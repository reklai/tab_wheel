"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/entryPoints/onboarding/onboarding.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabWheel.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());

  // src/lib/core/tabWheel/mouseGestureCore.ts
  var TABWHEEL_CLICK_ACTIONS = [
    "nativeNewTab",
    "recentTab",
    "closeToRecent",
    "duplicateTab",
    "dragCurrentTab",
    "openSettings",
    "none"
  ];
  var DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS = {
    leftClickAction: "nativeNewTab",
    middleClickAction: "dragCurrentTab",
    rightClickAction: "closeToRecent"
  };

  // src/lib/common/contracts/tabWheel.ts
  var TABWHEEL_ONBOARDING_VERSION = 2;
  var TABWHEEL_STORAGE_KEYS = {
    settings: "tabWheelSettings",
    scrollMemory: "tabWheelScrollMemory",
    recentTabs: "tabWheelRecentTabs",
    onboarding: "tabWheelOnboarding"
  };
  var TABWHEEL_MODIFIER_KEYS = ["alt", "ctrl", "meta"];
  var TABWHEEL_PRESETS = ["precise", "balanced", "fast", "custom"];
  var MIN_WHEEL_SENSITIVITY = 0.5;
  var MAX_WHEEL_SENSITIVITY = 2;
  var MIN_WHEEL_COOLDOWN_MS = 60;
  var MAX_WHEEL_COOLDOWN_MS = 400;
  var TABWHEEL_PRESET_VALUES = {
    precise: {
      wheelSensitivity: 0.8,
      wheelCooldownMs: 220,
      wheelAcceleration: false,
      overshootGuard: true
    },
    balanced: {
      wheelSensitivity: 1,
      wheelCooldownMs: 160,
      wheelAcceleration: false,
      overshootGuard: true
    },
    fast: {
      wheelSensitivity: 1.35,
      wheelCooldownMs: 90,
      wheelAcceleration: true,
      overshootGuard: true
    }
  };
  var DEFAULT_TABWHEEL_SETTINGS = {
    invertScroll: false,
    gestureModifier: "alt",
    gestureWithShift: false,
    allowGesturesInEditableFields: true,
    ...DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS,
    restorePagePosition: true,
    skipPinnedTabs: false,
    skipRestrictedPages: true,
    skipHiddenTabs: true,
    showRestrictedBadge: true,
    wrapAround: true,
    cycleWithinTabGroup: false,
    wheelPreset: "balanced",
    wheelSensitivity: 1,
    wheelCooldownMs: 160,
    wheelAcceleration: false,
    horizontalWheel: true,
    overshootGuard: true
  };
  var DEFAULT_TABWHEEL_ONBOARDING_STATE = {
    version: TABWHEEL_ONBOARDING_VERSION,
    demoCompleted: false,
    firstGestureCycleCompleted: false,
    clickActionsReleaseSeen: false
  };
  function normalizeModifierKey(value) {
    return TABWHEEL_MODIFIER_KEYS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.gestureModifier;
  }
  function normalizeEnabledFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeNumberInRange(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }
  function normalizeWheelPreset(value) {
    return TABWHEEL_PRESETS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.wheelPreset;
  }
  function normalizeClickAction(value, fallback) {
    return TABWHEEL_CLICK_ACTIONS.includes(value) ? value : fallback;
  }
  function detectTabWheelPreset(settings) {
    for (const preset of ["precise", "balanced", "fast"]) {
      const values = TABWHEEL_PRESET_VALUES[preset];
      if (settings.wheelSensitivity === values.wheelSensitivity && settings.wheelCooldownMs === values.wheelCooldownMs && settings.wheelAcceleration === values.wheelAcceleration && settings.overshootGuard === values.overshootGuard) {
        return preset;
      }
    }
    return "custom";
  }
  function normalizeTabWheelSettings(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
    const settings = value;
    const normalized = {
      invertScroll: settings.invertScroll === true,
      gestureModifier: normalizeModifierKey(settings.gestureModifier),
      gestureWithShift: settings.gestureWithShift === true,
      allowGesturesInEditableFields: true,
      leftClickAction: normalizeClickAction(
        settings.leftClickAction,
        DEFAULT_TABWHEEL_SETTINGS.leftClickAction
      ),
      middleClickAction: normalizeClickAction(
        settings.middleClickAction,
        DEFAULT_TABWHEEL_SETTINGS.middleClickAction
      ),
      rightClickAction: normalizeClickAction(
        settings.rightClickAction,
        DEFAULT_TABWHEEL_SETTINGS.rightClickAction
      ),
      restorePagePosition: true,
      skipPinnedTabs: normalizeEnabledFlag(settings.skipPinnedTabs, DEFAULT_TABWHEEL_SETTINGS.skipPinnedTabs),
      skipRestrictedPages: true,
      skipHiddenTabs: normalizeEnabledFlag(settings.skipHiddenTabs, DEFAULT_TABWHEEL_SETTINGS.skipHiddenTabs),
      showRestrictedBadge: true,
      wrapAround: normalizeEnabledFlag(settings.wrapAround, DEFAULT_TABWHEEL_SETTINGS.wrapAround),
      cycleWithinTabGroup: normalizeEnabledFlag(
        settings.cycleWithinTabGroup,
        DEFAULT_TABWHEEL_SETTINGS.cycleWithinTabGroup
      ),
      wheelPreset: normalizeWheelPreset(settings.wheelPreset),
      wheelSensitivity: normalizeNumberInRange(
        settings.wheelSensitivity,
        DEFAULT_TABWHEEL_SETTINGS.wheelSensitivity,
        MIN_WHEEL_SENSITIVITY,
        MAX_WHEEL_SENSITIVITY
      ),
      wheelCooldownMs: normalizeNumberInRange(
        settings.wheelCooldownMs,
        DEFAULT_TABWHEEL_SETTINGS.wheelCooldownMs,
        MIN_WHEEL_COOLDOWN_MS,
        MAX_WHEEL_COOLDOWN_MS
      ),
      wheelAcceleration: normalizeEnabledFlag(
        settings.wheelAcceleration,
        DEFAULT_TABWHEEL_SETTINGS.wheelAcceleration
      ),
      horizontalWheel: true,
      overshootGuard: true
    };
    normalized.wheelPreset = settings.wheelPreset == null ? detectTabWheelPreset(normalized) : normalized.wheelPreset;
    return normalized;
  }
  function normalizeTabWheelOnboardingState(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return { ...DEFAULT_TABWHEEL_ONBOARDING_STATE };
    }
    const state = value;
    return {
      version: Number(state.version) === TABWHEEL_ONBOARDING_VERSION ? TABWHEEL_ONBOARDING_VERSION : TABWHEEL_ONBOARDING_VERSION,
      demoCompleted: state.demoCompleted === true,
      firstGestureCycleCompleted: state.firstGestureCycleCompleted === true,
      clickActionsReleaseSeen: state.clickActionsReleaseSeen === true
    };
  }
  function formatTabWheelModifierKey(modifier) {
    if (modifier === "ctrl") return "Ctrl / Control";
    if (modifier === "meta") return "Meta / Command";
    return "Alt / Option";
  }
  function formatTabWheelModifierCombo(modifier, withShift) {
    const base = formatTabWheelModifierKey(modifier);
    return withShift ? `${base} + Shift` : base;
  }
  function formatTabWheelClickAction(action) {
    switch (action) {
      case "nativeNewTab":
        return "Browser new tab";
      case "recentTab":
        return "Most recent tab";
      case "closeToRecent":
        return "Close current tab";
      case "duplicateTab":
        return "Duplicate tab";
      case "dragCurrentTab":
        return "Drag current tab";
      case "openSettings":
        return "Open settings";
      case "none":
        return "Off";
    }
  }
  async function loadTabWheelSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.settings);
      return normalizeTabWheelSettings(data[TABWHEEL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
  }
  async function saveTabWheelSettings(settings) {
    await import_webextension_polyfill.default.storage.local.set({
      [TABWHEEL_STORAGE_KEYS.settings]: normalizeTabWheelSettings(settings)
    });
  }
  async function loadTabWheelOnboardingState() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.onboarding);
      return normalizeTabWheelOnboardingState(data[TABWHEEL_STORAGE_KEYS.onboarding]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_ONBOARDING_STATE };
    }
  }
  async function saveTabWheelOnboardingState(state) {
    await import_webextension_polyfill.default.storage.local.set({
      [TABWHEEL_STORAGE_KEYS.onboarding]: normalizeTabWheelOnboardingState(state)
    });
  }

  // src/lib/core/tabWheel/tabWheelCore.ts
  function isTabWheelModifier(event, modifier, withShift) {
    const expected = {
      altKey: modifier === "alt",
      ctrlKey: modifier === "ctrl",
      metaKey: modifier === "meta",
      shiftKey: withShift
    };
    return event.altKey === expected.altKey && event.ctrlKey === expected.ctrlKey && event.metaKey === expected.metaKey && event.shiftKey === expected.shiftKey;
  }
  function resolveWheelDirection(wheelDelta, invertScroll) {
    const normalDirection = wheelDelta > 0 ? "next" : "prev";
    if (!invertScroll) return normalDirection;
    return normalDirection === "next" ? "prev" : "next";
  }
  function normalizeWheelDelta(event, pageHeight, pageWidth, horizontalWheel) {
    const modeMultiplierY = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? pageHeight : 1;
    const normalizedY = event.deltaY * modeMultiplierY;
    if (!horizontalWheel) return normalizedY;
    const modeMultiplierX = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? pageWidth : 1;
    const normalizedX = event.deltaX * modeMultiplierX;
    return Math.abs(normalizedX) > Math.abs(normalizedY) ? normalizedX : normalizedY;
  }
  function resolveWheelTriggerDistance(baseThresholdPx, sensitivity) {
    const safeSensitivity = Number.isFinite(sensitivity) && sensitivity > 0 ? sensitivity : 1;
    return Math.max(1, baseThresholdPx / safeSensitivity);
  }

  // src/lib/core/tabWheel/tabDragCore.ts
  var TAB_DRAG_STEP_PX = 56;
  function createTabDragState(anchorX) {
    return {
      anchorX,
      blockedDirection: null
    };
  }
  function advanceTabDragState(state, clientX, stepPx = TAB_DRAG_STEP_PX) {
    const safeStepPx = Number.isFinite(stepPx) && stepPx > 0 ? stepPx : TAB_DRAG_STEP_PX;
    const deltaX = clientX - state.anchorX;
    const stepCount = Math.floor(Math.abs(deltaX) / safeStepPx);
    if (stepCount === 0) return { state, directions: [] };
    const direction = deltaX > 0 ? "right" : "left";
    const directionSign = direction === "right" ? 1 : -1;
    const nextState = {
      anchorX: state.anchorX + directionSign * stepCount * safeStepPx,
      blockedDirection: state.blockedDirection === direction ? direction : null
    };
    return {
      state: nextState,
      directions: state.blockedDirection === direction ? [] : Array.from({ length: stepCount }, () => direction)
    };
  }

  // src/lib/ui/settings/settingsControls.ts
  function populateModifierSelect(select, selected) {
    setSelectOptions(
      select,
      TABWHEEL_MODIFIER_KEYS,
      selected,
      (value) => formatTabWheelModifierKey(value)
    );
  }
  function populateClickActionSelect(select, selected) {
    setSelectOptions(
      select,
      TABWHEEL_CLICK_ACTIONS,
      selected,
      (value) => formatTabWheelClickAction(value)
    );
  }
  function setSelectOptions(select, values, selected, label) {
    select.replaceChildren();
    for (const value of values) {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = label(value);
      if (value === selected) option.selected = true;
      select.appendChild(option);
    }
  }

  // src/entryPoints/onboarding/onboarding.ts
  document.addEventListener("DOMContentLoaded", async () => {
    const byId = (id) => document.getElementById(id);
    let settings = await loadTabWheelSettings();
    let onboarding = await loadTabWheelOnboardingState();
    const wheelFlow = byId("wheelFlow");
    const mouseFlow = byId("mouseFlow");
    async function closeCurrentTab() {
      const tab = await import_webextension_polyfill2.default.tabs.getCurrent().catch(() => null);
      if (tab?.id != null) await import_webextension_polyfill2.default.tabs.remove(tab.id).catch(() => {
      });
      else window.close();
    }
    const demo = byId("gestureDemo");
    const demoCombo = byId("demoCombo");
    const demoPrompt = byId("demoPrompt");
    const demoStatus = byId("demoStatus");
    const continueDemoBtn = byId("continueDemoBtn");
    const modifierSelect = byId("gestureModifier");
    const gestureWithShift = byId("gestureWithShift");
    const leftClickAction = byId("leftClickAction");
    const middleClickAction = byId("middleClickAction");
    const rightClickAction = byId("rightClickAction");
    const introLeftClickAction = byId("introLeftClickAction");
    const introMiddleClickAction = byId("introMiddleClickAction");
    const introRightClickAction = byId("introRightClickAction");
    const clickGestureDemo = byId("clickGestureDemo");
    const clickPracticePrompt = byId("clickPracticePrompt");
    const clickDemoStatus = byId("clickDemoStatus");
    const browserSimulator = byId("browserSimulator");
    const simRecentTab = byId("simRecentTab");
    const simCurrentTab = byId("simCurrentTab");
    const simResultTab = byId("simResultTab");
    const simAddress = byId("simAddress");
    const simIcon = byId("simIcon");
    const simTitle = byId("simTitle");
    const simDescription = byId("simDescription");
    const tabs = [...document.querySelectorAll(".demo-tab")];
    let demoAccumulator = 0;
    let activeDemoTab = 0;
    let mouseHighlightTimer = 0;
    let demoTabDrag = null;
    let lastDemoTabDragMoved = false;
    const actionSelects = [leftClickAction, middleClickAction, rightClickAction];
    const introActionSelects = [
      introLeftClickAction,
      introMiddleClickAction,
      introRightClickAction
    ];
    const actionHintIds = ["leftActionHint", "middleActionHint", "rightActionHint"];
    function selectedAction(button) {
      return actionSelects[button]?.value || "none";
    }
    function selectedModifier() {
      return modifierSelect.value;
    }
    function renderCombo() {
      const combo = formatTabWheelModifierCombo(
        selectedModifier(),
        gestureWithShift.checked
      );
      demoCombo.textContent = combo;
      demoPrompt.textContent = `Hold ${combo} + scroll`;
      clickPracticePrompt.textContent = `Hold ${combo}, then click or drag with a mouse button here`;
      byId("clickCombo").textContent = `${combo} + mouse`;
      byId("settingsWheelCombo").textContent = `${combo} + wheel`;
    }
    function renderActionSummaries() {
      const hints = {
        nativeNewTab: "Open the browser's New Tab page beside the current tab.",
        recentTab: "Return to the previously active tab.",
        closeToRecent: "Close this tab and return to the previous one.",
        duplicateTab: "Copy this tab beside it and select the copy.",
        dragCurrentTab: "Hold and drag horizontally to move this tab in the strip.",
        openSettings: "Open TabWheel settings in a tab.",
        none: "Off leaves this mouse combination browser-native."
      };
      actionSelects.forEach((select, index) => {
        byId(actionHintIds[index]).textContent = hints[select.value];
      });
    }
    function setSetupProgress(step) {
      for (const marker of document.querySelectorAll("#setupProgress [data-progress]")) {
        marker.classList.toggle("active", Number(marker.dataset.progress) <= step);
      }
    }
    function showWheelStep(step) {
      for (const panel of wheelFlow.querySelectorAll("[data-wheel-step]")) {
        panel.hidden = Number(panel.dataset.wheelStep) !== step;
      }
    }
    function showMouseStep(step) {
      for (const panel of mouseFlow.querySelectorAll("[data-mouse-step]")) {
        panel.hidden = Number(panel.dataset.mouseStep) !== step;
      }
    }
    function openMouseFlow() {
      wheelFlow.hidden = true;
      mouseFlow.hidden = false;
      showMouseStep(1);
      setSetupProgress(2);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
    function returnToWheelDemo() {
      mouseFlow.hidden = true;
      wheelFlow.hidden = false;
      showWheelStep(1);
      setSetupProgress(1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
    function continueToWheelSettings() {
      mouseFlow.hidden = true;
      wheelFlow.hidden = false;
      showWheelStep(2);
      setSetupProgress(3);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
    async function markDemoComplete() {
      if (onboarding.demoCompleted) return;
      onboarding = { ...onboarding, demoCompleted: true };
      await saveTabWheelOnboardingState(onboarding);
    }
    function resetBrowserSimulation() {
      const simTabs = simCurrentTab.parentElement;
      simTabs?.append(simRecentTab, simCurrentTab, simResultTab);
      browserSimulator.dataset.state = "idle";
      simRecentTab.hidden = false;
      simRecentTab.classList.remove("active");
      simCurrentTab.hidden = false;
      simCurrentTab.classList.remove("closing");
      simCurrentTab.classList.add("active");
      simResultTab.hidden = true;
      simResultTab.classList.remove("active");
      simResultTab.textContent = "New tab";
      simAddress.textContent = "Current page";
      lastDemoTabDragMoved = false;
    }
    function renderSimulatedResult(action) {
      resetBrowserSimulation();
      browserSimulator.dataset.state = action;
      const descriptions = {
        nativeNewTab: [
          "\uFF0B",
          "Browser New Tab selected",
          "The browser owns this page, so TabWheel gestures resume after you navigate."
        ],
        recentTab: ["\u21B6", "Back to Research", "The most recently active tab becomes selected."],
        closeToRecent: ["\xD7", "Current tab closed", "Research becomes active immediately."],
        duplicateTab: ["\u29C9", "Current tab duplicated", "The copy opens beside the original and becomes active."],
        dragCurrentTab: ["\u2194", "Drag current tab", "Drag horizontally to move this tab through its strip section."],
        openSettings: ["\u2699", "Settings opened", "TabWheel opens its full settings page."],
        none: ["\u25CB", "Browser-native behavior", "TabWheel does not claim this mouse combination."]
      };
      const [icon, title, description] = descriptions[action];
      simIcon.textContent = icon;
      simTitle.textContent = title;
      simDescription.textContent = description;
      if (action === "nativeNewTab" || action === "duplicateTab") {
        simCurrentTab.classList.remove("active");
        simResultTab.hidden = false;
        simResultTab.classList.add("active");
        simResultTab.textContent = action === "duplicateTab" ? "Current tab copy" : "New tab";
        simAddress.textContent = action === "duplicateTab" ? "Current page" : "Browser-controlled New Tab";
      } else if (action === "recentTab" || action === "closeToRecent") {
        simCurrentTab.classList.remove("active");
        simRecentTab.classList.add("active");
        if (action === "closeToRecent") simCurrentTab.classList.add("closing");
        simAddress.textContent = "Research";
      } else if (action === "dragCurrentTab") {
        simResultTab.hidden = false;
        simResultTab.textContent = "Other tab";
      } else if (action === "openSettings") {
        simAddress.textContent = "TabWheel settings";
      }
      clickDemoStatus.textContent = `${formatTabWheelClickAction(action)} \u2014 ${description}`;
    }
    function highlightMouseButton(button) {
      for (const part of document.querySelectorAll("[data-mouse-part]")) {
        part.classList.toggle("active", Number(part.dataset.mousePart) === button);
      }
      if (mouseHighlightTimer) window.clearTimeout(mouseHighlightTimer);
      mouseHighlightTimer = window.setTimeout(() => {
        for (const part of document.querySelectorAll("[data-mouse-part]")) {
          part.classList.remove("active");
        }
        mouseHighlightTimer = 0;
      }, 320);
    }
    function previewAction(action, button) {
      highlightMouseButton(button);
      renderSimulatedResult(action);
    }
    function isConfiguredDemoGesture(event) {
      return isTabWheelModifier(
        event,
        selectedModifier(),
        gestureWithShift.checked
      );
    }
    function suppressDemoEvent(event) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
    function moveSimulatedCurrentTab(direction) {
      const parent = simCurrentTab.parentElement;
      if (!parent) return false;
      const visibleTabs = [...parent.children].filter((child) => child instanceof HTMLElement && !child.hidden);
      const currentIndex = visibleTabs.indexOf(simCurrentTab);
      const target = visibleTabs[currentIndex + (direction === "right" ? 1 : -1)];
      if (!target) return false;
      if (direction === "left") parent.insertBefore(simCurrentTab, target);
      else parent.insertBefore(target, simCurrentTab);
      return true;
    }
    function clickDemoPressHandler(event) {
      if (!isConfiguredDemoGesture(event)) return;
      const action = selectedAction(event.button);
      if (action === "none") return;
      suppressDemoEvent(event);
      if (action !== "dragCurrentTab" || event.type !== "pointerdown" || !(event instanceof PointerEvent) || event.pointerType !== "mouse") return;
      previewAction(action, event.button);
      demoTabDrag = {
        pointerId: event.pointerId,
        button: event.button,
        state: createTabDragState(event.clientX),
        moved: false
      };
      lastDemoTabDragMoved = false;
      try {
        clickGestureDemo.setPointerCapture(event.pointerId);
      } catch (_) {
      }
    }
    function clickDemoDragMoveHandler(event) {
      const session = demoTabDrag;
      if (!session || event.pointerId !== session.pointerId) return;
      suppressDemoEvent(event);
      const advanced = advanceTabDragState(session.state, event.clientX);
      session.state = advanced.state;
      for (const direction of advanced.directions) {
        session.moved = moveSimulatedCurrentTab(direction) || session.moved;
      }
      if (session.moved) {
        clickDemoStatus.textContent = "Drag current tab \u2014 the active tab moves live and stays selected.";
      }
    }
    function finishClickDemoDrag(event) {
      const session = demoTabDrag;
      if (!session || event.pointerId !== session.pointerId) return;
      suppressDemoEvent(event);
      lastDemoTabDragMoved = session.moved;
      demoTabDrag = null;
      try {
        if (clickGestureDemo.hasPointerCapture(event.pointerId)) {
          clickGestureDemo.releasePointerCapture(event.pointerId);
        }
      } catch (_) {
      }
      if (!lastDemoTabDragMoved) {
        clickDemoStatus.textContent = "Drag current tab \u2014 move horizontally at least 56 px to shift one slot.";
      }
    }
    function clickDemoActionHandler(event) {
      if (!isConfiguredDemoGesture(event)) {
        clickDemoStatus.textContent = `Hold ${formatTabWheelModifierCombo(
          selectedModifier(),
          gestureWithShift.checked
        )} while clicking.`;
        return;
      }
      const action = selectedAction(event.button);
      if (action === "none") {
        renderSimulatedResult("none");
        return;
      }
      suppressDemoEvent(event);
      if (action === "dragCurrentTab") {
        if (!lastDemoTabDragMoved) {
          clickDemoStatus.textContent = "Drag current tab \u2014 hold the button and drag horizontally.";
        }
        return;
      }
      previewAction(action, event.button);
    }
    populateModifierSelect(modifierSelect, settings.gestureModifier);
    populateClickActionSelect(leftClickAction, settings.leftClickAction);
    populateClickActionSelect(middleClickAction, settings.middleClickAction);
    populateClickActionSelect(rightClickAction, settings.rightClickAction);
    populateClickActionSelect(introLeftClickAction, settings.leftClickAction);
    populateClickActionSelect(introMiddleClickAction, settings.middleClickAction);
    populateClickActionSelect(introRightClickAction, settings.rightClickAction);
    gestureWithShift.checked = settings.gestureWithShift;
    renderCombo();
    renderActionSummaries();
    demo.addEventListener("wheel", (event) => {
      if (!isTabWheelModifier(event, selectedModifier(), gestureWithShift.checked)) {
        demoStatus.textContent = `Hold ${formatTabWheelModifierCombo(selectedModifier(), gestureWithShift.checked)} while scrolling.`;
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      demoAccumulator += normalizeWheelDelta(event, demo.clientHeight, demo.clientWidth, false);
      const triggerDistance = resolveWheelTriggerDistance(80, settings.wheelSensitivity);
      if (Math.abs(demoAccumulator) < triggerDistance) return;
      const movement = resolveWheelDirection(demoAccumulator, settings.invertScroll) === "next" ? 1 : -1;
      activeDemoTab = (activeDemoTab + movement + tabs.length) % tabs.length;
      tabs.forEach((tab, index) => tab.classList.toggle("active", index === activeDemoTab));
      demoAccumulator = 0;
      demo.classList.add("success");
      demoStatus.textContent = "Perfect \u2014 that is the whole wheel gesture.";
      continueDemoBtn.disabled = false;
      void markDemoComplete();
    }, { passive: false });
    demo.addEventListener("click", () => demo.focus());
    clickGestureDemo.addEventListener("pointerdown", clickDemoPressHandler);
    clickGestureDemo.addEventListener("pointermove", clickDemoDragMoveHandler);
    clickGestureDemo.addEventListener("pointerup", finishClickDemoDrag);
    clickGestureDemo.addEventListener("pointercancel", finishClickDemoDrag);
    clickGestureDemo.addEventListener("mousedown", clickDemoPressHandler);
    clickGestureDemo.addEventListener("click", clickDemoActionHandler);
    clickGestureDemo.addEventListener("auxclick", clickDemoActionHandler);
    clickGestureDemo.addEventListener("contextmenu", clickDemoActionHandler);
    for (const previewButton of document.querySelectorAll("[data-preview-button]")) {
      previewButton.addEventListener("click", () => {
        const button = Number(previewButton.dataset.previewButton);
        previewAction(selectedAction(button), button);
      });
    }
    for (const control of [modifierSelect, gestureWithShift]) {
      control.addEventListener("change", () => {
        renderCombo();
        resetBrowserSimulation();
      });
    }
    actionSelects.forEach((select, index) => {
      select.addEventListener("change", () => {
        introActionSelects[index].value = select.value;
        renderActionSummaries();
        resetBrowserSimulation();
      });
    });
    introActionSelects.forEach((select, index) => {
      select.addEventListener("change", () => {
        actionSelects[index].value = select.value;
        renderActionSummaries();
        resetBrowserSimulation();
        previewAction(selectedAction(index), index);
      });
    });
    continueDemoBtn.addEventListener("click", openMouseFlow);
    byId("skipDemoBtn").addEventListener("click", openMouseFlow);
    byId("wheelBackBtn").addEventListener("click", openMouseFlow);
    byId("saveWheelChoicesBtn").addEventListener("click", async () => {
      const finishBtn = byId("saveWheelChoicesBtn");
      if (finishBtn.disabled) return;
      finishBtn.disabled = true;
      settings = {
        ...settings,
        gestureModifier: selectedModifier(),
        gestureWithShift: gestureWithShift.checked,
        leftClickAction: leftClickAction.value,
        middleClickAction: middleClickAction.value,
        rightClickAction: rightClickAction.value
      };
      try {
        await saveTabWheelSettings(settings);
        onboarding = { ...onboarding, version: 2, clickActionsReleaseSeen: true };
        await saveTabWheelOnboardingState(onboarding);
        await closeCurrentTab();
      } catch (error) {
        finishBtn.disabled = false;
        throw error;
      }
    });
    byId("clickBackBtn").addEventListener("click", returnToWheelDemo);
    byId("saveChoicesBtn").addEventListener("click", () => {
      continueToWheelSettings();
    });
  });
})();

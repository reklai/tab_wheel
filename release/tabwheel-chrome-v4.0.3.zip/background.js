"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/backgroundRuntime/domains/tabWheelDomain.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabWheel.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());

  // src/lib/core/tabWheel/mouseGestureCore.ts
  var TABWHEEL_CLICK_ACTIONS = [
    "nativeNewTab",
    "recentTab",
    "closeToRecent",
    "duplicateTab",
    "dragCurrentTab",
    "openSettings",
    "none"
  ];
  var DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS = {
    leftClickAction: "nativeNewTab",
    middleClickAction: "dragCurrentTab",
    rightClickAction: "closeToRecent"
  };

  // src/lib/common/contracts/tabWheel.ts
  var MAX_SCROLL_MEMORY_ENTRIES = 300;
  var MAX_RECENT_TABS = 100;
  var TABWHEEL_ONBOARDING_VERSION = 2;
  var TABWHEEL_STORAGE_KEYS = {
    settings: "tabWheelSettings",
    scrollMemory: "tabWheelScrollMemory",
    recentTabs: "tabWheelRecentTabs",
    onboarding: "tabWheelOnboarding"
  };
  var TABWHEEL_MODIFIER_KEYS = ["alt", "ctrl", "meta"];
  var TABWHEEL_PRESETS = ["precise", "balanced", "fast", "custom"];
  var MIN_WHEEL_SENSITIVITY = 0.5;
  var MAX_WHEEL_SENSITIVITY = 2;
  var MIN_WHEEL_COOLDOWN_MS = 60;
  var MAX_WHEEL_COOLDOWN_MS = 400;
  var TABWHEEL_PRESET_VALUES = {
    precise: {
      wheelSensitivity: 0.8,
      wheelCooldownMs: 220,
      wheelAcceleration: false,
      overshootGuard: true
    },
    balanced: {
      wheelSensitivity: 1,
      wheelCooldownMs: 160,
      wheelAcceleration: false,
      overshootGuard: true
    },
    fast: {
      wheelSensitivity: 1.35,
      wheelCooldownMs: 90,
      wheelAcceleration: true,
      overshootGuard: true
    }
  };
  var DEFAULT_TABWHEEL_SETTINGS = {
    invertScroll: false,
    gestureModifier: "alt",
    gestureWithShift: false,
    allowGesturesInEditableFields: true,
    ...DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS,
    restorePagePosition: true,
    skipPinnedTabs: false,
    skipRestrictedPages: true,
    skipHiddenTabs: true,
    showRestrictedBadge: true,
    wrapAround: true,
    cycleWithinTabGroup: false,
    wheelPreset: "balanced",
    wheelSensitivity: 1,
    wheelCooldownMs: 160,
    wheelAcceleration: false,
    horizontalWheel: true,
    overshootGuard: true
  };
  var DEFAULT_TABWHEEL_ONBOARDING_STATE = {
    version: TABWHEEL_ONBOARDING_VERSION,
    demoCompleted: false,
    firstGestureCycleCompleted: false,
    clickActionsReleaseSeen: false
  };
  function normalizeModifierKey(value) {
    return TABWHEEL_MODIFIER_KEYS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.gestureModifier;
  }
  function normalizeEnabledFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeNumberInRange(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }
  function normalizeWheelPreset(value) {
    return TABWHEEL_PRESETS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.wheelPreset;
  }
  function normalizeClickAction(value, fallback) {
    return TABWHEEL_CLICK_ACTIONS.includes(value) ? value : fallback;
  }
  function detectTabWheelPreset(settings) {
    for (const preset of ["precise", "balanced", "fast"]) {
      const values = TABWHEEL_PRESET_VALUES[preset];
      if (settings.wheelSensitivity === values.wheelSensitivity && settings.wheelCooldownMs === values.wheelCooldownMs && settings.wheelAcceleration === values.wheelAcceleration && settings.overshootGuard === values.overshootGuard) {
        return preset;
      }
    }
    return "custom";
  }
  function normalizeTabWheelSettings(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
    const settings = value;
    const normalized = {
      invertScroll: settings.invertScroll === true,
      gestureModifier: normalizeModifierKey(settings.gestureModifier),
      gestureWithShift: settings.gestureWithShift === true,
      allowGesturesInEditableFields: true,
      leftClickAction: normalizeClickAction(
        settings.leftClickAction,
        DEFAULT_TABWHEEL_SETTINGS.leftClickAction
      ),
      middleClickAction: normalizeClickAction(
        settings.middleClickAction,
        DEFAULT_TABWHEEL_SETTINGS.middleClickAction
      ),
      rightClickAction: normalizeClickAction(
        settings.rightClickAction,
        DEFAULT_TABWHEEL_SETTINGS.rightClickAction
      ),
      restorePagePosition: true,
      skipPinnedTabs: normalizeEnabledFlag(settings.skipPinnedTabs, DEFAULT_TABWHEEL_SETTINGS.skipPinnedTabs),
      skipRestrictedPages: true,
      skipHiddenTabs: normalizeEnabledFlag(settings.skipHiddenTabs, DEFAULT_TABWHEEL_SETTINGS.skipHiddenTabs),
      showRestrictedBadge: true,
      wrapAround: normalizeEnabledFlag(settings.wrapAround, DEFAULT_TABWHEEL_SETTINGS.wrapAround),
      cycleWithinTabGroup: normalizeEnabledFlag(
        settings.cycleWithinTabGroup,
        DEFAULT_TABWHEEL_SETTINGS.cycleWithinTabGroup
      ),
      wheelPreset: normalizeWheelPreset(settings.wheelPreset),
      wheelSensitivity: normalizeNumberInRange(
        settings.wheelSensitivity,
        DEFAULT_TABWHEEL_SETTINGS.wheelSensitivity,
        MIN_WHEEL_SENSITIVITY,
        MAX_WHEEL_SENSITIVITY
      ),
      wheelCooldownMs: normalizeNumberInRange(
        settings.wheelCooldownMs,
        DEFAULT_TABWHEEL_SETTINGS.wheelCooldownMs,
        MIN_WHEEL_COOLDOWN_MS,
        MAX_WHEEL_COOLDOWN_MS
      ),
      wheelAcceleration: normalizeEnabledFlag(
        settings.wheelAcceleration,
        DEFAULT_TABWHEEL_SETTINGS.wheelAcceleration
      ),
      horizontalWheel: true,
      overshootGuard: true
    };
    normalized.wheelPreset = settings.wheelPreset == null ? detectTabWheelPreset(normalized) : normalized.wheelPreset;
    return normalized;
  }
  function normalizeTabWheelOnboardingState(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return { ...DEFAULT_TABWHEEL_ONBOARDING_STATE };
    }
    const state = value;
    return {
      version: Number(state.version) === TABWHEEL_ONBOARDING_VERSION ? TABWHEEL_ONBOARDING_VERSION : TABWHEEL_ONBOARDING_VERSION,
      demoCompleted: state.demoCompleted === true,
      firstGestureCycleCompleted: state.firstGestureCycleCompleted === true,
      clickActionsReleaseSeen: state.clickActionsReleaseSeen === true
    };
  }
  async function loadTabWheelSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.settings);
      return normalizeTabWheelSettings(data[TABWHEEL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
  }
  async function loadTabWheelOnboardingState() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.onboarding);
      return normalizeTabWheelOnboardingState(data[TABWHEEL_STORAGE_KEYS.onboarding]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_ONBOARDING_STATE };
    }
  }
  async function saveTabWheelOnboardingState(state) {
    await import_webextension_polyfill.default.storage.local.set({
      [TABWHEEL_STORAGE_KEYS.onboarding]: normalizeTabWheelOnboardingState(state)
    });
  }

  // src/lib/core/tabWheel/tabWheelCore.ts
  function resolveCycleTargetIndex(tabIndices, currentTabIndex, direction, wrapAround) {
    const candidates = tabIndices.slice().sort((left, right) => left - right);
    if (candidates.length === 0) return -1;
    if (candidates.length === 1) return candidates[0];
    if (direction === "next") {
      const nextIndex = candidates.find((index) => index > currentTabIndex);
      if (nextIndex != null) return nextIndex;
      return wrapAround ? candidates[0] : currentTabIndex;
    }
    for (let i = candidates.length - 1; i >= 0; i--) {
      if (candidates[i] < currentTabIndex) return candidates[i];
    }
    return wrapAround ? candidates[candidates.length - 1] : currentTabIndex;
  }

  // src/lib/core/tabWheel/tabDragCore.ts
  function resolveMovedTabResult(result, expectedTabId) {
    const candidates = Array.isArray(result) ? result : result != null ? [result] : [];
    for (const candidate of candidates) {
      if (candidate === null || typeof candidate !== "object") continue;
      try {
        const id = Reflect.get(candidate, "id");
        const index = Reflect.get(candidate, "index");
        if (id === expectedTabId && typeof index === "number" && Number.isInteger(index) && index >= 0) {
          return { id, index };
        }
      } catch {
      }
    }
    return null;
  }
  function normalizeGroupId(groupId) {
    return groupId ?? -1;
  }
  function resolveTabDragTargetIndex(activeTab, tabs, direction) {
    const targetIndex = activeTab.index + (direction === "right" ? 1 : -1);
    const neighbor = tabs.find((tab) => tab.index === targetIndex);
    if (!neighbor) return null;
    if (neighbor.pinned === true !== (activeTab.pinned === true)) return null;
    if (normalizeGroupId(neighbor.groupId) !== normalizeGroupId(activeTab.groupId)) return null;
    return targetIndex;
  }

  // src/lib/core/tabWheel/restrictedPagesCore.ts
  function normalizePageUrl(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url);
      return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.href : null;
    } catch (_) {
      return null;
    }
  }
  var KNOWN_BROWSER_STORE_RESTRICTED_HOSTS = /* @__PURE__ */ new Set([
    "addons.mozilla.org",
    "chromewebstore.google.com"
  ]);
  function normalizeHostname(hostname) {
    return hostname.toLowerCase().replace(/^www\./, "");
  }
  function isKnownBrowserStoreRestrictedUrl(url) {
    if (!url) return false;
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return false;
      const hostname = normalizeHostname(parsed.hostname);
      if (KNOWN_BROWSER_STORE_RESTRICTED_HOSTS.has(hostname)) return true;
      return hostname === "chrome.google.com" && parsed.pathname.toLowerCase().startsWith("/webstore");
    } catch (_) {
      return false;
    }
  }
  function isPageGestureRestrictedUrl(url) {
    return !normalizePageUrl(url) || isKnownBrowserStoreRestrictedUrl(url);
  }
  function resolveToolbarBadge(pageUrl, showBadge) {
    if (!showBadge) return null;
    return isPageGestureRestrictedUrl(pageUrl) ? { text: "!" } : null;
  }

  // src/lib/common/utils/asyncFlow.ts
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function createInFlightMemo(task) {
    let inFlight = null;
    return () => {
      if (inFlight) return inFlight;
      inFlight = task().catch((error) => {
        inFlight = null;
        throw error;
      });
      return inFlight;
    };
  }
  function createWriteChain() {
    let chain = Promise.resolve();
    return {
      enqueue(task) {
        const scheduledWrite = chain.catch(() => {
        }).then(() => task());
        chain = scheduledWrite.catch(() => {
        });
        return scheduledWrite;
      }
    };
  }
  function createKeyedTaskQueue() {
    const tasksByKey = /* @__PURE__ */ new Map();
    return {
      run(key, task) {
        const previousTask = tasksByKey.get(key) ?? Promise.resolve();
        const result = previousTask.then(() => task());
        const settled = result.then(() => {
        }, () => {
        });
        tasksByKey.set(key, settled);
        void settled.then(() => {
          if (tasksByKey.get(key) === settled) {
            tasksByKey.delete(key);
          }
        });
        return result;
      }
    };
  }

  // src/lib/backgroundRuntime/domains/toolbarBadge.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  var RESTRICTED_BADGE_BACKGROUND_COLOR = "#b45309";
  var badgedTabIds = /* @__PURE__ */ new Set();
  var badgeBackgroundColorApplied = false;
  function getToolbarBadgeApi() {
    const runtimeBrowser = import_webextension_polyfill2.default;
    const api = runtimeBrowser.action ?? runtimeBrowser.browserAction ?? null;
    return typeof api?.setBadgeText === "function" ? api : null;
  }
  async function ensureBadgeBackgroundColor(api) {
    if (badgeBackgroundColorApplied || typeof api.setBadgeBackgroundColor !== "function") return;
    badgeBackgroundColorApplied = true;
    try {
      await api.setBadgeBackgroundColor({ color: RESTRICTED_BADGE_BACKGROUND_COLOR });
    } catch (_) {
      badgeBackgroundColorApplied = false;
    }
  }
  async function updateTabToolbarBadge(tabId, pageUrl, showBadge) {
    const api = getToolbarBadgeApi();
    if (!api) return;
    const badge = resolveToolbarBadge(pageUrl, showBadge);
    if (badge) {
      await ensureBadgeBackgroundColor(api);
      try {
        await api.setBadgeText({ text: badge.text, tabId });
        badgedTabIds.add(tabId);
      } catch (_) {
      }
      return;
    }
    try {
      await api.setBadgeText({ text: "", tabId });
    } catch (_) {
    } finally {
      badgedTabIds.delete(tabId);
    }
  }
  function forgetToolbarBadgeTab(tabId) {
    badgedTabIds.delete(tabId);
  }

  // src/lib/backgroundRuntime/domains/tabWheelDomain.ts
  var FALLBACK_CYCLE_LOCK_WINDOW_ID = 0;
  var LEGACY_RECENT_TABS_STORAGE_KEY = "tabWheelMruState";
  var WINDOW_TABS_CACHE_TTL_MS = 350;
  var SCROLL_MEMORY_SAVE_DEBOUNCE_MS = 120;
  var GESTURE_TARGET_PROBE_TIMEOUT_MS = 150;
  var MAX_GESTURE_PROBE_ATTEMPTS = 4;
  var NEIGHBOR_PREPROBE_DEPTH = 2;
  var CONTENT_SCRIPT_UNAVAILABLE_CACHE_TTL_MS = 2500;
  var NEIGHBOR_PREPROBE_RETRY_COOLDOWN_MS = CONTENT_SCRIPT_UNAVAILABLE_CACHE_TTL_MS;
  var GESTURE_CONTENT_SCRIPT_READY_RETRY_DELAYS_MS = [0, 80, 180];
  var SCROLL_RESTORE_RETRY_DELAYS_MS = [0, 80, 220, 500, 900, 1500, 2400, 3600];
  var DISCARDED_SCROLL_RESTORE_RETRY_DELAYS_MS = [...SCROLL_RESTORE_RETRY_DELAYS_MS, 4e3];
  var DISCARDED_WAKE_HOLD_SAFETY_MS = 15e3;
  var TAB_DRAG_SESSION_TIMEOUT_MS = 5 * 60 * 1e3;
  function windowKey(windowId) {
    return String(windowId);
  }
  function tabKey(tabId) {
    return String(tabId);
  }
  async function resolveWithTimeout(task, timeoutMs, fallback) {
    let timeoutId = null;
    const guardedTask = task.catch(() => fallback);
    const timeout = new Promise((resolve) => {
      timeoutId = setTimeout(() => resolve(fallback), timeoutMs);
    });
    try {
      return await Promise.race([guardedTask, timeout]);
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }
  }
  function normalizeScroll(scrollX, scrollY) {
    return {
      scrollX: Math.max(0, Number(scrollX) || 0),
      scrollY: Math.max(0, Number(scrollY) || 0)
    };
  }
  function normalizeScrollRatio(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return 0;
    return Math.max(0, Math.min(1, numeric));
  }
  function normalizeScrollDimension(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return 0;
    return Math.max(0, numeric);
  }
  function normalizeScrollData(value) {
    const scroll = normalizeScroll(Number(value.scrollX), Number(value.scrollY));
    const scrollWidth = normalizeScrollDimension(value.scrollWidth);
    const scrollHeight = normalizeScrollDimension(value.scrollHeight);
    const viewportWidth = normalizeScrollDimension(value.viewportWidth);
    const viewportHeight = normalizeScrollDimension(value.viewportHeight);
    const maxScrollX = Math.max(0, scrollWidth - viewportWidth);
    const maxScrollY = Math.max(0, scrollHeight - viewportHeight);
    return {
      scrollX: scroll.scrollX,
      scrollY: scroll.scrollY,
      scrollRatioX: value.scrollRatioX == null ? maxScrollX > 0 ? Math.max(0, Math.min(1, scroll.scrollX / maxScrollX)) : 0 : normalizeScrollRatio(value.scrollRatioX),
      scrollRatioY: value.scrollRatioY == null ? maxScrollY > 0 ? Math.max(0, Math.min(1, scroll.scrollY / maxScrollY)) : 0 : normalizeScrollRatio(value.scrollRatioY),
      scrollWidth,
      scrollHeight,
      viewportWidth,
      viewportHeight
    };
  }
  function normalizeScrollMemoryEntry(rawEntry) {
    if (typeof rawEntry !== "object" || rawEntry === null) return null;
    const entry = rawEntry;
    const tabId = Number(entry.tabId);
    const windowId = Number(entry.windowId);
    const url = normalizePageUrl(entry.url);
    if (!Number.isInteger(tabId) || tabId <= 0) return null;
    if (!Number.isInteger(windowId) || windowId <= 0) return null;
    if (!url) return null;
    const scroll = normalizeScrollData(entry);
    return {
      tabId,
      windowId,
      url,
      scrollX: scroll.scrollX,
      scrollY: scroll.scrollY,
      scrollRatioX: scroll.scrollRatioX,
      scrollRatioY: scroll.scrollRatioY,
      scrollWidth: scroll.scrollWidth,
      scrollHeight: scroll.scrollHeight,
      viewportWidth: scroll.viewportWidth,
      viewportHeight: scroll.viewportHeight,
      updatedAt: Number.isFinite(Number(entry.updatedAt)) ? Number(entry.updatedAt) : Date.now()
    };
  }
  function normalizeScrollMemory(rawValue) {
    if (typeof rawValue !== "object" || rawValue === null || Array.isArray(rawValue)) return {};
    const normalized = {};
    for (const [key, rawEntry] of Object.entries(rawValue)) {
      const entry = normalizeScrollMemoryEntry(rawEntry);
      if (!entry || key !== tabKey(entry.tabId)) continue;
      normalized[key] = entry;
    }
    return normalized;
  }
  function trimScrollMemory(memory) {
    const entries = Object.values(memory).sort((left, right) => right.updatedAt - left.updatedAt).slice(0, MAX_SCROLL_MEMORY_ENTRIES);
    return Object.fromEntries(entries.map((entry) => [tabKey(entry.tabId), entry]));
  }
  function normalizeRecentTabState(rawValue) {
    if (typeof rawValue !== "object" || rawValue === null || Array.isArray(rawValue)) return {};
    const normalized = {};
    for (const [key, rawTabIds] of Object.entries(rawValue)) {
      const windowId = Number(key);
      if (!Number.isInteger(windowId) || windowId <= 0 || !Array.isArray(rawTabIds)) continue;
      const seenTabIds = /* @__PURE__ */ new Set();
      const tabIds = rawTabIds.map((value) => Number(value)).filter((tabId) => {
        if (!Number.isInteger(tabId) || tabId <= 0 || seenTabIds.has(tabId)) return false;
        seenTabIds.add(tabId);
        return true;
      }).slice(0, MAX_RECENT_TABS);
      if (tabIds.length > 0) normalized[key] = tabIds;
    }
    return normalized;
  }
  function buildScrollMemoryEntry(tabId, windowId, url, scroll) {
    return {
      tabId,
      windowId,
      url,
      scrollX: scroll.scrollX,
      scrollY: scroll.scrollY,
      scrollRatioX: scroll.scrollRatioX,
      scrollRatioY: scroll.scrollRatioY,
      scrollWidth: scroll.scrollWidth,
      scrollHeight: scroll.scrollHeight,
      viewportWidth: scroll.viewportWidth,
      viewportHeight: scroll.viewportHeight,
      updatedAt: Date.now()
    };
  }
  function getTabIndex(tab) {
    return Number(tab.index) || 0;
  }
  function isRestrictedTab(tab) {
    return isPageGestureRestrictedUrl(tab.url);
  }
  function getBrowserTabGroupsApi() {
    return import_webextension_polyfill3.default.tabGroups ?? null;
  }
  function isCollapsedGroupTab(tab, collapsedTabGroupIds) {
    return tab.groupId != null && collapsedTabGroupIds.has(tab.groupId);
  }
  function normalizeTabGroupId(groupId) {
    return groupId ?? -1;
  }
  function getEligibleTabs(tabs, settings, collapsedTabGroupIds = /* @__PURE__ */ new Set(), activeTabGroupId) {
    return tabs.filter((tab) => tab.id != null && (!settings.skipPinnedTabs || tab.pinned !== true) && (!settings.skipHiddenTabs || tab.hidden !== true && !isCollapsedGroupTab(tab, collapsedTabGroupIds)) && (!settings.skipRestrictedPages || !isRestrictedTab(tab)) && (!settings.cycleWithinTabGroup || activeTabGroupId == null || normalizeTabGroupId(tab.groupId) === activeTabGroupId)).sort((left, right) => getTabIndex(left) - getTabIndex(right));
  }
  function hasSameNumberList(left, right) {
    return left.length === right.length && left.every((value, index) => value === right[index]);
  }
  function createTabWheelDomain(options = {}) {
    const migrationReady2 = options.migrationReady ?? Promise.resolve();
    let scrollMemoryByTabId = {};
    let recentTabIdsByWindowId = {};
    const windowTabsCacheByWindowId = /* @__PURE__ */ new Map();
    const collapsedTabGroupIdsCacheByWindowId = /* @__PURE__ */ new Map();
    const contentScriptReadyUrlsByTabId = /* @__PURE__ */ new Map();
    const windowGestureTaskQueue = createKeyedTaskQueue();
    const tabDragSessionsById = /* @__PURE__ */ new Map();
    const tabDragTailsByWindowId = /* @__PURE__ */ new Map();
    const recentTabStateWriteChain = createWriteChain();
    const activeTabIdsByWindowId = /* @__PURE__ */ new Map();
    const scrollRestoreTokensByTabId = /* @__PURE__ */ new Map();
    const contentScriptUnavailableUrlsByTabId = /* @__PURE__ */ new Map();
    const neighborWarmupTabIds = /* @__PURE__ */ new Set();
    const neighborPreprobedUntilByTabId = /* @__PURE__ */ new Map();
    const neighborWarmupGenerationByWindowId = /* @__PURE__ */ new Map();
    const discardedWakeHoldByWindowId = /* @__PURE__ */ new Map();
    let scrollRestoreSerial = 0;
    let scrollMemorySaveTimer = null;
    let scrollMemorySaveResolvers = [];
    let scrollMemoryWriteChain = Promise.resolve();
    let settingsCache = null;
    const ensureLoaded = createInFlightMemo(async () => {
      await migrationReady2.catch(() => {
      });
      const stored = await import_webextension_polyfill3.default.storage.local.get([
        TABWHEEL_STORAGE_KEYS.scrollMemory,
        TABWHEEL_STORAGE_KEYS.recentTabs,
        LEGACY_RECENT_TABS_STORAGE_KEY
      ]);
      scrollMemoryByTabId = normalizeScrollMemory(
        stored[TABWHEEL_STORAGE_KEYS.scrollMemory]
      );
      recentTabIdsByWindowId = normalizeRecentTabState(
        stored[TABWHEEL_STORAGE_KEYS.recentTabs] ?? stored[LEGACY_RECENT_TABS_STORAGE_KEY]
      );
    });
    async function getSettings() {
      if (settingsCache) return settingsCache;
      settingsCache = await loadTabWheelSettings();
      return settingsCache;
    }
    function updateSettingsCache(value) {
      settingsCache = normalizeTabWheelSettings(value);
    }
    async function persistScrollMemory() {
      scrollMemoryByTabId = trimScrollMemory(scrollMemoryByTabId);
      await import_webextension_polyfill3.default.storage.local.set({
        [TABWHEEL_STORAGE_KEYS.scrollMemory]: scrollMemoryByTabId
      });
    }
    function flushScrollMemorySave() {
      if (scrollMemorySaveTimer) {
        clearTimeout(scrollMemorySaveTimer);
        scrollMemorySaveTimer = null;
      }
      const resolvers = scrollMemorySaveResolvers;
      scrollMemorySaveResolvers = [];
      if (resolvers.length === 0) return scrollMemoryWriteChain.catch(() => {
      });
      scrollMemoryWriteChain = scrollMemoryWriteChain.catch(() => {
      }).then(() => persistScrollMemory());
      scrollMemoryWriteChain.then(() => {
        for (const pending of resolvers) pending.resolve();
      }).catch((error) => {
        for (const pending of resolvers) pending.reject(error);
      });
      return scrollMemoryWriteChain;
    }
    function saveScrollMemory() {
      const pendingSave = new Promise((resolve, reject) => {
        scrollMemorySaveResolvers.push({ resolve, reject });
      });
      if (scrollMemorySaveTimer) clearTimeout(scrollMemorySaveTimer);
      scrollMemorySaveTimer = setTimeout(() => {
        scrollMemorySaveTimer = null;
        void flushScrollMemorySave().catch(() => {
        });
      }, SCROLL_MEMORY_SAVE_DEBOUNCE_MS);
      return pendingSave;
    }
    function saveRecentTabState() {
      return recentTabStateWriteChain.enqueue(() => import_webextension_polyfill3.default.storage.local.set({
        [TABWHEEL_STORAGE_KEYS.recentTabs]: recentTabIdsByWindowId
      }));
    }
    function queryTabsSafe(queryInfo) {
      return import_webextension_polyfill3.default.tabs.query(queryInfo).catch(() => null);
    }
    async function queryActiveTab(windowId) {
      const [activeTab] = await queryTabsSafe(
        windowId != null ? { active: true, windowId } : { active: true, currentWindow: true }
      ) ?? [];
      return activeTab?.id != null && activeTab.windowId != null ? activeTab : null;
    }
    async function resolveActiveTab(tab, windowId) {
      const fallbackWindowId = windowId ?? tab?.windowId;
      if (tab?.id != null && tab.windowId != null) {
        try {
          const currentTab = await import_webextension_polyfill3.default.tabs.get(tab.id);
          if (currentTab?.id != null && currentTab.windowId != null && currentTab.active === true) {
            return currentTab;
          }
          return await queryActiveTab(currentTab?.windowId ?? fallbackWindowId);
        } catch (_) {
          return await queryActiveTab(fallbackWindowId);
        }
      }
      return await queryActiveTab(windowId);
    }
    async function resolveCurrentWindowId(windowId) {
      if (windowId != null) return windowId;
      const [activeTab] = await queryTabsSafe({ active: true, currentWindow: true }) ?? [];
      return activeTab?.windowId ?? null;
    }
    function invalidateWindowTabsCache(windowId) {
      if (windowId == null) {
        windowTabsCacheByWindowId.clear();
        collapsedTabGroupIdsCacheByWindowId.clear();
        return;
      }
      windowTabsCacheByWindowId.delete(windowId);
      collapsedTabGroupIdsCacheByWindowId.delete(windowId);
    }
    async function getWindowTabs(windowId) {
      const cached = windowTabsCacheByWindowId.get(windowId);
      if (cached && cached.expiresAt > Date.now()) return cached.tabs;
      const tabs = await queryTabsSafe({ windowId });
      if (!tabs) return [];
      windowTabsCacheByWindowId.set(windowId, {
        tabs,
        expiresAt: Date.now() + WINDOW_TABS_CACHE_TTL_MS
      });
      return tabs;
    }
    function markContentScriptAvailable(tab, url) {
      if (tab.id == null) return;
      contentScriptReadyUrlsByTabId.set(tab.id, url);
      contentScriptUnavailableUrlsByTabId.delete(tab.id);
    }
    function markContentScriptUnavailable(tab, ttlMs = CONTENT_SCRIPT_UNAVAILABLE_CACHE_TTL_MS) {
      if (tab.id == null) return;
      contentScriptReadyUrlsByTabId.delete(tab.id);
      const url = normalizePageUrl(tab.url);
      if (!url) return;
      contentScriptUnavailableUrlsByTabId.set(tab.id, {
        url,
        expiresAt: Date.now() + ttlMs
      });
    }
    function isContentScriptKnownUnavailable(tab) {
      if (tab.id == null) return false;
      const url = normalizePageUrl(tab.url);
      const entry = contentScriptUnavailableUrlsByTabId.get(tab.id);
      if (!url || !entry || entry.url !== url) return false;
      if (entry.expiresAt > Date.now()) return true;
      contentScriptUnavailableUrlsByTabId.delete(tab.id);
      return false;
    }
    async function getCollapsedTabGroupIds(windowId, tabs, settings) {
      if (!settings.skipHiddenTabs) return /* @__PURE__ */ new Set();
      if (!tabs.some((tab) => tab.groupId != null && tab.groupId !== -1)) return /* @__PURE__ */ new Set();
      const cached = collapsedTabGroupIdsCacheByWindowId.get(windowId);
      if (cached && cached.expiresAt > Date.now()) return cached.collapsedTabGroupIds;
      const tabGroupsApi = getBrowserTabGroupsApi();
      if (typeof tabGroupsApi?.query !== "function") return /* @__PURE__ */ new Set();
      const collapsedGroups = await tabGroupsApi.query({ windowId, collapsed: true }).catch(() => []);
      const collapsedTabGroupIds = new Set(
        collapsedGroups.filter((group) => group.collapsed === true && Number.isInteger(group.id)).map((group) => group.id)
      );
      collapsedTabGroupIdsCacheByWindowId.set(windowId, {
        collapsedTabGroupIds,
        expiresAt: Date.now() + WINDOW_TABS_CACHE_TTL_MS
      });
      return collapsedTabGroupIds;
    }
    async function getGestureEligibleTabs(tabs, settings, windowId, activeTab) {
      const collapsedTabGroupIds = await getCollapsedTabGroupIds(windowId, tabs, settings);
      const eligibleTabs = getEligibleTabs(
        tabs,
        settings,
        collapsedTabGroupIds,
        activeTab ? activeTab.groupId ?? -1 : null
      );
      return settings.skipRestrictedPages ? eligibleTabs.filter((tab) => !isContentScriptKnownUnavailable(tab)) : eligibleTabs;
    }
    function beginScrollRestore(tabId) {
      const token = ++scrollRestoreSerial;
      scrollRestoreTokensByTabId.set(tabId, token);
      return token;
    }
    function cancelScrollRestore(tabId) {
      if (tabId == null) return;
      scrollRestoreTokensByTabId.set(tabId, ++scrollRestoreSerial);
    }
    function isScrollRestoreCurrent(tabId, token) {
      return scrollRestoreTokensByTabId.get(tabId) === token;
    }
    function getActiveDiscardedWakeHold(windowId, activeTabId) {
      const hold = discardedWakeHoldByWindowId.get(windowId);
      if (!hold) return null;
      if (hold.tabId !== activeTabId || hold.expiresAt <= Date.now()) {
        discardedWakeHoldByWindowId.delete(windowId);
        return null;
      }
      return hold;
    }
    function setDiscardedWakeHold(tab) {
      if (tab.id == null || tab.windowId == null || tab.discarded !== true) return;
      discardedWakeHoldByWindowId.set(tab.windowId, {
        tabId: tab.id,
        expiresAt: Date.now() + DISCARDED_WAKE_HOLD_SAFETY_MS
      });
    }
    function clearDiscardedWakeHoldForTab(tabId) {
      for (const [windowId, hold] of discardedWakeHoldByWindowId) {
        if (hold.tabId === tabId) discardedWakeHoldByWindowId.delete(windowId);
      }
    }
    async function reconcileRecentTabs(windowId, tabs) {
      await ensureLoaded();
      const key = windowKey(windowId);
      const tabIds = new Set(tabs.map((tab) => tab.id).filter((tabId) => tabId != null));
      const current = recentTabIdsByWindowId[key] || [];
      const next = current.filter((tabId) => tabIds.has(tabId)).slice(0, MAX_RECENT_TABS);
      if (hasSameNumberList(current, next)) return;
      if (next.length > 0) recentTabIdsByWindowId[key] = next;
      else delete recentTabIdsByWindowId[key];
      await saveRecentTabState();
    }
    async function recordRecentTab(tabId, windowId) {
      try {
        await ensureLoaded();
        if (!Number.isInteger(tabId) || tabId <= 0 || !Number.isInteger(windowId) || windowId <= 0) return;
        const key = windowKey(windowId);
        const current = recentTabIdsByWindowId[key] || [];
        const next = [tabId, ...current.filter((candidate) => candidate !== tabId)].slice(0, MAX_RECENT_TABS);
        if (hasSameNumberList(current, next)) return;
        recentTabIdsByWindowId[key] = next;
        await saveRecentTabState();
      } catch (error) {
        console.warn("[TabWheel] Recent-tab recording failed:", error);
      }
    }
    async function executeContentScriptInTab(tabId, allFrames) {
      const runtimeBrowser = import_webextension_polyfill3.default;
      try {
        if (runtimeBrowser.scripting?.executeScript) {
          await runtimeBrowser.scripting.executeScript({
            target: { tabId, ...allFrames ? { allFrames: true } : {} },
            files: ["contentScript.js"],
            // Restored documents may never reach the default document_idle phase.
            injectImmediately: true
          });
          return true;
        }
        if (runtimeBrowser.tabs.executeScript) {
          await runtimeBrowser.tabs.executeScript(tabId, {
            file: "contentScript.js",
            runAt: "document_start",
            ...allFrames ? { allFrames: true } : {}
          });
          return true;
        }
      } catch (_) {
        return false;
      }
      return false;
    }
    async function injectContentScriptIntoTab(tab) {
      if (tab.id == null || tab.discarded === true || isPageGestureRestrictedUrl(tab.url)) return "skipped";
      if (await executeContentScriptInTab(tab.id, true)) return "injected";
      return await executeContentScriptInTab(tab.id, false) ? "injected" : "failed";
    }
    async function resetState() {
      await ensureLoaded();
      recentTabIdsByWindowId = {};
      scrollMemoryByTabId = {};
      updateSettingsCache(void 0);
      await import_webextension_polyfill3.default.storage.local.remove([
        TABWHEEL_STORAGE_KEYS.settings,
        TABWHEEL_STORAGE_KEYS.recentTabs,
        TABWHEEL_STORAGE_KEYS.scrollMemory
      ]).catch(() => {
      });
      return { ok: true };
    }
    async function activateExistingContentScripts() {
      const result = {
        attempted: 0,
        injected: 0,
        skipped: 0,
        failed: 0
      };
      const tabs = await import_webextension_polyfill3.default.tabs.query({});
      await Promise.all(tabs.map(async (tab) => {
        const activation = await injectContentScriptIntoTab(tab);
        if (activation === "skipped") {
          result.skipped += 1;
          return;
        }
        result.attempted += 1;
        if (activation === "injected") result.injected += 1;
        else result.failed += 1;
      }));
      return result;
    }
    async function applyToolbarBadgeForTab(tab) {
      if (tab?.id == null) return;
      const settings = await getSettings();
      await updateTabToolbarBadge(tab.id, tab.url, settings.showRestrictedBadge);
    }
    async function applyToolbarBadgeForTabId(tabId) {
      const tab = await import_webextension_polyfill3.default.tabs.get(tabId).catch(() => null);
      await applyToolbarBadgeForTab(tab);
    }
    async function ensureActiveTabContentScripts() {
      const windows = await import_webextension_polyfill3.default.windows.getAll().catch(() => []);
      await Promise.all(windows.map(async (win) => {
        if (win.id == null) return;
        const [activeTab] = await import_webextension_polyfill3.default.tabs.query({ active: true, windowId: win.id }).catch(() => []);
        if (!activeTab || activeTab.id == null) return;
        void applyToolbarBadgeForTab(activeTab).catch(() => {
        });
        if (isPageGestureRestrictedUrl(activeTab.url) || activeTab.discarded === true) return;
        if (contentScriptReadyUrlsByTabId.get(activeTab.id) === normalizePageUrl(activeTab.url)) return;
        if (await pingContentScript(activeTab)) return;
        const injection = await injectContentScriptIntoTab(activeTab);
        if (injection !== "injected") return;
        await waitForContentScriptReady(activeTab, GESTURE_CONTENT_SCRIPT_READY_RETRY_DELAYS_MS);
      }));
    }
    async function ensureContentScriptForActiveTab(tabId) {
      const tab = await import_webextension_polyfill3.default.tabs.get(tabId).catch(() => null);
      if (!tab || tab.id == null) return;
      if (isPageGestureRestrictedUrl(tab.url) || tab.discarded === true) return;
      if (contentScriptReadyUrlsByTabId.get(tab.id) === normalizePageUrl(tab.url)) return;
      if (await pingContentScript(tab)) return;
      const injection = await injectContentScriptIntoTab(tab);
      if (injection !== "injected") return;
      await resolveWithTimeout(
        waitForContentScriptReady(tab, GESTURE_CONTENT_SCRIPT_READY_RETRY_DELAYS_MS),
        GESTURE_TARGET_PROBE_TIMEOUT_MS,
        false
      ).catch(() => {
      });
    }
    async function pingContentScript(tab) {
      if (tab.id == null) return false;
      const url = normalizePageUrl(tab.url);
      if (!url) return false;
      try {
        await import_webextension_polyfill3.default.tabs.sendMessage(tab.id, { type: "TABWHEEL_PING" });
        markContentScriptAvailable(tab, url);
        return true;
      } catch (_) {
        contentScriptReadyUrlsByTabId.delete(tab.id);
        return false;
      }
    }
    async function waitForContentScriptReady(tab, retryDelaysMs = [0, 90, 240, 450, 800]) {
      for (const delay of retryDelaysMs) {
        if (delay > 0) await sleep(delay);
        if (await pingContentScript(tab)) return true;
      }
      return false;
    }
    async function getScroll(tabId) {
      try {
        return await import_webextension_polyfill3.default.tabs.sendMessage(tabId, { type: "GET_SCROLL" });
      } catch (_) {
        return null;
      }
    }
    async function resolveContentScriptStatus(tab) {
      if (!tab?.id) return "unavailable";
      if (isPageGestureRestrictedUrl(tab.url)) return "unavailable";
      if (isContentScriptKnownUnavailable(tab)) return "unavailable";
      const url = normalizePageUrl(tab.url);
      if (!url) return "unavailable";
      if (contentScriptReadyUrlsByTabId.get(tab.id) === url) return "ready";
      return await pingContentScript(tab) ? "ready" : "unavailable";
    }
    function markContentScriptReady(tab) {
      if (!tab?.id) return { ok: false, reason: "No sender tab" };
      if (isPageGestureRestrictedUrl(tab.url)) return { ok: false, reason: "Unsupported page" };
      const url = normalizePageUrl(tab.url);
      if (!url) return { ok: false, reason: "Unsupported page" };
      markContentScriptAvailable(tab, url);
      if (tab.active === true && tab.windowId != null) {
        activeTabIdsByWindowId.set(tab.windowId, tab.id);
        void recordRecentTab(tab.id, tab.windowId);
      }
      return { ok: true };
    }
    async function resolvePageGestureReadiness(tab, { recordFailure = true } = {}) {
      if (tab.id == null) return "unavailable";
      const tabId = tab.id;
      if (isPageGestureRestrictedUrl(tab.url)) {
        if (recordFailure) markContentScriptUnavailable(tab);
        return "unavailable";
      }
      const url = normalizePageUrl(tab.url);
      if (!url) return "unavailable";
      if (contentScriptReadyUrlsByTabId.get(tab.id) === url) {
        contentScriptUnavailableUrlsByTabId.delete(tab.id);
        return "ready";
      }
      const readiness = await resolveWithTimeout(
        (async () => {
          if (await pingContentScript(tab)) return "ready";
          const injection = await injectContentScriptIntoTab(tab);
          if (injection !== "injected") return "unavailable";
          const currentTab = await import_webextension_polyfill3.default.tabs.get(tabId).catch(() => tab);
          return await waitForContentScriptReady(currentTab, GESTURE_CONTENT_SCRIPT_READY_RETRY_DELAYS_MS) ? "ready" : "slow";
        })(),
        GESTURE_TARGET_PROBE_TIMEOUT_MS,
        "slow"
      );
      if (readiness === "unavailable" && recordFailure) markContentScriptUnavailable(tab);
      return readiness;
    }
    async function ensurePageGestureAvailable(tab, options2 = {}) {
      return await resolvePageGestureReadiness(tab, options2) === "ready";
    }
    async function restoreScroll(tab) {
      if (tab.id == null) return false;
      const settings = await getSettings();
      if (!settings.restorePagePosition) return false;
      const retryDelaysMs = tab.discarded === true ? DISCARDED_SCROLL_RESTORE_RETRY_DELAYS_MS : SCROLL_RESTORE_RETRY_DELAYS_MS;
      const restoreToken = beginScrollRestore(tab.id);
      const entry = scrollMemoryByTabId[tabKey(tab.id)];
      const currentUrl = normalizePageUrl(tab.url);
      if (!currentUrl || entry?.url !== currentUrl) return false;
      if (!entry) return false;
      for (const delay of retryDelaysMs) {
        if (!isScrollRestoreCurrent(tab.id, restoreToken)) return false;
        if (delay > 0) await sleep(delay);
        if (!isScrollRestoreCurrent(tab.id, restoreToken)) return false;
        try {
          await import_webextension_polyfill3.default.tabs.sendMessage(tab.id, {
            type: "SET_SCROLL",
            scrollX: entry.scrollX,
            scrollY: entry.scrollY,
            scrollRatioX: entry.scrollRatioX,
            scrollRatioY: entry.scrollRatioY,
            scrollWidth: entry.scrollWidth,
            scrollHeight: entry.scrollHeight,
            viewportWidth: entry.viewportWidth,
            viewportHeight: entry.viewportHeight
          });
          return true;
        } catch (_) {
        }
      }
      return false;
    }
    async function captureTabScroll(tab) {
      if (tab.id == null || tab.windowId == null) return;
      const url = normalizePageUrl(tab.url);
      if (!url) return;
      const scroll = await getScroll(tab.id);
      if (!scroll) return;
      const normalized = normalizeScrollData(scroll);
      scrollMemoryByTabId[tabKey(tab.id)] = buildScrollMemoryEntry(tab.id, tab.windowId, url, normalized);
      await saveScrollMemory();
    }
    function captureTabScrollUnlessWaking(tab, settings) {
      if (!settings.restorePagePosition) return;
      if (tab.id == null || tab.windowId == null) return;
      if (getActiveDiscardedWakeHold(tab.windowId, tab.id)) return;
      void captureTabScroll(tab).catch(() => {
      });
    }
    async function getOverview(tab, windowId) {
      await ensureLoaded();
      const settings = await getSettings();
      const onboarding = await loadTabWheelOnboardingState();
      const resolvedWindowId = await resolveCurrentWindowId(windowId ?? tab?.windowId);
      if (resolvedWindowId == null) {
        return {
          activeIndex: 0,
          tabCount: 0,
          contentScriptStatus: "unavailable",
          firstGestureCycleCompleted: onboarding.firstGestureCycleCompleted
        };
      }
      const activeTab = await resolveActiveTab(tab, resolvedWindowId);
      const tabs = await getWindowTabs(resolvedWindowId);
      await reconcileRecentTabs(resolvedWindowId, tabs);
      const eligibleTabs = await getGestureEligibleTabs(tabs, settings, resolvedWindowId, activeTab);
      const activeIndex = activeTab ? eligibleTabs.findIndex((candidate) => candidate.id === activeTab.id) : -1;
      const contentScriptStatus = await resolveContentScriptStatus(activeTab);
      return {
        activeIndex: activeIndex >= 0 ? activeIndex : 0,
        ...activeTab?.id != null ? { activeTabId: activeTab.id } : {},
        tabCount: eligibleTabs.length,
        contentScriptStatus,
        firstGestureCycleCompleted: onboarding.firstGestureCycleCompleted
      };
    }
    function resolveStripTargetTab(activeTab, candidateTabs, direction, wrapAround) {
      const targetIndex = resolveCycleTargetIndex(
        candidateTabs.map(getTabIndex),
        getTabIndex(activeTab),
        direction,
        wrapAround
      );
      return candidateTabs.find((tab) => getTabIndex(tab) === targetIndex) || null;
    }
    function resolveCycleTargetTab(activeTab, candidateTabs, direction, settings) {
      return resolveStripTargetTab(activeTab, candidateTabs, direction, settings.wrapAround);
    }
    async function resolveAvailableCycleTargetTab(activeTab, candidateTabs, direction, settings) {
      let remainingTabs = candidateTabs;
      const maxAttempts = Math.min(candidateTabs.length, MAX_GESTURE_PROBE_ATTEMPTS);
      for (let attempts = 0; attempts < maxAttempts; attempts += 1) {
        const targetTab = resolveCycleTargetTab(activeTab, remainingTabs, direction, settings);
        if (!targetTab?.id || targetTab.id === activeTab.id) return null;
        if (targetTab.discarded === true) return targetTab;
        if (!settings.skipRestrictedPages) return targetTab;
        if (await resolvePageGestureReadiness(targetTab) !== "unavailable") return targetTab;
        remainingTabs = remainingTabs.filter((candidate) => candidate.id !== targetTab.id);
      }
      return null;
    }
    function collectNeighborCandidateTabs(originTab, candidateTabs, settings) {
      const neighborTabs = [];
      const seenTabIds = /* @__PURE__ */ new Set();
      if (originTab.id != null) seenTabIds.add(originTab.id);
      for (const direction of ["next", "prev"]) {
        let cursorTab = originTab;
        for (let step = 0; step < NEIGHBOR_PREPROBE_DEPTH; step += 1) {
          const neighborTab = resolveCycleTargetTab(cursorTab, candidateTabs, direction, settings);
          if (neighborTab?.id == null || seenTabIds.has(neighborTab.id)) break;
          seenTabIds.add(neighborTab.id);
          neighborTabs.push(neighborTab);
          cursorTab = neighborTab;
        }
      }
      return neighborTabs;
    }
    function beginNeighborWarmupGeneration(windowId) {
      const generation = (neighborWarmupGenerationByWindowId.get(windowId) ?? 0) + 1;
      neighborWarmupGenerationByWindowId.set(windowId, generation);
      return generation;
    }
    function isNeighborWarmupCurrent(windowId, generation) {
      return neighborWarmupGenerationByWindowId.get(windowId) === generation;
    }
    function isNeighborRecentlyPreprobed(tabId) {
      const expiresAt = neighborPreprobedUntilByTabId.get(tabId);
      if (expiresAt == null) return false;
      if (expiresAt > Date.now()) return true;
      neighborPreprobedUntilByTabId.delete(tabId);
      return false;
    }
    function shouldWarmNeighborTab(tab) {
      if (tab.id == null || tab.discarded === true) return false;
      if (neighborWarmupTabIds.has(tab.id)) return false;
      if (isNeighborRecentlyPreprobed(tab.id)) return false;
      if (isContentScriptKnownUnavailable(tab)) return false;
      const url = normalizePageUrl(tab.url);
      if (!url) return false;
      return contentScriptReadyUrlsByTabId.get(tab.id) !== url;
    }
    async function warmNeighborReadiness(originTab, candidateTabs, settings) {
      if (!settings.skipRestrictedPages) return;
      const windowId = originTab.windowId;
      if (windowId == null) return;
      const generation = beginNeighborWarmupGeneration(windowId);
      for (const neighborTab of collectNeighborCandidateTabs(originTab, candidateTabs, settings)) {
        if (!isNeighborWarmupCurrent(windowId, generation)) return;
        const neighborTabId = neighborTab.id;
        if (neighborTabId == null || !shouldWarmNeighborTab(neighborTab)) continue;
        neighborWarmupTabIds.add(neighborTabId);
        let didBecomeReady = false;
        try {
          didBecomeReady = await ensurePageGestureAvailable(neighborTab, { recordFailure: false });
        } finally {
          neighborWarmupTabIds.delete(neighborTabId);
        }
        if (didBecomeReady) continue;
        neighborPreprobedUntilByTabId.set(
          neighborTabId,
          Date.now() + NEIGHBOR_PREPROBE_RETRY_COOLDOWN_MS
        );
      }
    }
    async function activateTab(targetTab, options2 = {}) {
      if (targetTab.id == null) return false;
      const didActivate = await import_webextension_polyfill3.default.tabs.update(targetTab.id, { active: true }).then(() => true).catch(() => false);
      if (!didActivate) return false;
      setDiscardedWakeHold(targetTab);
      if (targetTab.windowId != null) {
        await recordRecentTab(targetTab.id, targetTab.windowId);
      }
      if (options2.restoreScrollAsync === true) {
        void restoreScroll(targetTab).catch(() => {
        });
        return true;
      }
      await restoreScroll(targetTab);
      return true;
    }
    function runRawSerializedWindowTask(tab, windowId, task) {
      return windowGestureTaskQueue.run(
        windowId ?? tab?.windowId ?? FALLBACK_CYCLE_LOCK_WINDOW_ID,
        task
      );
    }
    async function runSerializedWindowTask(tab, windowId, task) {
      const resolvedWindowId = windowId ?? tab?.windowId ?? FALLBACK_CYCLE_LOCK_WINDOW_ID;
      const dragTail = tabDragTailsByWindowId.get(resolvedWindowId);
      if (dragTail) await dragTail;
      return await runRawSerializedWindowTask(tab, windowId, task);
    }
    async function waitForTabDrag(tab) {
      if (tab?.windowId == null) return;
      const dragTail = tabDragTailsByWindowId.get(tab.windowId);
      if (dragTail) await dragTail;
    }
    function releaseTabDragSession(gestureId) {
      const session = tabDragSessionsById.get(gestureId);
      if (!session) return;
      if (session.timeoutId != null) clearTimeout(session.timeoutId);
      tabDragSessionsById.delete(gestureId);
      session.release();
    }
    function refreshTabDragSessionTimeout(session) {
      if (session.timeoutId != null) clearTimeout(session.timeoutId);
      session.timeoutId = setTimeout(
        () => releaseTabDragSession(session.gestureId),
        TAB_DRAG_SESSION_TIMEOUT_MS
      );
    }
    async function beginTabDrag(gestureId, tab) {
      if (!gestureId || tab?.id == null || tab.windowId == null) {
        return { ok: false, reason: "No active tab" };
      }
      const existing = tabDragSessionsById.get(gestureId);
      if (existing) {
        if (existing.tabId !== tab.id || existing.windowId !== tab.windowId) {
          return { ok: false, reason: "Invalid drag session" };
        }
        await existing.ready;
        if (tabDragSessionsById.get(gestureId) !== existing) {
          return { ok: false, reason: "Drag session expired" };
        }
        refreshTabDragSessionTimeout(existing);
        return { ok: true };
      }
      const windowId = tab.windowId;
      const previousTail = tabDragTailsByWindowId.get(windowId) ?? Promise.resolve();
      let releaseOwnedQueue = () => {
      };
      const ownedQueue = new Promise((resolve) => {
        releaseOwnedQueue = resolve;
      });
      let wasReleased = false;
      const release = () => {
        if (wasReleased) return;
        wasReleased = true;
        releaseOwnedQueue();
      };
      const dragTail = previousTail.then(() => ownedQueue);
      tabDragTailsByWindowId.set(windowId, dragTail);
      void dragTail.then(() => {
        if (tabDragTailsByWindowId.get(windowId) === dragTail) {
          tabDragTailsByWindowId.delete(windowId);
        }
      });
      const ready = (async () => {
        await previousTail;
        await runRawSerializedWindowTask(tab, windowId, async () => {
        });
      })();
      const session = {
        gestureId,
        tabId: tab.id,
        windowId,
        ready,
        release,
        timeoutId: null
      };
      tabDragSessionsById.set(gestureId, session);
      await ready;
      if (tabDragSessionsById.get(gestureId) !== session) {
        return { ok: false, reason: "Drag session expired" };
      }
      refreshTabDragSessionTimeout(session);
      return { ok: true };
    }
    async function endTabDrag(gestureId, tab) {
      const session = tabDragSessionsById.get(gestureId);
      if (!session) return { ok: true };
      if (tab?.id !== session.tabId) {
        return { ok: false, reason: "Invalid drag session" };
      }
      releaseTabDragSession(gestureId);
      return { ok: true };
    }
    async function recordFirstGestureCycle() {
      const state = await loadTabWheelOnboardingState();
      if (state.firstGestureCycleCompleted) return;
      await saveTabWheelOnboardingState({
        ...state,
        firstGestureCycleCompleted: true
      });
    }
    async function cycleUnlocked(direction, source, tab, windowId) {
      await ensureLoaded();
      const activeTab = await resolveActiveTab(tab, windowId);
      if (!activeTab?.id || activeTab.windowId == null) {
        return { ok: false, reason: "No active tab" };
      }
      const settings = await getSettings();
      const tabs = await getWindowTabs(activeTab.windowId);
      await reconcileRecentTabs(activeTab.windowId, tabs);
      const eligibleTabs = await getGestureEligibleTabs(tabs, settings, activeTab.windowId, activeTab);
      if (eligibleTabs.length === 0) return { ok: false, reason: "No eligible tabs" };
      const candidateTabs = eligibleTabs;
      const targetTab = await resolveAvailableCycleTargetTab(activeTab, candidateTabs, direction, settings);
      if (!targetTab?.id) {
        return { ok: false, reason: "Edge of tab list" };
      }
      cancelScrollRestore(activeTab.id);
      captureTabScrollUnlessWaking(activeTab, settings);
      const didActivate = await activateTab(targetTab, { restoreScrollAsync: true });
      if (!didActivate) return { ok: false, reason: "Tab no longer exists" };
      void warmNeighborReadiness(targetTab, candidateTabs, settings).catch(() => {
      });
      if (source === "gesture") {
        void recordFirstGestureCycle().catch(() => {
        });
      }
      return { ok: true, tabId: targetTab.id };
    }
    async function cycle(direction, source, tab, windowId) {
      return await runSerializedWindowTask(
        tab,
        windowId,
        () => cycleUnlocked(direction, source, tab, windowId)
      );
    }
    function getRecentCandidateTabs(windowId, tabs, activeTabId) {
      const tabsById = /* @__PURE__ */ new Map();
      for (const candidate of tabs) {
        if (candidate.id != null) tabsById.set(candidate.id, candidate);
      }
      return (recentTabIdsByWindowId[windowKey(windowId)] || []).filter((tabId) => tabId !== activeTabId).map((tabId) => tabsById.get(tabId)).filter((candidate) => candidate != null);
    }
    async function openNativeNewTab(tab, windowId) {
      return await runSerializedWindowTask(tab, windowId, async () => {
        await ensureLoaded();
        const activeTab = await resolveActiveTab(tab, windowId);
        if (!activeTab?.id || activeTab.windowId == null) {
          return { ok: false, reason: "No active tab" };
        }
        const createdTab = await import_webextension_polyfill3.default.tabs.create({
          active: true,
          windowId: activeTab.windowId,
          index: getTabIndex(activeTab) + 1,
          openerTabId: activeTab.id
        }).catch(() => null);
        if (!createdTab) return { ok: false, reason: "New tab unavailable" };
        invalidateWindowTabsCache(activeTab.windowId);
        if (createdTab.id != null && createdTab.windowId != null) {
          await recordRecentTab(createdTab.id, createdTab.windowId);
        }
        return { ok: true, tabId: createdTab.id };
      });
    }
    async function activateMostRecentTab(tab, windowId) {
      return await runSerializedWindowTask(tab, windowId, async () => {
        await ensureLoaded();
        const activeTab = await resolveActiveTab(tab, windowId);
        if (!activeTab?.id || activeTab.windowId == null) {
          return { ok: false, reason: "No active tab" };
        }
        const tabs = await getWindowTabs(activeTab.windowId);
        await reconcileRecentTabs(activeTab.windowId, tabs);
        const settings = await getSettings();
        for (const targetTab of getRecentCandidateTabs(activeTab.windowId, tabs, activeTab.id)) {
          cancelScrollRestore(activeTab.id);
          captureTabScrollUnlessWaking(activeTab, settings);
          if (await activateTab(targetTab, { restoreScrollAsync: true })) {
            return { ok: true, tabId: targetTab.id };
          }
        }
        return { ok: false, reason: "No recent tab" };
      });
    }
    async function closeCurrentTabAndActivateRecent(tab, windowId) {
      return await runSerializedWindowTask(tab, windowId, async () => {
        await ensureLoaded();
        const activeTab = await resolveActiveTab(tab, windowId);
        if (!activeTab?.id || activeTab.windowId == null) {
          return { ok: false, reason: "No active tab" };
        }
        const tabs = await getWindowTabs(activeTab.windowId);
        await reconcileRecentTabs(activeTab.windowId, tabs);
        let activatedTabId;
        cancelScrollRestore(activeTab.id);
        for (const targetTab of getRecentCandidateTabs(activeTab.windowId, tabs, activeTab.id)) {
          if (await activateTab(targetTab, { restoreScrollAsync: true })) {
            activatedTabId = targetTab.id;
            break;
          }
        }
        const didClose = await import_webextension_polyfill3.default.tabs.remove(activeTab.id).then(() => true).catch(() => false);
        invalidateWindowTabsCache(activeTab.windowId);
        if (!didClose) return { ok: false, reason: "Close tab failed" };
        return { ok: true, tabId: activatedTabId };
      });
    }
    async function duplicateTab(tab, windowId) {
      return await runSerializedWindowTask(tab, windowId, async () => {
        await ensureLoaded();
        const activeTab = await resolveActiveTab(tab, windowId);
        if (!activeTab?.id || activeTab.windowId == null) {
          return { ok: false, reason: "No active tab" };
        }
        const duplicatedTab = await import_webextension_polyfill3.default.tabs.duplicate(activeTab.id).catch(() => null);
        if (!duplicatedTab?.id) return { ok: false, reason: "Duplicate unavailable" };
        const activatedTab = await import_webextension_polyfill3.default.tabs.update(duplicatedTab.id, { active: true }).catch(() => null);
        if (!activatedTab) return { ok: false, reason: "Duplicate unavailable" };
        invalidateWindowTabsCache(activeTab.windowId);
        await recordRecentTab(duplicatedTab.id, duplicatedTab.windowId ?? activeTab.windowId);
        return { ok: true, tabId: duplicatedTab.id };
      });
    }
    async function moveCurrentTabUnlocked(direction, tab) {
      await ensureLoaded();
      if (tab?.id == null) {
        return { ok: false, moved: false, reason: "No active tab" };
      }
      const activeTab = await import_webextension_polyfill3.default.tabs.get(tab.id).catch(() => null);
      if (!activeTab?.id || activeTab.windowId == null || activeTab.active !== true) {
        return { ok: false, moved: false, reason: "Tab changed" };
      }
      const tabs = await getWindowTabs(activeTab.windowId);
      const targetIndex = resolveTabDragTargetIndex(activeTab, tabs, direction);
      if (targetIndex == null) {
        return { ok: true, moved: false, tabId: activeTab.id, index: activeTab.index };
      }
      const movedResult = await import_webextension_polyfill3.default.tabs.move(activeTab.id, { index: targetIndex }).catch(() => null);
      const movedTab = resolveMovedTabResult(movedResult, activeTab.id);
      if (!movedTab) {
        return { ok: false, moved: false, reason: "Tab move failed" };
      }
      invalidateWindowTabsCache(activeTab.windowId);
      return {
        ok: true,
        moved: true,
        tabId: movedTab.id,
        index: movedTab.index
      };
    }
    async function moveCurrentTab(direction, tab, gestureId) {
      const session = gestureId ? tabDragSessionsById.get(gestureId) : void 0;
      if (!session || tab?.id !== session.tabId || tab.windowId !== session.windowId) {
        if (session && tab?.id === session.tabId) releaseTabDragSession(session.gestureId);
        return { ok: false, moved: false, reason: "Drag session expired" };
      }
      refreshTabDragSessionTimeout(session);
      await session.ready;
      return await runRawSerializedWindowTask(
        tab,
        session.windowId,
        () => moveCurrentTabUnlocked(direction, tab)
      );
    }
    async function refreshCurrentTab(tab, windowId) {
      await ensureLoaded();
      const activeTab = await resolveActiveTab(tab, windowId);
      if (!activeTab?.id || activeTab.windowId == null) {
        return {
          ok: false,
          reason: "No active tab",
          contentScriptStatus: "unavailable"
        };
      }
      if (isPageGestureRestrictedUrl(activeTab.url)) {
        markContentScriptUnavailable(activeTab);
        return {
          ok: false,
          reason: "TabWheel cannot run on this page.",
          overview: await getOverview(activeTab, activeTab.windowId),
          contentScriptStatus: "unavailable"
        };
      }
      const wasReady = await pingContentScript(activeTab);
      const injection = await injectContentScriptIntoTab(activeTab);
      if (injection !== "injected") {
        const overview2 = await getOverview(activeTab, activeTab.windowId);
        if (wasReady || overview2.contentScriptStatus === "ready") {
          return {
            ok: true,
            overview: overview2,
            contentScriptStatus: overview2.contentScriptStatus,
            injected: false
          };
        }
        markContentScriptUnavailable(activeTab);
        return {
          ok: false,
          reason: "TabWheel cannot run on this page.",
          overview: overview2,
          contentScriptStatus: overview2.contentScriptStatus,
          injected: false
        };
      }
      const currentTab = await import_webextension_polyfill3.default.tabs.get(activeTab.id).catch(() => activeTab);
      const isReady = await waitForContentScriptReady(currentTab);
      const overview = await getOverview(currentTab, activeTab.windowId);
      if (!isReady || overview.contentScriptStatus !== "ready") {
        markContentScriptUnavailable(currentTab);
        return {
          ok: false,
          reason: "TabWheel refresh failed",
          overview,
          contentScriptStatus: overview.contentScriptStatus,
          injected: true
        };
      }
      return {
        ok: true,
        overview,
        contentScriptStatus: "ready",
        injected: true
      };
    }
    async function saveScrollPosition(tabId, windowId, rawUrl, scrollData) {
      await ensureLoaded();
      const settings = await getSettings();
      if (!settings.restorePagePosition) return { ok: true };
      const url = normalizePageUrl(rawUrl);
      if (!url) return { ok: false, reason: "Unsupported page" };
      const scroll = normalizeScrollData(scrollData);
      const key = tabKey(tabId);
      const existing = scrollMemoryByTabId[key];
      if (existing?.url === url && existing.scrollX === scroll.scrollX && existing.scrollY === scroll.scrollY && existing.scrollRatioX === scroll.scrollRatioX && existing.scrollRatioY === scroll.scrollRatioY && existing.scrollWidth === scroll.scrollWidth && existing.scrollHeight === scroll.scrollHeight && existing.viewportWidth === scroll.viewportWidth && existing.viewportHeight === scroll.viewportHeight) {
        return { ok: true };
      }
      scrollMemoryByTabId[key] = buildScrollMemoryEntry(tabId, windowId, url, scroll);
      await saveScrollMemory();
      return { ok: true };
    }
    function registerLifecycleListeners() {
      import_webextension_polyfill3.default.runtime.onInstalled.addListener((details) => {
        if (details.reason !== "install" && details.reason !== "update") return;
        void migrationReady2.catch(() => {
        }).then(async () => {
          void activateExistingContentScripts().then(ensureActiveTabContentScripts).catch((error) => {
            console.warn("[TabWheel] install-time content script activation failed:", error);
          });
          const previousMajor = Number(details.previousVersion?.split(".")[0] || 0);
          if (details.reason === "install" || details.reason === "update" && previousMajor < 4) {
            await import_webextension_polyfill3.default.tabs.create({
              url: import_webextension_polyfill3.default.runtime.getURL("onboarding/onboarding.html"),
              active: true
            }).catch((error) => {
              console.warn("[TabWheel] onboarding page could not be opened:", error);
            });
          }
        });
      });
      import_webextension_polyfill3.default.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== "local") return;
        const settingsChange = changes[TABWHEEL_STORAGE_KEYS.settings];
        if (!settingsChange) return;
        const previousSettings = normalizeTabWheelSettings(settingsChange.oldValue);
        const nextSettings = normalizeTabWheelSettings(settingsChange.newValue);
        updateSettingsCache(settingsChange.newValue);
        if (previousSettings.restorePagePosition && !nextSettings.restorePagePosition) {
          scrollMemoryByTabId = {};
          void import_webextension_polyfill3.default.storage.local.remove(TABWHEEL_STORAGE_KEYS.scrollMemory).catch(() => {
          });
        }
      });
      import_webextension_polyfill3.default.tabs.onCreated.addListener((createdTab) => {
        invalidateWindowTabsCache(createdTab.windowId);
      });
      import_webextension_polyfill3.default.tabs.onActivated.addListener((activeInfo) => {
        const previousTabId = activeTabIdsByWindowId.get(activeInfo.windowId);
        activeTabIdsByWindowId.set(activeInfo.windowId, activeInfo.tabId);
        const wakeHold = discardedWakeHoldByWindowId.get(activeInfo.windowId);
        if (wakeHold && wakeHold.tabId !== activeInfo.tabId) discardedWakeHoldByWindowId.delete(activeInfo.windowId);
        if (previousTabId != null && previousTabId !== activeInfo.tabId) {
          cancelScrollRestore(previousTabId);
        }
        void recordRecentTab(activeInfo.tabId, activeInfo.windowId);
        void ensureContentScriptForActiveTab(activeInfo.tabId).catch(() => {
        });
        void applyToolbarBadgeForTabId(activeInfo.tabId).catch(() => {
        });
      });
      import_webextension_polyfill3.default.tabs.onMoved.addListener((_tabId, moveInfo) => {
        invalidateWindowTabsCache(moveInfo.windowId);
      });
      import_webextension_polyfill3.default.tabs.onAttached.addListener((_tabId, attachInfo) => {
        invalidateWindowTabsCache(attachInfo.newWindowId);
      });
      import_webextension_polyfill3.default.tabs.onDetached.addListener((tabId, detachInfo) => {
        for (const session of tabDragSessionsById.values()) {
          if (session.tabId === tabId) releaseTabDragSession(session.gestureId);
        }
        invalidateWindowTabsCache(detachInfo.oldWindowId);
      });
      import_webextension_polyfill3.default.tabs.onRemoved.addListener(async (tabId, removeInfo) => {
        for (const session of tabDragSessionsById.values()) {
          if (session.tabId === tabId) releaseTabDragSession(session.gestureId);
        }
        invalidateWindowTabsCache(removeInfo?.windowId);
        await ensureLoaded();
        delete scrollMemoryByTabId[tabKey(tabId)];
        contentScriptReadyUrlsByTabId.delete(tabId);
        contentScriptUnavailableUrlsByTabId.delete(tabId);
        neighborPreprobedUntilByTabId.delete(tabId);
        scrollRestoreTokensByTabId.delete(tabId);
        clearDiscardedWakeHoldForTab(tabId);
        forgetToolbarBadgeTab(tabId);
        for (const [windowId, activeTabId] of activeTabIdsByWindowId) {
          if (activeTabId === tabId) activeTabIdsByWindowId.delete(windowId);
        }
        let recentTabsChanged = false;
        for (const [key, tabIds] of Object.entries(recentTabIdsByWindowId)) {
          const nextTabIds = tabIds.filter((candidate) => candidate !== tabId);
          if (nextTabIds.length === tabIds.length) continue;
          recentTabsChanged = true;
          if (nextTabIds.length > 0) recentTabIdsByWindowId[key] = nextTabIds;
          else delete recentTabIdsByWindowId[key];
        }
        if (recentTabsChanged) await saveRecentTabState();
        await saveScrollMemory();
      });
      import_webextension_polyfill3.default.tabs.onUpdated.addListener((tabId, changeInfo, updatedTab) => {
        if (changeInfo.url || changeInfo.pinned != null || changeInfo.hidden != null || changeInfo.groupId != null) {
          invalidateWindowTabsCache(updatedTab?.windowId);
        }
        if (changeInfo.status === "complete") {
          clearDiscardedWakeHoldForTab(tabId);
        }
        if (changeInfo.url) {
          contentScriptReadyUrlsByTabId.delete(tabId);
          contentScriptUnavailableUrlsByTabId.delete(tabId);
          cancelScrollRestore(tabId);
        }
        if (changeInfo.url || changeInfo.status === "complete") {
          if (updatedTab) void applyToolbarBadgeForTab(updatedTab).catch(() => {
          });
          else void applyToolbarBadgeForTabId(tabId).catch(() => {
          });
        }
      });
      const tabGroupsApi = getBrowserTabGroupsApi();
      const invalidateTabGroupWindow = (group) => {
        invalidateWindowTabsCache(group.windowId);
      };
      const addTabGroupInvalidationListener = (event) => {
        if (typeof event?.addListener === "function") event.addListener(invalidateTabGroupWindow);
      };
      addTabGroupInvalidationListener(tabGroupsApi?.onCreated);
      addTabGroupInvalidationListener(tabGroupsApi?.onRemoved);
      addTabGroupInvalidationListener(tabGroupsApi?.onUpdated);
      import_webextension_polyfill3.default.windows.onRemoved.addListener((windowId) => {
        for (const session of tabDragSessionsById.values()) {
          if (session.windowId === windowId) releaseTabDragSession(session.gestureId);
        }
        void (async () => {
          await ensureLoaded();
          invalidateWindowTabsCache(windowId);
          delete recentTabIdsByWindowId[windowKey(windowId)];
          activeTabIdsByWindowId.delete(windowId);
          discardedWakeHoldByWindowId.delete(windowId);
          neighborWarmupGenerationByWindowId.delete(windowId);
          for (const [key, entry] of Object.entries(scrollMemoryByTabId)) {
            if (entry.windowId === windowId) {
              delete scrollMemoryByTabId[key];
              scrollRestoreTokensByTabId.delete(entry.tabId);
            }
          }
          await saveRecentTabState();
          await saveScrollMemory();
        })();
      });
      import_webextension_polyfill3.default.runtime.onStartup.addListener(async () => {
        try {
          await ensureLoaded();
          scrollMemoryByTabId = trimScrollMemory(scrollMemoryByTabId);
          recentTabIdsByWindowId = {};
          windowTabsCacheByWindowId.clear();
          collapsedTabGroupIdsCacheByWindowId.clear();
          contentScriptReadyUrlsByTabId.clear();
          contentScriptUnavailableUrlsByTabId.clear();
          neighborPreprobedUntilByTabId.clear();
          neighborWarmupGenerationByWindowId.clear();
          scrollRestoreTokensByTabId.clear();
          activeTabIdsByWindowId.clear();
          discardedWakeHoldByWindowId.clear();
          await saveScrollMemory();
          await import_webextension_polyfill3.default.storage.local.remove(TABWHEEL_STORAGE_KEYS.recentTabs);
        } catch (error) {
          console.warn("[TabWheel] startup housekeeping failed:", error);
        }
        const activateRestoredTabs = async () => {
          await activateExistingContentScripts();
          await ensureActiveTabContentScripts();
        };
        const immediateActivation = activateRestoredTabs().catch((error) => {
          console.warn("[TabWheel] startup content script activation failed:", error);
        });
        const delayedActivation = (async () => {
          try {
            await sleep(2e3);
            await activateRestoredTabs();
          } catch (error) {
            console.warn("[TabWheel] delayed startup content script activation failed:", error);
          }
        })();
        await Promise.all([immediateActivation, delayedActivation]);
      });
      void ensureActiveTabContentScripts().catch(() => {
      });
    }
    return {
      ensureLoaded,
      activateExistingContentScripts,
      getOverview,
      cycle,
      openNativeNewTab,
      activateMostRecentTab,
      closeCurrentTabAndActivateRecent,
      duplicateTab,
      beginTabDrag,
      moveCurrentTab,
      endTabDrag,
      waitForTabDrag,
      refreshCurrentTab,
      resetState,
      saveScrollPosition,
      markContentScriptReady,
      registerLifecycleListeners
    };
  }

  // src/lib/backgroundRuntime/handlers/tabWheelMessageHandler.ts
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());

  // src/lib/backgroundRuntime/handlers/runtimeRouter.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());
  var UNHANDLED = Symbol("background-runtime-unhandled");
  function registerRuntimeMessageRouter(handlers) {
    import_webextension_polyfill4.default.runtime.onMessage.addListener(async (receivedMessage, sender) => {
      if (typeof receivedMessage !== "object" || receivedMessage === null) return null;
      const message = receivedMessage;
      for (const handler of handlers) {
        try {
          const result = await handler(message, sender);
          if (result !== UNHANDLED) {
            return result;
          }
        } catch (error) {
          console.error("[TabWheel] Runtime message handler failed:", error);
          if (message.type === "TABWHEEL_GET_OVERVIEW") {
            throw error;
          }
          return { ok: false, reason: "Internal error" };
        }
      }
      return null;
    });
  }

  // src/lib/backgroundRuntime/handlers/tabWheelMessageHandler.ts
  async function openOptionsPage() {
    try {
      await import_webextension_polyfill5.default.runtime.openOptionsPage();
      return { ok: true };
    } catch (_) {
      return { ok: false, reason: "Settings unavailable" };
    }
  }
  function createTabWheelMessageHandler(domain) {
    return async (message, sender) => {
      switch (message.type) {
        case "TABWHEEL_CONTENT_READY":
          return domain.markContentScriptReady(sender.tab);
        case "TABWHEEL_CYCLE":
          return await domain.cycle(message.direction, message.source, sender.tab, message.windowId);
        case "TABWHEEL_REFRESH_CURRENT_TAB":
          return await domain.refreshCurrentTab(sender.tab, message.windowId ?? sender.tab?.windowId);
        case "TABWHEEL_GET_OVERVIEW":
          return await domain.getOverview(sender.tab, message.windowId ?? sender.tab?.windowId);
        case "TABWHEEL_OPEN_NATIVE_NEW_TAB":
          return await domain.openNativeNewTab(sender.tab, message.windowId);
        case "TABWHEEL_ACTIVATE_MOST_RECENT_TAB":
          return await domain.activateMostRecentTab(sender.tab, message.windowId);
        case "TABWHEEL_CLOSE_CURRENT_TAB_AND_ACTIVATE_RECENT":
          return await domain.closeCurrentTabAndActivateRecent(sender.tab, message.windowId);
        case "TABWHEEL_DUPLICATE_TAB":
          return await domain.duplicateTab(sender.tab, message.windowId);
        case "TABWHEEL_BEGIN_TAB_DRAG":
          return await domain.beginTabDrag(message.gestureId, sender.tab);
        case "TABWHEEL_MOVE_CURRENT_TAB":
          return await domain.moveCurrentTab(message.direction, sender.tab, message.gestureId);
        case "TABWHEEL_END_TAB_DRAG":
          return await domain.endTabDrag(message.gestureId, sender.tab);
        case "TABWHEEL_SAVE_SCROLL_POSITION": {
          const tabId = sender.tab?.id;
          const windowId = sender.tab?.windowId;
          if (tabId == null || windowId == null) return { ok: false, reason: "No sender tab" };
          return await domain.saveScrollPosition(
            tabId,
            windowId,
            sender.tab?.url,
            message
          );
        }
        case "TABWHEEL_OPEN_OPTIONS":
          await domain.waitForTabDrag(sender.tab);
          return await openOptionsPage();
        case "TABWHEEL_RESET_STATE":
          return await domain.resetState();
        case "TABWHEEL_ACTIVATE_CONTENT_SCRIPTS":
          return await domain.activateExistingContentScripts();
        default:
          return UNHANDLED;
      }
    };
  }

  // src/lib/common/utils/storageMigrationsRuntime.ts
  var import_webextension_polyfill6 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/storageMigrations.ts
  var STORAGE_SCHEMA_VERSION_KEY = "storageSchemaVersion";
  var TABWHEEL_SETTINGS_KEY = "tabWheelSettings";
  var TABWHEEL_SCROLL_MEMORY_KEY = "tabWheelScrollMemory";
  var TABWHEEL_MRU_STATE_KEY = "tabWheelMruState";
  var TABWHEEL_RECENT_TABS_KEY = "tabWheelRecentTabs";
  var TABWHEEL_SEARCH_HISTORY_KEY = "tabWheelSearchHistory";
  var TABWHEEL_LEGACY_TAGGED_TABS_KEY = "tabWheelTaggedTabs";
  var TABWHEEL_WHEEL_LIST_KEY = "tabWheelWheelList";
  var TABWHEEL_DEVICE_PROFILE_KEY = "tabWheelDeviceProfile";
  var STORAGE_SCHEMA_VERSION = 19;
  function readSchemaVersion(storage) {
    const numeric = Number(storage[STORAGE_SCHEMA_VERSION_KEY]);
    if (!Number.isFinite(numeric)) return 0;
    const rounded = Math.floor(numeric);
    return rounded > 0 ? rounded : 0;
  }
  function isFreshInstallSnapshot(storage) {
    const keys = Object.keys(storage);
    return keys.length === 0 || keys.every((key) => key === STORAGE_SCHEMA_VERSION_KEY);
  }
  function isStorageSchemaVersionCurrent(rawVersion) {
    return Number(rawVersion) === STORAGE_SCHEMA_VERSION;
  }
  function createCurrentVersionMigrationResult() {
    return {
      fromVersion: STORAGE_SCHEMA_VERSION,
      toVersion: STORAGE_SCHEMA_VERSION,
      changed: false,
      migratedStorage: {}
    };
  }
  function hasKey(storage, key) {
    return Object.prototype.hasOwnProperty.call(storage, key);
  }
  function deleteKey(storage, key) {
    if (!hasKey(storage, key)) return false;
    delete storage[key];
    return true;
  }
  function enableEditableFieldsByDefault(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    if (typeof settings !== "object" || settings === null || Array.isArray(settings)) {
      storage[TABWHEEL_SETTINGS_KEY] = { allowGesturesInEditableFields: true };
      return true;
    }
    const nextSettings = {
      ...settings,
      allowGesturesInEditableFields: true
    };
    const changed = settings.allowGesturesInEditableFields !== true;
    storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return changed;
  }
  function deleteSettingKey(storage, key) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    if (typeof settings !== "object" || settings === null || Array.isArray(settings)) return false;
    const nextSettings = { ...settings };
    if (!deleteKey(nextSettings, key)) return false;
    storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return true;
  }
  function migrateTabWheelSettings(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    const hasExistingSettings = typeof settings === "object" && settings !== null && !Array.isArray(settings);
    const nextSettings = hasExistingSettings ? { ...settings } : {};
    let changed = !hasExistingSettings;
    if (nextSettings.cycleScope !== "general" && nextSettings.cycleScope !== "mru") {
      nextSettings.cycleScope = "general";
      changed = true;
    }
    if (typeof nextSettings.skipRestrictedPages !== "boolean") {
      nextSettings.skipRestrictedPages = true;
      changed = true;
    }
    if (typeof nextSettings.openNativeNewTabOnLeftClick !== "boolean") {
      nextSettings.openNativeNewTabOnLeftClick = false;
      changed = true;
    }
    if (deleteKey(nextSettings, "searchUrlTemplate")) changed = true;
    if (deleteKey(nextSettings, "cycleOrder")) changed = true;
    if (typeof nextSettings.wheelPreset !== "string") {
      nextSettings.wheelPreset = "balanced";
      changed = true;
    }
    if (typeof nextSettings.horizontalWheel !== "boolean") {
      nextSettings.horizontalWheel = true;
      changed = true;
    }
    if (typeof nextSettings.overshootGuard !== "boolean") {
      nextSettings.overshootGuard = true;
      changed = true;
    }
    if (typeof nextSettings.wheelAcceleration !== "boolean") {
      nextSettings.wheelAcceleration = false;
      changed = true;
    }
    if (typeof nextSettings.wheelCooldownMs !== "number") {
      nextSettings.wheelCooldownMs = 160;
      changed = true;
    }
    if (typeof nextSettings.wheelSensitivity !== "number") {
      nextSettings.wheelSensitivity = 1;
      changed = true;
    }
    if (typeof nextSettings.pageScrollSpeedMultiplier !== "number") {
      nextSettings.pageScrollSpeedMultiplier = 1;
      changed = true;
    }
    if (typeof nextSettings.pageScrollViewportCapRatio !== "number") {
      nextSettings.pageScrollViewportCapRatio = 1;
      changed = true;
    }
    if (changed) storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return changed;
  }
  var TABWHEEL_CLICK_ACTION_VALUES = [
    "search",
    "nativeNewTab",
    "recentTab",
    "closeToRecent",
    "duplicateTab",
    "dragCurrentTab",
    "openSettings",
    "none"
  ];
  function isClickActionValue(value) {
    return typeof value === "string" && TABWHEEL_CLICK_ACTION_VALUES.includes(value);
  }
  function migrateClickActionSettings(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    const hasExistingSettings = typeof settings === "object" && settings !== null && !Array.isArray(settings);
    const nextSettings = hasExistingSettings ? { ...settings } : {};
    let changed = !hasExistingSettings;
    const clickActionFallbacks = [
      ["leftClickAction", nextSettings.openNativeNewTabOnLeftClick === true ? "nativeNewTab" : "search"],
      ["middleClickAction", "recentTab"],
      ["rightClickAction", "closeToRecent"]
    ];
    for (const [settingKey, fallback] of clickActionFallbacks) {
      if (isClickActionValue(nextSettings[settingKey])) continue;
      nextSettings[settingKey] = fallback;
      changed = true;
    }
    if (deleteKey(nextSettings, "openNativeNewTabOnLeftClick")) changed = true;
    if (changed) storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return changed;
  }
  function focusTabWheelSettings(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    if (typeof settings !== "object" || settings === null || Array.isArray(settings)) return false;
    const nextSettings = { ...settings };
    let changed = false;
    for (const key of [
      "leftClickAction",
      "rightClickAction",
      "openNativeNewTabOnLeftClick",
      "pageScrollSpeedMultiplier",
      "pageScrollViewportCapRatio"
    ]) {
      changed = deleteKey(nextSettings, key) || changed;
    }
    if (!isClickActionValue(nextSettings.middleClickAction)) {
      nextSettings.middleClickAction = "openSettings";
      changed = true;
    }
    for (const key of [
      "allowGesturesInEditableFields",
      "restorePagePosition",
      "skipRestrictedPages",
      "wrapAround",
      "horizontalWheel",
      "overshootGuard"
    ]) {
      if (nextSettings[key] === true) continue;
      nextSettings[key] = true;
      changed = true;
    }
    if (typeof nextSettings.skipHiddenTabs !== "boolean") {
      nextSettings.skipHiddenTabs = true;
      changed = true;
    }
    if (nextSettings.wheelPreset === "custom") {
      const presets = [
        ["precise", 0.8, 220, false, true],
        ["balanced", 1, 160, false, true],
        ["fast", 1.35, 90, true, true]
      ];
      const match = presets.find(([, sensitivity, cooldown, acceleration, guard]) => nextSettings.wheelSensitivity === sensitivity && nextSettings.wheelCooldownMs === cooldown && nextSettings.wheelAcceleration === acceleration && nextSettings.overshootGuard === guard);
      if (match) {
        nextSettings.wheelPreset = match[0];
        changed = true;
      }
    }
    if (changed) storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return changed;
  }
  function backfillFeelAndReliabilitySettings(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    const hasExistingSettings = typeof settings === "object" && settings !== null && !Array.isArray(settings);
    const nextSettings = hasExistingSettings ? { ...settings } : {};
    let changed = !hasExistingSettings;
    for (const key of ["deviceAwareTuning", "showRestrictedBadge"]) {
      if (typeof nextSettings[key] === "boolean") continue;
      nextSettings[key] = true;
      changed = true;
    }
    if (changed) storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return changed;
  }
  function removeDeviceTuningState(storage) {
    let changed = deleteSettingKey(storage, "deviceAwareTuning");
    changed = deleteKey(storage, TABWHEEL_DEVICE_PROFILE_KEY) || changed;
    return changed;
  }
  function backfillCycleWithinTabGroupSetting(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    const hasExistingSettings = typeof settings === "object" && settings !== null && !Array.isArray(settings);
    const nextSettings = hasExistingSettings ? { ...settings } : {};
    let changed = !hasExistingSettings;
    if (typeof nextSettings.cycleWithinTabGroup !== "boolean") {
      nextSettings.cycleWithinTabGroup = false;
      changed = true;
    }
    if (changed) storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    return changed;
  }
  function restoreClickActionsAndRetireMruCycle(storage) {
    const settings = storage[TABWHEEL_SETTINGS_KEY];
    const hasExistingSettings = typeof settings === "object" && settings !== null && !Array.isArray(settings);
    const nextSettings = hasExistingSettings ? { ...settings } : {};
    const validActions = /* @__PURE__ */ new Set([
      "nativeNewTab",
      "recentTab",
      "closeToRecent",
      "duplicateTab",
      "dragCurrentTab",
      "openSettings",
      "none"
    ]);
    let changed = !hasExistingSettings;
    const defaults = [
      ["leftClickAction", "nativeNewTab"],
      ["middleClickAction", "recentTab"],
      ["rightClickAction", "closeToRecent"]
    ];
    for (const [key, fallback] of defaults) {
      if (validActions.has(String(nextSettings[key]))) continue;
      nextSettings[key] = fallback;
      changed = true;
    }
    if (deleteKey(nextSettings, "cycleScope")) changed = true;
    if (changed) storage[TABWHEEL_SETTINGS_KEY] = nextSettings;
    if (!hasKey(storage, TABWHEEL_RECENT_TABS_KEY) && hasKey(storage, TABWHEEL_MRU_STATE_KEY)) {
      storage[TABWHEEL_RECENT_TABS_KEY] = storage[TABWHEEL_MRU_STATE_KEY];
      changed = true;
    }
    changed = deleteKey(storage, TABWHEEL_MRU_STATE_KEY) || changed;
    return changed;
  }
  function isHttpUrl(value) {
    if (typeof value !== "string") return false;
    try {
      const url = new URL(value);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch (_) {
      return false;
    }
  }
  function removeScrollMemoryWithoutUrls(storage) {
    const scrollMemory = storage[TABWHEEL_SCROLL_MEMORY_KEY];
    if (typeof scrollMemory !== "object" || scrollMemory === null || Array.isArray(scrollMemory)) return false;
    const nextScrollMemory = {};
    let changed = false;
    for (const [key, rawEntry] of Object.entries(scrollMemory)) {
      if (typeof rawEntry !== "object" || rawEntry === null || Array.isArray(rawEntry)) {
        changed = true;
        continue;
      }
      const entry = rawEntry;
      if (!isHttpUrl(entry.url)) {
        changed = true;
        continue;
      }
      nextScrollMemory[key] = entry;
    }
    if (changed) storage[TABWHEEL_SCROLL_MEMORY_KEY] = nextScrollMemory;
    return changed;
  }
  function removeScrollMemoryZoom(storage) {
    const scrollMemory = storage[TABWHEEL_SCROLL_MEMORY_KEY];
    if (typeof scrollMemory !== "object" || scrollMemory === null || Array.isArray(scrollMemory)) return false;
    const nextScrollMemory = {};
    let changed = false;
    for (const [key, rawEntry] of Object.entries(scrollMemory)) {
      if (typeof rawEntry !== "object" || rawEntry === null || Array.isArray(rawEntry)) {
        nextScrollMemory[key] = rawEntry;
        continue;
      }
      const entry = rawEntry;
      if (!hasKey(entry, "zoom")) {
        nextScrollMemory[key] = entry;
        continue;
      }
      const nextEntry = { ...entry };
      delete nextEntry.zoom;
      nextScrollMemory[key] = nextEntry;
      changed = true;
    }
    if (changed) storage[TABWHEEL_SCROLL_MEMORY_KEY] = nextScrollMemory;
    return changed;
  }
  function migrateStorageSnapshot(input) {
    const migratedStorage = { ...input };
    const fromVersion = readSchemaVersion(input);
    if (fromVersion > STORAGE_SCHEMA_VERSION) {
      return {
        fromVersion,
        toVersion: fromVersion,
        changed: false,
        migratedStorage
      };
    }
    if (fromVersion < STORAGE_SCHEMA_VERSION && isFreshInstallSnapshot(input)) {
      return {
        fromVersion,
        toVersion: STORAGE_SCHEMA_VERSION,
        changed: true,
        migratedStorage: {
          [STORAGE_SCHEMA_VERSION_KEY]: STORAGE_SCHEMA_VERSION
        }
      };
    }
    let changed = false;
    if (fromVersion < 2) {
      changed = deleteKey(migratedStorage, "frecencyData") || changed;
    }
    if (fromVersion === 2) {
      changed = deleteKey(migratedStorage, "frecencyData") || changed;
    }
    if (fromVersion < 4) {
      changed = deleteKey(migratedStorage, "tabWheelSessions") || changed;
    }
    if (fromVersion < 5) {
      changed = enableEditableFieldsByDefault(migratedStorage) || changed;
    }
    if (fromVersion < 6) {
      changed = deleteSettingKey(migratedStorage, "showCycleToast") || changed;
    }
    if (fromVersion < 7) {
      changed = removeScrollMemoryWithoutUrls(migratedStorage) || changed;
      changed = deleteKey(migratedStorage, TABWHEEL_MRU_STATE_KEY) || changed;
    }
    if (fromVersion < 8) {
      changed = deleteKey(migratedStorage, TABWHEEL_LEGACY_TAGGED_TABS_KEY) || changed;
      changed = deleteKey(migratedStorage, TABWHEEL_MRU_STATE_KEY) || changed;
      changed = migrateTabWheelSettings(migratedStorage) || changed;
    }
    if (fromVersion < 9) {
      changed = deleteKey(migratedStorage, TABWHEEL_LEGACY_TAGGED_TABS_KEY) || changed;
      changed = deleteKey(migratedStorage, TABWHEEL_WHEEL_LIST_KEY) || changed;
      changed = migrateTabWheelSettings(migratedStorage) || changed;
    }
    if (fromVersion < 10) {
      changed = removeScrollMemoryZoom(migratedStorage) || changed;
    }
    if (fromVersion < 11) {
      changed = migrateTabWheelSettings(migratedStorage) || changed;
    }
    if (fromVersion < 12) {
      changed = deleteSettingKey(migratedStorage, "searchUrlTemplate") || changed;
    }
    if (fromVersion < 13) {
      changed = migrateClickActionSettings(migratedStorage) || changed;
    }
    if (fromVersion < 14) {
      changed = focusTabWheelSettings(migratedStorage) || changed;
      changed = deleteKey(migratedStorage, TABWHEEL_SEARCH_HISTORY_KEY) || changed;
    }
    if (fromVersion < 15) {
      changed = backfillFeelAndReliabilitySettings(migratedStorage) || changed;
    }
    if (fromVersion < 16) {
      changed = removeDeviceTuningState(migratedStorage) || changed;
    }
    if (fromVersion < 17) {
      changed = backfillCycleWithinTabGroupSetting(migratedStorage) || changed;
    }
    if (fromVersion < 18) {
      changed = restoreClickActionsAndRetireMruCycle(migratedStorage) || changed;
    }
    if (migratedStorage[STORAGE_SCHEMA_VERSION_KEY] !== STORAGE_SCHEMA_VERSION) {
      migratedStorage[STORAGE_SCHEMA_VERSION_KEY] = STORAGE_SCHEMA_VERSION;
      changed = true;
    }
    return {
      fromVersion,
      toVersion: STORAGE_SCHEMA_VERSION,
      changed,
      migratedStorage
    };
  }

  // src/lib/common/utils/storageMigrationsRuntime.ts
  async function migrateStorageIfNeeded() {
    const versionSnapshot = await import_webextension_polyfill6.default.storage.local.get(STORAGE_SCHEMA_VERSION_KEY);
    if (isStorageSchemaVersionCurrent(versionSnapshot[STORAGE_SCHEMA_VERSION_KEY])) {
      return createCurrentVersionMigrationResult();
    }
    const snapshot = await import_webextension_polyfill6.default.storage.local.get(null);
    const result = migrateStorageSnapshot(snapshot);
    if (!result.changed) return result;
    const deletedKeys = Object.keys(snapshot).filter((key) => !(key in result.migratedStorage));
    if (deletedKeys.length > 0) {
      await import_webextension_polyfill6.default.storage.local.remove(deletedKeys);
    }
    await import_webextension_polyfill6.default.storage.local.set(result.migratedStorage);
    return result;
  }

  // src/entryPoints/backgroundRuntime/background.ts
  var migrationReady = migrateStorageIfNeeded();
  var tabWheel = createTabWheelDomain({ migrationReady });
  tabWheel.registerLifecycleListeners();
  registerRuntimeMessageRouter([
    createTabWheelMessageHandler(tabWheel)
  ]);
  async function bootstrapBackground() {
    const migration = await migrationReady;
    if (migration.changed) {
      console.log(
        `[TabWheel] Storage migration applied (${migration.fromVersion} -> ${migration.toVersion}).`
      );
    }
    void tabWheel.ensureLoaded();
  }
  void bootstrapBackground().catch((error) => {
    console.error("[TabWheel] Background bootstrap failed:", error);
  });
})();

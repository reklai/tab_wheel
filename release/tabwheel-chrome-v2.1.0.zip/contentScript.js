"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/appInit/appInit.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabWheel.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());

  // src/lib/core/tabWheel/mouseGestureCore.ts
  var MOUSE_GESTURE_CLAIM_MS = 900;
  var TABWHEEL_CLICK_ACTIONS = [
    "search",
    "nativeNewTab",
    "recentTab",
    "closeToRecent",
    "duplicateTab",
    "openSettings",
    "none"
  ];
  var DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS = {
    leftClickAction: "none",
    middleClickAction: "openSettings",
    rightClickAction: "none"
  };
  var MOUSE_GESTURE_BUTTON_MECHANICS = [
    {
      button: 0,
      runPhase: "sessionStart",
      finishEvents: ["click"]
    },
    {
      button: 1,
      runPhase: "auxclick",
      finishEvents: ["auxclick"]
    },
    {
      button: 2,
      runPhase: "contextmenu",
      finishEvents: ["click", "auxclick", "contextmenu"]
    }
  ];
  function buildMouseGesturePolicies(clickActions) {
    const clickActionsByButton = [
      clickActions.leftClickAction,
      clickActions.middleClickAction,
      clickActions.rightClickAction
    ];
    return MOUSE_GESTURE_BUTTON_MECHANICS.flatMap((mechanics) => {
      const clickAction = clickActionsByButton[mechanics.button];
      if (clickAction === "none") return [];
      return [{ action: clickAction, ...mechanics }];
    });
  }
  var MOUSE_GESTURE_POLICIES = buildMouseGesturePolicies(DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS);
  function resolveMouseGesturePolicy(button, policies = MOUSE_GESTURE_POLICIES) {
    return policies.find((policy) => policy.button === button) || null;
  }
  function isMouseGestureStartEventType(eventType) {
    return eventType === "pointerdown" || eventType === "mousedown";
  }
  function isMouseGestureSessionStartEventType(eventType) {
    return isMouseGestureStartEventType(eventType) || eventType === "click" || eventType === "contextmenu" || eventType === "auxclick";
  }
  function shouldSuppressRedundantGestureStart(eventType, button, firedButtons) {
    if (isMouseGestureStartEventType(eventType)) return false;
    return firedButtons.has(button);
  }
  function createMouseGestureSession(policy, startedAt) {
    return {
      policy,
      hasRun: false,
      startedAt
    };
  }
  function isMouseGestureSessionExpired(session, now, claimMs = MOUSE_GESTURE_CLAIM_MS) {
    return now - session.startedAt > claimMs;
  }
  function isMouseGestureEventForSession(session, event) {
    if (event.type === "contextmenu" && session.policy.button === 2) return true;
    return event.button === session.policy.button;
  }
  function shouldRunMouseGestureSession(session, eventType) {
    if (session.hasRun) return false;
    return session.policy.runPhase === "sessionStart" || eventType === session.policy.runPhase;
  }
  function isMouseGestureFinishEventType(eventType) {
    return eventType === "click" || eventType === "auxclick" || eventType === "contextmenu";
  }
  function shouldFinishMouseGestureSession(session, eventType) {
    return isMouseGestureFinishEventType(eventType) && session.policy.finishEvents.includes(eventType);
  }

  // src/lib/common/contracts/tabWheel.ts
  var TABWHEEL_STORAGE_KEYS = {
    settings: "tabWheelSettings",
    scrollMemory: "tabWheelScrollMemory",
    mruState: "tabWheelMruState",
    searchHistory: "tabWheelSearchHistory"
  };
  var TABWHEEL_MODIFIER_KEYS = [
    "alt",
    "ctrl",
    "meta"
  ];
  var TABWHEEL_CYCLE_SCOPES = ["general", "mru"];
  var TABWHEEL_PRESETS = ["precise", "balanced", "fast", "custom"];
  var MIN_WHEEL_SENSITIVITY = 0.5;
  var MAX_WHEEL_SENSITIVITY = 2;
  var MIN_WHEEL_COOLDOWN_MS = 60;
  var MAX_WHEEL_COOLDOWN_MS = 400;
  var MIN_PAGE_SCROLL_SPEED_MULTIPLIER = 0.5;
  var MAX_PAGE_SCROLL_SPEED_MULTIPLIER = 3;
  var MIN_PAGE_SCROLL_VIEWPORT_CAP_RATIO = 0.1;
  var MAX_PAGE_SCROLL_VIEWPORT_CAP_RATIO = 1;
  var MAX_SEARCH_QUERY_LENGTH = 512;
  var TABWHEEL_PRESET_VALUES = {
    precise: {
      wheelSensitivity: 0.8,
      wheelCooldownMs: 220,
      pageScrollSpeedMultiplier: 0.8,
      pageScrollViewportCapRatio: 0.35,
      wheelAcceleration: false,
      overshootGuard: true
    },
    balanced: {
      wheelSensitivity: 1,
      wheelCooldownMs: 160,
      pageScrollSpeedMultiplier: 1,
      pageScrollViewportCapRatio: 1,
      wheelAcceleration: false,
      overshootGuard: true
    },
    fast: {
      wheelSensitivity: 1.35,
      wheelCooldownMs: 90,
      pageScrollSpeedMultiplier: 1.4,
      pageScrollViewportCapRatio: 1,
      wheelAcceleration: true,
      overshootGuard: true
    }
  };
  var DEFAULT_TABWHEEL_SETTINGS = {
    invertScroll: false,
    gestureModifier: "alt",
    gestureWithShift: false,
    allowGesturesInEditableFields: true,
    ...DEFAULT_TABWHEEL_CLICK_ACTION_SETTINGS,
    cycleScope: "general",
    skipPinnedTabs: false,
    skipRestrictedPages: true,
    skipHiddenTabs: false,
    wrapAround: true,
    wheelPreset: "balanced",
    wheelSensitivity: 1,
    wheelCooldownMs: 160,
    pageScrollSpeedMultiplier: 1,
    pageScrollViewportCapRatio: 1,
    wheelAcceleration: false,
    horizontalWheel: true,
    overshootGuard: true
  };
  function normalizeModifierKey(value, fallback) {
    return TABWHEEL_MODIFIER_KEYS.includes(value) ? value : fallback;
  }
  function normalizeShiftRequirement(value) {
    return value === true;
  }
  function normalizeClickAction(value, fallback) {
    return TABWHEEL_CLICK_ACTIONS.includes(value) ? value : fallback;
  }
  function normalizeEnabledFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeNumberInRange(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }
  function normalizeSearchQuery(value) {
    if (typeof value !== "string") return "";
    return value.trim().replace(/\s+/g, " ").slice(0, MAX_SEARCH_QUERY_LENGTH);
  }
  function normalizeTabWheelCycleScope(value) {
    return TABWHEEL_CYCLE_SCOPES.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.cycleScope;
  }
  function normalizeWheelPreset(value) {
    return TABWHEEL_PRESETS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.wheelPreset;
  }
  function detectTabWheelPreset(settings) {
    for (const preset of ["precise", "balanced", "fast"]) {
      const presetValues = TABWHEEL_PRESET_VALUES[preset];
      if (settings.wheelSensitivity === presetValues.wheelSensitivity && settings.wheelCooldownMs === presetValues.wheelCooldownMs && settings.pageScrollSpeedMultiplier === presetValues.pageScrollSpeedMultiplier && settings.pageScrollViewportCapRatio === presetValues.pageScrollViewportCapRatio && settings.wheelAcceleration === presetValues.wheelAcceleration && settings.overshootGuard === presetValues.overshootGuard) {
        return preset;
      }
    }
    return "custom";
  }
  function normalizeTabWheelSettings(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
    const settings = value;
    const normalizedSettings = {
      invertScroll: settings.invertScroll === true,
      gestureModifier: normalizeModifierKey(
        settings.gestureModifier,
        DEFAULT_TABWHEEL_SETTINGS.gestureModifier
      ),
      gestureWithShift: normalizeShiftRequirement(settings.gestureWithShift),
      allowGesturesInEditableFields: normalizeEnabledFlag(
        settings.allowGesturesInEditableFields,
        DEFAULT_TABWHEEL_SETTINGS.allowGesturesInEditableFields
      ),
      leftClickAction: normalizeClickAction(
        settings.leftClickAction,
        value.openNativeNewTabOnLeftClick === true ? "nativeNewTab" : DEFAULT_TABWHEEL_SETTINGS.leftClickAction
      ),
      middleClickAction: normalizeClickAction(
        settings.middleClickAction,
        DEFAULT_TABWHEEL_SETTINGS.middleClickAction
      ),
      rightClickAction: normalizeClickAction(
        settings.rightClickAction,
        DEFAULT_TABWHEEL_SETTINGS.rightClickAction
      ),
      cycleScope: normalizeTabWheelCycleScope(settings.cycleScope),
      skipPinnedTabs: normalizeEnabledFlag(
        settings.skipPinnedTabs,
        DEFAULT_TABWHEEL_SETTINGS.skipPinnedTabs
      ),
      skipRestrictedPages: normalizeEnabledFlag(
        settings.skipRestrictedPages,
        DEFAULT_TABWHEEL_SETTINGS.skipRestrictedPages
      ),
      skipHiddenTabs: normalizeEnabledFlag(
        settings.skipHiddenTabs,
        DEFAULT_TABWHEEL_SETTINGS.skipHiddenTabs
      ),
      wrapAround: normalizeEnabledFlag(
        settings.wrapAround,
        DEFAULT_TABWHEEL_SETTINGS.wrapAround
      ),
      wheelPreset: normalizeWheelPreset(settings.wheelPreset),
      wheelSensitivity: normalizeNumberInRange(
        settings.wheelSensitivity,
        DEFAULT_TABWHEEL_SETTINGS.wheelSensitivity,
        MIN_WHEEL_SENSITIVITY,
        MAX_WHEEL_SENSITIVITY
      ),
      wheelCooldownMs: normalizeNumberInRange(
        settings.wheelCooldownMs,
        DEFAULT_TABWHEEL_SETTINGS.wheelCooldownMs,
        MIN_WHEEL_COOLDOWN_MS,
        MAX_WHEEL_COOLDOWN_MS
      ),
      pageScrollSpeedMultiplier: normalizeNumberInRange(
        settings.pageScrollSpeedMultiplier,
        DEFAULT_TABWHEEL_SETTINGS.pageScrollSpeedMultiplier,
        MIN_PAGE_SCROLL_SPEED_MULTIPLIER,
        MAX_PAGE_SCROLL_SPEED_MULTIPLIER
      ),
      pageScrollViewportCapRatio: normalizeNumberInRange(
        settings.pageScrollViewportCapRatio,
        DEFAULT_TABWHEEL_SETTINGS.pageScrollViewportCapRatio,
        MIN_PAGE_SCROLL_VIEWPORT_CAP_RATIO,
        MAX_PAGE_SCROLL_VIEWPORT_CAP_RATIO
      ),
      wheelAcceleration: normalizeEnabledFlag(
        settings.wheelAcceleration,
        DEFAULT_TABWHEEL_SETTINGS.wheelAcceleration
      ),
      horizontalWheel: normalizeEnabledFlag(
        settings.horizontalWheel,
        DEFAULT_TABWHEEL_SETTINGS.horizontalWheel
      ),
      overshootGuard: normalizeEnabledFlag(
        settings.overshootGuard,
        DEFAULT_TABWHEEL_SETTINGS.overshootGuard
      )
    };
    normalizedSettings.wheelPreset = settings.wheelPreset == null ? detectTabWheelPreset(normalizedSettings) : normalizedSettings.wheelPreset;
    return normalizedSettings;
  }
  async function loadTabWheelSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.settings);
      return normalizeTabWheelSettings(data[TABWHEEL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
  }

  // src/lib/common/utils/asyncFlow.ts
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function createDebouncedCallback(fn, delayMs) {
    let timer = null;
    const debounced = (...args) => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => {
        timer = null;
        fn(...args);
      }, delayMs);
    };
    debounced.cancel = () => {
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
    };
    return debounced;
  }

  // src/lib/common/utils/panelHost.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  var activePanelCleanup = null;
  var activePanelFailSafeCleanup = null;
  var DEFAULT_PANEL_MODAL_EVENT_TYPES = [
    "keydown",
    "keypress",
    "keyup",
    "pointerdown",
    "pointerup",
    "mousedown",
    "mouseup",
    "click",
    "auxclick",
    "contextmenu"
  ];
  function invokeCleanupSafely(label, cleanup) {
    if (!cleanup) return;
    try {
      cleanup();
    } catch (error) {
      console.error(`[TabWheel] ${label}:`, error);
    }
  }
  function cleanupPanelFailSafe() {
    const cleanup = activePanelFailSafeCleanup;
    activePanelFailSafeCleanup = null;
    invokeCleanupSafely("Panel fail-safe cleanup failed", cleanup);
  }
  function handlePanelRuntimeFault(label, reason) {
    if (!document.getElementById("ht-panel-host")) return;
    console.error(`[TabWheel] ${label}; dismissing panel.`, reason);
    dismissPanel();
  }
  var EXTENSION_BASE_URL = import_webextension_polyfill2.default.runtime.getURL("");
  function reasonLooksExtensionScoped(reason) {
    if (!reason) return false;
    if (typeof reason === "string") return reason.includes(EXTENSION_BASE_URL);
    if (typeof reason === "object") {
      const maybeError = reason;
      if (typeof maybeError.stack === "string" && maybeError.stack.includes(EXTENSION_BASE_URL)) {
        return true;
      }
      if (typeof maybeError.message === "string" && maybeError.message.includes(EXTENSION_BASE_URL)) {
        return true;
      }
    }
    return false;
  }
  function isPanelRuntimeFaultFromExtension(event) {
    if (typeof event.filename === "string" && event.filename.startsWith(EXTENSION_BASE_URL)) {
      return true;
    }
    if (reasonLooksExtensionScoped(event.error)) return true;
    return reasonLooksExtensionScoped(event.message);
  }
  function registerPanelCleanup(fn) {
    activePanelCleanup = fn;
  }
  function createPanelHost() {
    if (activePanelCleanup) {
      const cleanup = activePanelCleanup;
      activePanelCleanup = null;
      invokeCleanupSafely("Panel cleanup failed while opening a new panel", cleanup);
    }
    cleanupPanelFailSafe();
    const existing = document.getElementById("ht-panel-host");
    if (existing) existing.remove();
    const host = document.createElement("div");
    host.id = "ht-panel-host";
    host.tabIndex = -1;
    host.style.cssText = "position:fixed;inset:0;z-index:2147483647;pointer-events:auto;overscroll-behavior:contain;isolation:isolate;";
    const shadow = host.attachShadow({ mode: "closed" });
    document.body.appendChild(host);
    let lastFocusedInPanel = null;
    let pointerInteractionInPanel = false;
    shadow.addEventListener("focusin", (event) => {
      const target = event.target;
      if (target instanceof HTMLElement) {
        lastFocusedInPanel = target;
      }
    });
    shadow.addEventListener("pointerdown", () => {
      pointerInteractionInPanel = true;
    });
    const onGlobalPointerEnd = () => {
      pointerInteractionInPanel = false;
    };
    window.addEventListener("pointerup", onGlobalPointerEnd, true);
    window.addEventListener("pointercancel", onGlobalPointerEnd, true);
    const focusPreferredPanelTarget = () => {
      if (!document.getElementById("ht-panel-host")) return;
      if (lastFocusedInPanel && shadow.contains(lastFocusedInPanel)) {
        lastFocusedInPanel.focus({ preventScroll: true });
        return;
      }
      host.focus({ preventScroll: true });
    };
    let reclaimId = 0;
    host.addEventListener("focusout", () => {
      cancelAnimationFrame(reclaimId);
      reclaimId = requestAnimationFrame(() => {
        if (document.visibilityState !== "visible") return;
        if (pointerInteractionInPanel) return;
        if (!document.getElementById("ht-panel-host")) return;
        const activeInHostTree = document.activeElement === host || host.contains(document.activeElement);
        const activeInShadow = !!shadow.activeElement && shadow.contains(shadow.activeElement);
        if (!activeInHostTree && !activeInShadow) {
          focusPreferredPanelTarget();
        }
      });
    });
    const onVisibilityChange = () => {
      if (document.visibilityState !== "visible") return;
      if (!document.getElementById("ht-panel-host")) return;
      const activeInHostTree = document.activeElement === host || host.contains(document.activeElement);
      const activeInShadow = !!shadow.activeElement && shadow.contains(shadow.activeElement);
      if (!activeInHostTree && !activeInShadow) {
        focusPreferredPanelTarget();
      }
    };
    document.addEventListener("visibilitychange", onVisibilityChange);
    const onError = (event) => {
      if (!isPanelRuntimeFaultFromExtension(event)) return;
      handlePanelRuntimeFault("Panel runtime error", event.error || event.message);
    };
    const onUnhandledRejection = (event) => {
      if (!reasonLooksExtensionScoped(event.reason)) return;
      handlePanelRuntimeFault("Panel unhandled rejection", event.reason);
    };
    let lastAnimationFrameAt = performance.now();
    let frameProbeId = 0;
    const frameProbe = (ts) => {
      lastAnimationFrameAt = ts;
      frameProbeId = requestAnimationFrame(frameProbe);
    };
    frameProbeId = requestAnimationFrame(frameProbe);
    const watchdogIntervalId = window.setInterval(() => {
      if (!document.getElementById("ht-panel-host")) return;
      if (document.visibilityState !== "visible") return;
      const gapMs = performance.now() - lastAnimationFrameAt;
      if (gapMs > 3e3) {
        handlePanelRuntimeFault("Panel watchdog detected UI stall", { gapMs });
      }
    }, 1e3);
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onUnhandledRejection);
    activePanelFailSafeCleanup = () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onUnhandledRejection);
      window.removeEventListener("pointerup", onGlobalPointerEnd, true);
      window.removeEventListener("pointercancel", onGlobalPointerEnd, true);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      cancelAnimationFrame(frameProbeId);
      window.clearInterval(watchdogIntervalId);
    };
    return { host, shadow };
  }
  function removePanelHost() {
    cleanupPanelFailSafe();
    const host = document.getElementById("ht-panel-host");
    if (host) host.remove();
    activePanelCleanup = null;
  }
  function createPanelModalSession(options) {
    const root = options.root;
    const host = root.host;
    const eventTypes = options.eventTypes ?? DEFAULT_PANEL_MODAL_EVENT_TYPES;
    const containEvents = options.containEvents !== false;
    const closeOnEscape = options.closeOnEscape !== false;
    let disposed = false;
    const dispose = () => {
      if (disposed) return;
      disposed = true;
      for (const eventType of eventTypes) {
        root.removeEventListener(eventType, modalEventHandler);
      }
      document.removeEventListener("keydown", documentKeyHandler, true);
      document.removeEventListener("fullscreenchange", fullscreenChangeHandler, true);
      document.removeEventListener("visibilitychange", visibilityChangeHandler, true);
      window.removeEventListener("pagehide", pageHideHandler, true);
    };
    const requestClose = () => {
      if (disposed) return;
      dispose();
      options.onClose();
    };
    function isPanelEvent(event) {
      const path = event.composedPath();
      return path.includes(root) || path.includes(host);
    }
    function modalEventHandler(event) {
      if (containEvents) event.stopPropagation();
      if (closeOnEscape && event instanceof KeyboardEvent && event.key === "Escape") {
        event.preventDefault();
        requestClose();
      }
    }
    function documentKeyHandler(event) {
      if (!closeOnEscape || event.key !== "Escape" || !isPanelEvent(event)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      requestClose();
    }
    function fullscreenChangeHandler() {
      if (options.closeOnFullscreenChange !== true) return;
      requestClose();
    }
    function pageHideHandler() {
      if (options.closeOnPageHide !== true) return;
      requestClose();
    }
    function visibilityChangeHandler() {
      if (options.closeOnVisibilityHidden !== true) return;
      if (document.visibilityState !== "hidden") return;
      requestClose();
    }
    for (const eventType of eventTypes) {
      root.addEventListener(eventType, modalEventHandler);
    }
    document.addEventListener("keydown", documentKeyHandler, true);
    document.addEventListener("fullscreenchange", fullscreenChangeHandler, true);
    document.addEventListener("visibilitychange", visibilityChangeHandler, true);
    window.addEventListener("pagehide", pageHideHandler, true);
    return { dispose };
  }
  function dismissPanel() {
    const cleanup = activePanelCleanup;
    activePanelCleanup = null;
    invokeCleanupSafely("Panel cleanup failed during dismiss", cleanup);
    removePanelHost();
  }
  function getBaseStyles() {
    return `
    * { margin: 0; padding: 0; box-sizing: border-box; }

    :host {
      all: initial;
      --ht-font-mono: 'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
      --ht-color-bg: #1e1e1e;
      --ht-color-bg-elevated: #252525;
      --ht-color-bg-soft: #3a3a3c;
      --ht-color-bg-detail-focus: #1a2230;
      --ht-color-bg-detail-focus-header: #1e2a3a;
      --ht-color-bg-code: #1a1a1a;
      --ht-color-text: #e0e0e0;
      --ht-color-text-soft: #c0c0c0;
      --ht-color-text-muted: #808080;
      --ht-color-text-title: #a0a0a0;
      --ht-color-text-detail-focus: #a0c0e0;
      --ht-color-text-dim: #666;
      --ht-color-text-faint: #555;
      --ht-color-text-strong: #fff;
      --ht-color-accent: #0a84ff;
      --ht-color-accent-soft: rgba(10,132,255,0.1);
      --ht-color-accent-active: rgba(10,132,255,0.15);
      --ht-color-accent-soft-strong: rgba(10,132,255,0.12);
      --ht-color-accent-soft-faint: rgba(10,132,255,0.08);
      --ht-color-accent-alt: #af82ff;
      --ht-color-accent-alt-soft: rgba(175,130,255,0.15);
      --ht-color-success: #32d74b;
      --ht-color-tree-cursor: #4ec970;
      --ht-color-tree-cursor-bg: rgba(78,201,112,0.15);
      --ht-color-tree-cursor-bg-soft: rgba(78,201,112,0.18);
      --ht-color-tree-cursor-bg-strong: rgba(78,201,112,0.20);
      --ht-color-danger: #ff5f57;
      --ht-color-warning: #febc2e;
      --ht-color-mark-bg: #f9d45c;
      --ht-color-mark-fg: #1e1e1e;
      --ht-color-border: rgba(255,255,255,0.1);
      --ht-color-border-soft: rgba(255,255,255,0.06);
      --ht-color-border-faint: rgba(255,255,255,0.04);
      --ht-color-border-ultra-faint: rgba(255,255,255,0.03);
      --ht-color-hover: rgba(255,255,255,0.06);
      --ht-color-focus-active: rgba(255,255,255,0.13);
      --ht-color-surface: rgba(255,255,255,0.08);
      --ht-color-surface-dim: rgba(255,255,255,0.04);
      --ht-color-surface-strong: rgba(255,255,255,0.15);
      --ht-shadow-overlay: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.05);
      --ht-radius: 10px;
      --ht-input-row-pad-y: 8px;
      --ht-input-row-pad-x: 14px;
      --ht-input-row-pad-x-compact: 10px;
      --ht-input-prompt-gap: 8px;
      --ht-input-prompt-size: 14px;
      --ht-input-prompt-weight: 600;
      --ht-input-font-size: 13px;
      --ht-input-caret-color: var(--ht-color-text-strong);
      --ht-pane-header-pad-y: 5px;
      --ht-pane-header-pad-x: 14px;
      --ht-pane-header-font-size: 11px;
      --ht-pane-header-weight: 500;
      font-family: var(--ht-font-mono);
      font-size: 13px;
      color: var(--ht-color-text);
      -webkit-font-smoothing: antialiased;
      text-rendering: optimizeLegibility;
    }

    .ht-backdrop {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
      width: 100dvw; height: 100dvh;
      background: rgba(0, 0, 0, 0.55);
    }

    .ht-titlebar {
      display: flex; align-items: center;
      padding: 10px 14px;
      background: var(--ht-color-bg-soft);
      border-bottom: 1px solid var(--ht-color-border-soft);
      border-radius: var(--ht-radius) var(--ht-radius) 0 0;
      user-select: none;
    }
    .ht-traffic-lights {
      display: flex; gap: 7px; margin-right: 14px; flex-shrink: 0;
    }
    .ht-dot {
      width: 12px; height: 12px; border-radius: 50%;
      cursor: pointer; border: none;
      transition: filter 0.15s;
    }
    .ht-dot:hover { filter: brightness(1.2); }
    .ht-dot-close { background: var(--ht-color-danger); }
    .ht-titlebar-text {
      flex: 1; text-align: center; font-size: 12px;
      color: var(--ht-color-text-title); font-weight: 500;
    }

    /* Shared row/header primitives used by overlay panels. */
    .ht-ui-input-wrap {
      display: flex;
      align-items: center;
      padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x);
      border-bottom: 1px solid var(--ht-color-border-soft);
      background: var(--ht-color-bg-elevated);
    }
    .ht-ui-input-prompt {
      color: var(--ht-color-accent);
      margin-right: var(--ht-input-prompt-gap);
      font-weight: var(--ht-input-prompt-weight);
      font-size: var(--ht-input-prompt-size);
    }
    .ht-ui-input-field {
      flex: 1;
      background: transparent;
      border: none;
      outline: none;
      color: var(--ht-color-text);
      font-family: inherit;
      font-size: var(--ht-input-font-size);
      caret-color: var(--ht-input-caret-color);
    }
    input,
    textarea {
      user-select: text;
      -webkit-user-select: text;
    }
    .ht-ui-input-field::placeholder {
      color: var(--ht-color-text-dim);
    }
    .ht-ui-pane-header {
      padding: var(--ht-pane-header-pad-y) var(--ht-pane-header-pad-x);
      font-size: var(--ht-pane-header-font-size);
      color: var(--ht-color-text-muted);
      background: var(--ht-color-bg-elevated);
      border-bottom: 1px solid var(--ht-color-border-faint);
      font-weight: var(--ht-pane-header-weight);
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ht-ui-pane-header-text {
      flex: 1;
    }
    .ht-ui-pane-header-meta {
      font-size: 10px;
      color: var(--ht-color-text-dim);
      flex-shrink: 0;
    }

    .ht-vim-badge {
      font-size: 9px; font-weight: 700; letter-spacing: 0.5px;
      padding: 2px 6px; border-radius: 4px;
      text-transform: uppercase; flex-shrink: 0;
      line-height: 1; margin-left: 8px;
    }
    .ht-vim-badge.on {
      background: var(--ht-color-success); color: #1a1a1a;
    }
    .ht-vim-badge.off {
      background: var(--ht-color-surface); color: var(--ht-color-text-dim);
    }

    .ht-footer {
      display: flex; gap: 16px; padding: 8px 14px;
      background: var(--ht-color-bg-elevated); border-top: 1px solid var(--ht-color-border-soft);
      font-size: 11px; color: var(--ht-color-text-muted); flex-wrap: wrap;
      border-radius: 0 0 var(--ht-radius) var(--ht-radius); justify-content: center;
    }
    .ht-footer-row {
      display: flex; gap: 8px; justify-content: center; width: 100%; flex-wrap: wrap;
      align-items: center;
    }
    .ht-footer-hint {
      display: inline-flex;
      align-items: baseline;
      gap: 4px;
      white-space: nowrap;
      color: var(--ht-color-text-muted);
    }
    .ht-footer-key {
      color: var(--ht-color-text-soft);
      font-weight: 700;
    }
    .ht-footer-sep {
      color: var(--ht-color-text-dim);
      font-weight: 600;
    }

    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation: none !important;
        transition: none !important;
      }
    }

    @media (max-width: 520px), (max-height: 560px) {
      .ht-ui-input-wrap {
        padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x-compact);
      }
    }
  `;
  }

  // src/lib/core/tabWheel/tabWheelCore.ts
  function resolveWheelDirection(wheelDeltaY, invertScroll) {
    const normalDirection = wheelDeltaY > 0 ? "next" : "prev";
    if (!invertScroll) return normalDirection;
    return normalDirection === "next" ? "prev" : "next";
  }
  function normalizeWheelDeltaY(event, pageHeight) {
    if (event.deltaMode === 1) return event.deltaY * 16;
    if (event.deltaMode === 2) return event.deltaY * pageHeight;
    return event.deltaY;
  }
  function normalizeWheelDelta(event, pageHeight, pageWidth, horizontalWheel) {
    const normalizedY = normalizeWheelDeltaY(event, pageHeight);
    if (!horizontalWheel) return normalizedY;
    const normalizedX = event.deltaMode === 1 ? event.deltaX * 16 : event.deltaMode === 2 ? event.deltaX * pageWidth : event.deltaX;
    return Math.abs(normalizedX) > Math.abs(normalizedY) ? normalizedX : normalizedY;
  }
  function resolveWheelTriggerDistance(baseThresholdPx, sensitivity) {
    const safeSensitivity = Number.isFinite(sensitivity) && sensitivity > 0 ? sensitivity : 1;
    return Math.max(1, baseThresholdPx / safeSensitivity);
  }
  var MAX_BURST_COUNT = 6;
  var BURST_REDUCTION_PX_PER_BURST = 6;
  var MIN_ACCELERATED_TRIGGER_DISTANCE_PX = 40;
  function resolveAcceleratedWheelTriggerDistance(triggerDistancePx, burstCount, isAccelerationEnabled) {
    if (!isAccelerationEnabled) return triggerDistancePx;
    const cappedBurstCount = Math.max(0, Math.min(MAX_BURST_COUNT, burstCount));
    const burstReduction = cappedBurstCount * BURST_REDUCTION_PX_PER_BURST;
    return Math.max(MIN_ACCELERATED_TRIGGER_DISTANCE_PX, triggerDistancePx - burstReduction);
  }
  function shouldUseNativePageScroll(speedMultiplier, viewportCapRatio) {
    return Math.abs(speedMultiplier - 1) < 1e-3 && Math.abs(viewportCapRatio - 1) < 1e-3;
  }
  function scalePageScrollDelta(wheelDelta, speedMultiplier, viewportSize, viewportCapRatio) {
    const multiplier = Number.isFinite(speedMultiplier) ? Math.max(0, speedMultiplier) : 1;
    const capRatio = Number.isFinite(viewportCapRatio) ? Math.max(0, viewportCapRatio) : 1;
    const scaledDelta = wheelDelta * multiplier;
    const maxStep = Math.max(1, viewportSize) * capRatio;
    if (maxStep <= 0) return 0;
    return Math.sign(scaledDelta) * Math.min(Math.abs(scaledDelta), maxStep);
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill3.default.runtime.sendMessage(message);
  }

  // src/lib/adapters/runtime/tabWheelApi.ts
  function cycleTabWheel(direction) {
    return sendRuntimeMessage({
      type: "TABWHEEL_CYCLE",
      direction
    });
  }
  function openTabWheelSearchTab(query, windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_OPEN_SEARCH_TAB",
      query: normalizeSearchQuery(query),
      windowId
    });
  }
  function getTabWheelSearchSuggestions(query, mode) {
    return sendRuntimeMessage({
      type: "TABWHEEL_GET_SEARCH_SUGGESTIONS",
      query: normalizeSearchQuery(query),
      mode
    });
  }
  function activateTabWheelTab(tabId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_ACTIVATE_TAB",
      tabId
    });
  }
  function openTabWheelUrlTab(url) {
    return sendRuntimeMessage({
      type: "TABWHEEL_OPEN_URL_TAB",
      url
    });
  }
  function openNativeNewTabWheelTab(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_OPEN_NATIVE_NEW_TAB",
      windowId
    });
  }
  function activateMostRecentTabWheelTab(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_ACTIVATE_MOST_RECENT_TAB",
      windowId
    });
  }
  function closeCurrentTabWheelTabAndActivateRecent(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_CLOSE_CURRENT_TAB_AND_ACTIVATE_RECENT",
      windowId
    });
  }
  function duplicateCurrentTabWheelTab(windowId) {
    return sendRuntimeMessage({
      type: "TABWHEEL_DUPLICATE_TAB",
      windowId
    });
  }
  function saveTabWheelScrollPosition(scroll) {
    return sendRuntimeMessage({
      type: "TABWHEEL_SAVE_SCROLL_POSITION",
      ...scroll
    });
  }
  function openTabWheelOptions() {
    return sendRuntimeMessage({ type: "TABWHEEL_OPEN_OPTIONS" });
  }

  // src/lib/ui/panels/searchLauncher/searchLauncher.css
  var searchLauncher_default = ".ht-search-launcher {\n  position: fixed;\n  top: 20vh;\n  left: 50%;\n  width: min(680px, calc(100vw - 32px));\n  transform: translateX(-50%);\n  border: 1px solid var(--ht-color-border);\n  border-radius: 8px;\n  overflow: hidden;\n  background: rgba(30, 30, 30, 0.72);\n  backdrop-filter: blur(18px) saturate(1.4);\n  -webkit-backdrop-filter: blur(18px) saturate(1.4);\n  box-shadow: var(--ht-shadow-overlay);\n  contain: layout style paint;\n  overscroll-behavior: contain;\n  backface-visibility: hidden;\n  will-change: transform;\n  animation: ht-search-rise 190ms cubic-bezier(0.22, 0.61, 0.36, 1) both;\n}\n\n@supports not ((backdrop-filter: blur(1px)) or (-webkit-backdrop-filter: blur(1px))) {\n  .ht-search-launcher {\n    background: var(--ht-color-bg);\n  }\n}\n\n@keyframes ht-search-rise {\n  from { opacity: 0; transform: translate(-50%, -10px) scale(0.98); }\n  to { opacity: 1; transform: translateX(-50%); }\n}\n\n.ht-backdrop {\n  animation: ht-search-fade 160ms ease both;\n}\n\n@keyframes ht-search-fade {\n  from { opacity: 0; }\n  to { opacity: 1; }\n}\n\n.ht-search-hint {\n  display: flex;\n  align-items: center;\n  gap: 7px;\n  flex-wrap: wrap;\n  padding: 8px 14px;\n  border-bottom: 1px solid rgba(255,255,255,0.14);\n  background: transparent;\n}\n\n.ht-search-hint-label {\n  font-size: 11px;\n  font-weight: 700;\n  color: var(--ht-color-text-soft);\n}\n\n.ht-search-hint-cmd {\n  font: inherit;\n  font-size: 11px;\n  font-weight: 600;\n  padding: 2px 8px;\n  border-radius: 5px;\n  cursor: pointer;\n  border: 1px solid var(--ht-color-border-soft);\n  background: var(--ht-color-surface-dim);\n  color: var(--ht-color-text-soft);\n  transition: background 0.15s ease, color 0.15s ease, opacity 0.15s ease;\n}\n\n.ht-search-hint-cmd:hover {\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text);\n}\n\n.ht-search-form {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) auto auto;\n  align-items: center;\n  gap: 8px;\n  padding: 14px;\n  border-bottom: 1px solid rgba(255,255,255,0.1);\n  background: transparent;\n}\n\n.ht-search-field {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  min-width: 0;\n}\n\n.ht-search-mode {\n  flex-shrink: 0;\n  padding: 2px 7px;\n  border-radius: 5px;\n  background: var(--ht-color-accent-active);\n  color: var(--ht-color-text-detail-focus);\n  font-size: 10px;\n  font-weight: 700;\n  letter-spacing: 0.6px;\n  text-transform: uppercase;\n}\n\n.ht-search-mode[hidden] {\n  display: none;\n}\n\n.ht-search-cancel,\n.ht-search-submit {\n  min-height: 34px;\n  padding: 0 14px;\n  border-radius: 7px;\n  cursor: pointer;\n  font: inherit;\n  font-size: 12px;\n  font-weight: 700;\n  box-shadow: inset 0 0 0 1px rgba(255,255,255,0.04);\n  transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease, transform 0.1s ease;\n}\n\n.ht-search-cancel {\n  border: 1px solid rgba(255,255,255,0.14);\n  background: rgba(255,255,255,0.06);\n  color: var(--ht-color-text);\n}\n\n.ht-search-cancel:hover {\n  border-color: rgba(255,255,255,0.22);\n  background: rgba(255,255,255,0.1);\n  color: var(--ht-color-text-strong);\n}\n\n.ht-search-submit {\n  border: 1px solid rgba(10,132,255,0.44);\n  background: rgba(10,132,255,0.18);\n  color: #f2f7ff;\n}\n\n.ht-search-submit:hover {\n  border-color: rgba(10,132,255,0.58);\n  background: rgba(10,132,255,0.26);\n}\n\n.ht-search-cancel:focus-visible,\n.ht-search-submit:focus-visible {\n  outline: 2px solid rgba(10,132,255,0.62);\n  outline-offset: 2px;\n}\n\n.ht-search-cancel:active,\n.ht-search-submit:active {\n  transform: scale(0.97);\n}\n\n.ht-search-submit:disabled {\n  cursor: default;\n  opacity: 0.66;\n}\n\n.ht-search-input {\n  min-width: 0;\n  flex: 1;\n  height: 38px;\n  border: 0;\n  outline: none;\n  background: transparent;\n  color: var(--ht-color-text-strong);\n  caret-color: var(--ht-color-text-strong);\n  font: inherit;\n  font-size: 16px;\n}\n\n.ht-search-input::placeholder {\n  color: var(--ht-color-text-dim);\n}\n\n.ht-search-input:disabled {\n  opacity: 0.82;\n}\n\n.ht-search-suggest {\n  position: relative;\n  padding: 0 6px 6px;\n  border-top: 1px solid rgba(255,255,255,0.14);\n}\n\n.ht-search-suggest[hidden] {\n  display: none;\n}\n\n.ht-search-glow {\n  position: absolute;\n  left: 6px;\n  right: 6px;\n  top: 0;\n  height: 0;\n  border-radius: 8px;\n  background: var(--ht-color-accent-soft-strong);\n  box-shadow: inset 0 0 0 1px var(--ht-color-accent-soft-faint);\n  transform: translateY(0);\n  transition: transform 220ms cubic-bezier(0.22, 0.61, 0.36, 1),\n    height 220ms cubic-bezier(0.22, 0.61, 0.36, 1),\n    opacity 180ms ease;\n  opacity: 0;\n  pointer-events: none;\n  z-index: 0;\n  will-change: transform, height;\n}\n\n.ht-search-glow.is-visible {\n  opacity: 1;\n}\n\n.ht-search-list {\n  list-style: none;\n  margin: 0;\n  padding: 6px 0 0;\n  max-height: 46vh;\n  overflow-y: auto;\n}\n\n.ht-search-option {\n  position: relative;\n  z-index: 1;\n  display: flex;\n  align-items: center;\n  gap: 11px;\n  padding: 9px 10px;\n  border-radius: 8px;\n  cursor: pointer;\n  animation: ht-search-in 150ms ease-out both;\n  animation-delay: calc(var(--i, 0) * 14ms);\n}\n\n@keyframes ht-search-in {\n  from { opacity: 0; transform: translateY(4px); }\n  to { opacity: 1; transform: none; }\n}\n\n.ht-search-favicon {\n  width: 16px;\n  height: 16px;\n  flex-shrink: 0;\n  border-radius: 3px;\n  background: var(--ht-color-surface-dim);\n}\n\n.ht-search-glyph {\n  width: 20px;\n  height: 20px;\n  flex-shrink: 0;\n  display: grid;\n  place-items: center;\n  font-size: 13px;\n  color: var(--ht-color-text-muted);\n}\n\n.ht-search-glyph-mono {\n  border-radius: 5px;\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text-soft);\n  font-size: 11px;\n  font-weight: 700;\n}\n\n.ht-search-text {\n  flex: 1;\n  min-width: 0;\n  display: flex;\n  flex-direction: column;\n  gap: 1px;\n}\n\n.ht-search-primary {\n  color: var(--ht-color-text);\n  font-size: 13px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.ht-search-secondary {\n  color: var(--ht-color-text-muted);\n  font-size: 11px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.ht-search-hit {\n  color: var(--ht-color-text-detail-focus);\n  font-weight: 700;\n}\n\n.ht-search-kicker {\n  flex-shrink: 0;\n  font-size: 9px;\n  font-weight: 600;\n  letter-spacing: 0.5px;\n  text-transform: uppercase;\n  color: var(--ht-color-text-dim);\n}\n\n.ht-search-status {\n  min-height: 18px;\n  padding: 8px 14px 12px;\n  color: var(--ht-color-text-muted);\n  font-size: 12px;\n}\n\n.ht-search-status[hidden] {\n  display: none;\n}\n\n@media (max-width: 520px), (max-height: 560px) {\n  .ht-search-launcher {\n    top: 14vh;\n    width: min(480px, calc(100vw - 20px));\n  }\n\n  .ht-search-form {\n    grid-template-columns: minmax(0, 1fr) auto auto;\n    padding: 10px;\n  }\n\n  .ht-search-input {\n    font-size: 14px;\n  }\n}\n";

  // src/lib/ui/panels/searchLauncher/searchLauncher.ts
  var SEARCH_MODE_LABELS = {
    recent: "RECENT",
    tab: "TAB",
    hist: "HISTORY",
    book: "BOOKMARK"
  };
  var COMMAND_DEFINITIONS = [
    { command: "book", hint: "search bookmarks" },
    { command: "hist", hint: "search history" },
    { command: "tab", hint: "search open tabs" }
  ];
  function parseLauncherInput(rawValue) {
    const committed = rawValue.match(/^\/(tab|hist|book)\s([\s\S]*)$/);
    if (committed) {
      const command = committed[1];
      return { kind: "fetch", mode: command, query: committed[2] };
    }
    if (rawValue.startsWith("/")) {
      return { kind: "commandMenu", filter: rawValue.slice(1).toLowerCase() };
    }
    return { kind: "fetch", mode: "recent", query: rawValue };
  }
  function domainFromUrl(url) {
    if (!url) return "";
    try {
      return new URL(url).hostname.replace(/^www\./, "");
    } catch (_) {
      return url;
    }
  }
  async function openTabWheelSearchLauncher() {
    const { host, shadow } = createPanelHost();
    const style = document.createElement("style");
    style.textContent = getBaseStyles() + searchLauncher_default;
    shadow.appendChild(style);
    const backdrop = document.createElement("div");
    backdrop.className = "ht-backdrop";
    shadow.appendChild(backdrop);
    const panel = document.createElement("div");
    panel.className = "ht-search-launcher";
    shadow.appendChild(panel);
    panel.innerHTML = `
    <div class="ht-search-hint">
      <span class="ht-search-hint-label">Filters:</span>
    </div>
    <form class="ht-search-form" id="ht-search-form">
      <div class="ht-search-field">
        <span class="ht-search-mode" hidden></span>
        <input class="ht-search-input" name="query" type="search" autocomplete="off" spellcheck="false" placeholder="Search or type / to apply filter..." autofocus />
      </div>
      <button class="ht-search-cancel" type="button">Cancel</button>
      <button class="ht-search-submit" type="submit">Search</button>
    </form>
    <div class="ht-search-suggest" hidden>
      <div class="ht-search-glow" aria-hidden="true"></div>
      <ul class="ht-search-list" role="listbox" aria-label="Search suggestions"></ul>
    </div>
    <div class="ht-search-status" role="status" aria-live="polite" hidden></div>
  `;
    const cancelButton = panel.querySelector(".ht-search-cancel");
    const submitButton = panel.querySelector(".ht-search-submit");
    const form = panel.querySelector(".ht-search-form");
    const input = panel.querySelector(".ht-search-input");
    const modeChip = panel.querySelector(".ht-search-mode");
    const hint = panel.querySelector(".ht-search-hint");
    const suggest = panel.querySelector(".ht-search-suggest");
    const glow = panel.querySelector(".ht-search-glow");
    const list = panel.querySelector(".ht-search-list");
    const status = panel.querySelector(".ht-search-status");
    let isSubmitting = false;
    let modalSession = null;
    let rows = [];
    let rowElements = [];
    let selectedIndex = -1;
    let requestSerial = 0;
    function isPanelAlive() {
      return document.getElementById("ht-panel-host") !== null;
    }
    function invalidateSuggestionRequests() {
      requestSerial += 1;
      return requestSerial;
    }
    function setStatus(message) {
      status.textContent = message;
      status.hidden = message.length === 0;
    }
    function setSubmitting(nextIsSubmitting) {
      isSubmitting = nextIsSubmitting;
      submitButton.disabled = nextIsSubmitting;
      input.disabled = nextIsSubmitting;
      form.setAttribute("aria-busy", String(nextIsSubmitting));
    }
    function focusSearchInput() {
      if (!isPanelAlive()) return;
      input.focus({ preventScroll: true });
    }
    function close() {
      invalidateSuggestionRequests();
      requestSuggestions.cancel();
      modalSession?.dispose();
      modalSession = null;
      removePanelHost();
    }
    function setModeChip(mode) {
      if (!mode) {
        modeChip.hidden = true;
        modeChip.textContent = "";
        return;
      }
      modeChip.textContent = SEARCH_MODE_LABELS[mode];
      modeChip.hidden = false;
    }
    function appendHighlightedText(target, text, positions) {
      const matched = new Set(positions);
      let run = "";
      let runMatched = false;
      const flush = () => {
        if (!run) return;
        if (runMatched) {
          const mark = document.createElement("span");
          mark.className = "ht-search-hit";
          mark.textContent = run;
          target.appendChild(mark);
        } else {
          target.appendChild(document.createTextNode(run));
        }
        run = "";
      };
      for (let index = 0; index < text.length; index += 1) {
        const isHit = matched.has(index);
        if (isHit !== runMatched) {
          flush();
          runMatched = isHit;
        }
        run += text[index];
      }
      flush();
    }
    function createRowIcon(row) {
      if (row.kind === "tab" && row.item.favIconUrl) {
        const favicon = document.createElement("img");
        favicon.className = "ht-search-favicon";
        favicon.src = row.item.favIconUrl;
        favicon.referrerPolicy = "no-referrer";
        favicon.alt = "";
        favicon.addEventListener("error", () => {
          favicon.replaceWith(createGlyphIcon(row));
        });
        return favicon;
      }
      return createGlyphIcon(row);
    }
    function createGlyphIcon(row) {
      const glyph = document.createElement("span");
      glyph.className = "ht-search-glyph";
      glyph.setAttribute("aria-hidden", "true");
      if (row.kind === "recent") glyph.textContent = "\u21BA";
      else if (row.kind === "tab" || row.kind === "link") glyph.textContent = domainFromUrl(row.item.secondary).slice(0, 1).toUpperCase() || "\u25B8";
      else if (row.kind === "web") glyph.textContent = "\u2315";
      else glyph.textContent = "\u203A";
      if (row.kind === "tab" || row.kind === "link") glyph.classList.add("ht-search-glyph-mono");
      return glyph;
    }
    function createRowElement(index) {
      const rowElement = document.createElement("li");
      rowElement.className = "ht-search-option";
      rowElement.id = `ht-search-option-${index}`;
      rowElement.setAttribute("role", "option");
      rowElement.style.setProperty("--i", String(index));
      wireRowInteractions(rowElement, index);
      return rowElement;
    }
    function fillRowContent(rowElement, row) {
      rowElement.replaceChildren();
      rowElement.appendChild(createRowIcon(row));
      const text = document.createElement("span");
      text.className = "ht-search-text";
      const primary = document.createElement("span");
      primary.className = "ht-search-primary";
      if (row.kind === "recent" || row.kind === "tab" || row.kind === "link") {
        appendHighlightedText(primary, row.item.primary, row.item.positions);
      } else if (row.kind === "web") {
        primary.textContent = `Search the web for "${row.query}"`;
      } else {
        primary.textContent = `/${row.command}`;
      }
      text.appendChild(primary);
      if ((row.kind === "tab" || row.kind === "link") && row.item.secondary) {
        const secondary = document.createElement("span");
        secondary.className = "ht-search-secondary";
        secondary.textContent = domainFromUrl(row.item.secondary);
        text.appendChild(secondary);
      } else if (row.kind === "command") {
        const definition = COMMAND_DEFINITIONS.find((entry) => entry.command === row.command);
        const hint2 = document.createElement("span");
        hint2.className = "ht-search-secondary";
        hint2.textContent = definition?.hint ?? "";
        text.appendChild(hint2);
      }
      rowElement.appendChild(text);
      appendRowKicker(rowElement, row);
    }
    function appendRowKicker(rowElement, row) {
      const kickerText = row.kind === "tab" ? "open tab" : row.kind === "web" ? "web search" : row.kind === "recent" ? "recent" : row.kind === "link" ? row.item.source === "hist" ? "history" : "bookmark" : "";
      if (!kickerText) return;
      const kicker = document.createElement("span");
      kicker.className = "ht-search-kicker";
      kicker.textContent = kickerText;
      rowElement.appendChild(kicker);
    }
    function wireRowInteractions(rowElement, index) {
      rowElement.addEventListener("mousedown", (event) => event.preventDefault());
      rowElement.addEventListener("mouseenter", () => setSelectedIndex(index));
      rowElement.addEventListener("click", () => {
        setSelectedIndex(index);
        activateSelection();
      });
    }
    function moveGlowToSelected() {
      const selected = rowElements[selectedIndex];
      if (!selected) {
        glow.classList.remove("is-visible");
        return;
      }
      glow.style.transform = `translateY(${selected.offsetTop}px)`;
      glow.style.height = `${selected.offsetHeight}px`;
      glow.classList.add("is-visible");
    }
    function setSelectedIndex(nextIndex) {
      if (rows.length === 0) {
        selectedIndex = -1;
        list.removeAttribute("aria-activedescendant");
        glow.classList.remove("is-visible");
        return;
      }
      selectedIndex = (nextIndex + rows.length) % rows.length;
      rowElements.forEach((rowElement, index) => {
        const isSelected = index === selectedIndex;
        rowElement.classList.toggle("is-selected", isSelected);
        rowElement.setAttribute("aria-selected", String(isSelected));
      });
      const selected = rowElements[selectedIndex];
      if (selected) {
        list.setAttribute("aria-activedescendant", selected.id);
        selected.scrollIntoView({ block: "nearest" });
      }
      moveGlowToSelected();
    }
    function showSuggest(visible) {
      suggest.hidden = !visible;
      if (!visible) glow.classList.remove("is-visible");
    }
    function renderRows(nextRows) {
      rows = nextRows;
      if (nextRows.length === 0) {
        rowElements.forEach((rowElement) => rowElement.remove());
        rowElements = [];
        selectedIndex = -1;
        showSuggest(false);
        return;
      }
      const nextElements = [];
      for (let index = 0; index < nextRows.length; index += 1) {
        let rowElement = rowElements[index];
        if (!rowElement) {
          rowElement = createRowElement(index);
          list.appendChild(rowElement);
        }
        fillRowContent(rowElement, nextRows[index]);
        nextElements.push(rowElement);
      }
      for (let index = nextRows.length; index < rowElements.length; index += 1) {
        rowElements[index].remove();
      }
      rowElements = nextElements;
      showSuggest(true);
      setSelectedIndex(0);
    }
    function renderCommandMenu(filter) {
      setModeChip(null);
      const matches = COMMAND_DEFINITIONS.filter((entry) => entry.command.startsWith(filter));
      const visible = matches.length > 0 ? matches : COMMAND_DEFINITIONS;
      renderRows(visible.map((entry) => ({ kind: "command", command: entry.command })));
    }
    function buildFetchRows(query, items) {
      const nextRows = items.map((item) => item.source === "tab" ? { kind: "tab", item } : item.source === "recent" ? { kind: "recent", item } : { kind: "link", item });
      const normalizedQuery = normalizeSearchQuery(query);
      if (normalizedQuery) nextRows.push({ kind: "web", query: normalizedQuery });
      return nextRows;
    }
    async function runFetch(state) {
      const serial = invalidateSuggestionRequests();
      const result = await getTabWheelSearchSuggestions(state.query, state.mode).catch(() => null);
      if (serial !== requestSerial || !isPanelAlive()) return;
      const items = result?.ok ? result.items : [];
      renderRows(buildFetchRows(state.query, items));
    }
    const requestSuggestions = createDebouncedCallback(
      (state) => void runFetch(state),
      140
    );
    function handleInput() {
      invalidateSuggestionRequests();
      setStatus("");
      const state = parseLauncherInput(input.value);
      if (state.kind === "commandMenu") {
        requestSuggestions.cancel();
        renderCommandMenu(state.filter);
        return;
      }
      setModeChip(state.mode === "recent" ? null : state.mode);
      requestSuggestions(state);
    }
    function insertCommand(command) {
      input.value = `/${command} `;
      focusSearchInput();
      handleInput();
    }
    function submitWebSearch(query) {
      const normalizedQuery = normalizeSearchQuery(query);
      if (!normalizedQuery) {
        setStatus("Enter a search query");
        input.focus({ preventScroll: true });
        return;
      }
      setSubmitting(true);
      setStatus("Opening search...");
      void openTabWheelSearchTab(query).then((result) => {
        if (result.ok) {
          close();
          return;
        }
        setStatus(result.reason || "Search unavailable");
      }).catch(() => setStatus("Search unavailable")).finally(() => {
        if (!isPanelAlive()) return;
        setSubmitting(false);
        focusSearchInput();
      });
    }
    function openTabSuggestion(item) {
      if (item.tabId == null) return;
      setSubmitting(true);
      setStatus("Switching tab...");
      void activateTabWheelTab(item.tabId).then((result) => {
        if (result.ok) {
          close();
          return;
        }
        setStatus(result.reason || "Tab unavailable");
      }).catch(() => setStatus("Tab unavailable")).finally(() => {
        if (!isPanelAlive()) return;
        setSubmitting(false);
        focusSearchInput();
      });
    }
    function openLinkSuggestion(item) {
      if (!item.url) return;
      setSubmitting(true);
      setStatus("Opening link...");
      void openTabWheelUrlTab(item.url).then((result) => {
        if (result.ok) {
          close();
          return;
        }
        setStatus(result.reason || "Link unavailable");
      }).catch(() => setStatus("Link unavailable")).finally(() => {
        if (!isPanelAlive()) return;
        setSubmitting(false);
        focusSearchInput();
      });
    }
    function activateSelection() {
      if (isSubmitting) return;
      const selected = rows[selectedIndex];
      if (!selected) {
        submitWebSearch(input.value);
        return;
      }
      if (selected.kind === "tab") openTabSuggestion(selected.item);
      else if (selected.kind === "link") openLinkSuggestion(selected.item);
      else if (selected.kind === "recent") submitWebSearch(selected.item.primary);
      else if (selected.kind === "web") submitWebSearch(selected.query);
      else insertCommand(selected.command);
    }
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      event.stopPropagation();
      activateSelection();
    });
    input.addEventListener("input", handleInput);
    input.addEventListener("keydown", (event) => {
      if (event.key === "ArrowDown") {
        event.preventDefault();
        setSelectedIndex(selectedIndex + 1);
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        setSelectedIndex(selectedIndex - 1);
      } else if (event.key === "Tab") {
        event.preventDefault();
        setSelectedIndex(selectedIndex + (event.shiftKey ? -1 : 1));
      }
    });
    cancelButton.addEventListener("click", close);
    backdrop.addEventListener("click", close);
    backdrop.addEventListener("mousedown", (event) => event.preventDefault());
    modalSession = createPanelModalSession({
      root: shadow,
      closeOnEscape: true,
      closeOnFullscreenChange: true,
      closeOnPageHide: true,
      closeOnVisibilityHidden: true,
      onClose: close
    });
    for (const definition of COMMAND_DEFINITIONS) {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "ht-search-hint-cmd";
      chip.textContent = `/${definition.command}`;
      chip.title = definition.hint;
      chip.addEventListener("mousedown", (event) => event.preventDefault());
      chip.addEventListener("click", () => insertCommand(definition.command));
      hint.appendChild(chip);
    }
    registerPanelCleanup(close);
    host.focus({ preventScroll: true });
    focusSearchInput();
    requestAnimationFrame(focusSearchInput);
    handleInput();
  }

  // src/lib/appInit/appInit.ts
  var SCROLL_SAVE_DEBOUNCE_MS = 700;
  var SCROLL_RESTORE_SUPPRESS_SAVE_MS = 450;
  var WHEEL_TRIGGER_THRESHOLD_PX = 80;
  var WHEEL_ACCELERATION_WINDOW_MS = 700;
  var STATUS_TIMEOUT_MS = 1500;
  var STATUS_ID = "tw-status-indicator";
  var SCROLL_RESTORE_DELAYS_MS = [0, 80, 220, 500, 900, 1500, 2400, 3600];
  var LAYOUT_STABILITY_TIMEOUT_MS = 1600;
  var LAYOUT_STABILITY_REQUIRED_FRAMES = 3;
  var LAYOUT_DIMENSION_TOLERANCE_PX = 4;
  var LAYOUT_DIMENSION_MATCH_RATIO = 0.08;
  var EVENT_MODIFIER_KEYS = ["alt", "ctrl", "shift", "meta"];
  function isEditableTarget(target) {
    if (!(target instanceof Element)) return false;
    const editable = target.closest(
      "input, textarea, select, [contenteditable=''], [contenteditable='true'], [role='textbox']"
    );
    return editable !== null;
  }
  function hasAnyWheelModifier(event) {
    return event.altKey || event.ctrlKey || event.shiftKey || event.metaKey;
  }
  function isTabWheelModifier(event, modifier, withShift) {
    const modifierState = {
      alt: event.altKey,
      ctrl: event.ctrlKey,
      shift: event.shiftKey,
      meta: event.metaKey
    };
    if (!TABWHEEL_MODIFIER_KEYS.includes(modifier)) return false;
    return EVENT_MODIFIER_KEYS.every((key) => {
      if (key === modifier) return modifierState[key];
      if (key === "shift") return modifierState.shift === withShift;
      return !modifierState[key];
    });
  }
  function clampScrollY(scrollY) {
    return Math.max(0, Math.min(scrollY, getMaxScrollY()));
  }
  function getPageScrollWidth() {
    const documentElement = document.documentElement;
    const body = document.body;
    return Math.max(
      documentElement?.scrollWidth || 0,
      body?.scrollWidth || 0,
      documentElement?.offsetWidth || 0,
      body?.offsetWidth || 0,
      documentElement?.clientWidth || 0,
      body?.clientWidth || 0
    );
  }
  function getPageScrollHeight() {
    const documentElement = document.documentElement;
    const body = document.body;
    return Math.max(
      documentElement?.scrollHeight || 0,
      body?.scrollHeight || 0,
      documentElement?.offsetHeight || 0,
      body?.offsetHeight || 0,
      documentElement?.clientHeight || 0,
      body?.clientHeight || 0
    );
  }
  function getMaxScrollX() {
    return Math.max(0, getPageScrollWidth() - window.innerWidth);
  }
  function getMaxScrollY() {
    return Math.max(0, getPageScrollHeight() - window.innerHeight);
  }
  function clampScrollX(scrollX) {
    return Math.max(0, Math.min(scrollX, getMaxScrollX()));
  }
  var PAGE_SCROLL_FILTER_BLOCKED_SELECTOR = [
    "input",
    "textarea",
    "select",
    "[contenteditable='']",
    "[contenteditable='true']",
    "[role='textbox']",
    "[role='slider']",
    "[role='spinbutton']",
    "[role='scrollbar']",
    "[role='application']",
    "iframe",
    "embed",
    "object",
    "video",
    "audio",
    "canvas",
    "[data-tabwheel-native-scroll='true']",
    "[class*='mapbox' i]",
    "[class*='leaflet' i]",
    "[class*='monaco' i]",
    "[class*='cm-editor' i]"
  ].join(",");
  function isPageScrollFilterBlockedTarget(target) {
    if (!(target instanceof Element)) return false;
    return target.closest(PAGE_SCROLL_FILTER_BLOCKED_SELECTOR) !== null;
  }
  function isScrollableOverflowY(value) {
    return value === "auto" || value === "scroll" || value === "overlay";
  }
  function getElementMaxScrollTop(element) {
    return Math.max(0, element.scrollHeight - element.clientHeight);
  }
  function canScrollElementVertically(element, direction) {
    if (direction === 0) return false;
    if (element === document.documentElement || element === document.body) return false;
    const maxScrollTop = getElementMaxScrollTop(element);
    if (maxScrollTop <= 1) return false;
    if (!isScrollableOverflowY(window.getComputedStyle(element).overflowY)) return false;
    return direction > 0 ? element.scrollTop < maxScrollTop - 1 : element.scrollTop > 1;
  }
  function canScrollWindowVertically(direction) {
    if (direction === 0) return false;
    const maxScrollY = getMaxScrollY();
    if (maxScrollY <= 1) return false;
    return direction > 0 ? window.scrollY < maxScrollY - 1 : window.scrollY > 1;
  }
  function getPageScrollPath(target, event) {
    const path = typeof event.composedPath === "function" ? event.composedPath() : [];
    const elements = path.filter((item) => item instanceof HTMLElement);
    if (elements.length > 0) return elements;
    const fallbackElements = [];
    let current = target instanceof HTMLElement ? target : null;
    while (current) {
      fallbackElements.push(current);
      current = current.parentElement;
    }
    return fallbackElements;
  }
  function resolvePageScrollTarget(event, direction) {
    for (const element of getPageScrollPath(event.target, event)) {
      if (canScrollElementVertically(element, direction)) {
        return { type: "element", element };
      }
    }
    return canScrollWindowVertically(direction) ? { type: "window" } : null;
  }
  function getPageScrollTargetViewportHeight(target) {
    return target.type === "window" ? window.innerHeight : target.element.clientHeight;
  }
  function scrollPageTarget(target, deltaY) {
    if (target.type === "window") {
      window.scrollTo({
        left: window.scrollX,
        top: clampScrollY(window.scrollY + deltaY),
        behavior: "auto"
      });
      return;
    }
    const maxScrollTop = getElementMaxScrollTop(target.element);
    target.element.scrollTop = Math.max(0, Math.min(maxScrollTop, target.element.scrollTop + deltaY));
  }
  function getRootScrollSnapshot() {
    const scrollX = Math.max(0, window.scrollX);
    const scrollY = Math.max(0, window.scrollY);
    const scrollWidth = getPageScrollWidth();
    const scrollHeight = getPageScrollHeight();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const maxScrollX = Math.max(0, scrollWidth - viewportWidth);
    const maxScrollY = Math.max(0, scrollHeight - viewportHeight);
    return {
      scrollX,
      scrollY,
      scrollRatioX: maxScrollX > 0 ? Math.max(0, Math.min(1, scrollX / maxScrollX)) : 0,
      scrollRatioY: maxScrollY > 0 ? Math.max(0, Math.min(1, scrollY / maxScrollY)) : 0,
      scrollWidth,
      scrollHeight,
      viewportWidth,
      viewportHeight
    };
  }
  function hasSimilarDimension(current, stored) {
    if (!Number.isFinite(stored) || stored <= 0) return false;
    return Math.abs(current - stored) <= Math.max(LAYOUT_DIMENSION_TOLERANCE_PX, stored * LAYOUT_DIMENSION_MATCH_RATIO);
  }
  function resolveRootScrollTarget(snapshot) {
    const current = getRootScrollSnapshot();
    const hasStoredWidth = snapshot.scrollWidth > 0 && snapshot.viewportWidth > 0;
    const hasStoredHeight = snapshot.scrollHeight > 0 && snapshot.viewportHeight > 0;
    const hasSimilarWidth = hasSimilarDimension(current.scrollWidth, snapshot.scrollWidth) && hasSimilarDimension(current.viewportWidth, snapshot.viewportWidth);
    const hasSimilarHeight = hasSimilarDimension(current.scrollHeight, snapshot.scrollHeight) && hasSimilarDimension(current.viewportHeight, snapshot.viewportHeight);
    const maxScrollX = Math.max(0, current.scrollWidth - current.viewportWidth);
    const maxScrollY = Math.max(0, current.scrollHeight - current.viewportHeight);
    const ratioX = Number.isFinite(snapshot.scrollRatioX) ? Math.max(0, Math.min(1, snapshot.scrollRatioX)) : 0;
    const ratioY = Number.isFinite(snapshot.scrollRatioY) ? Math.max(0, Math.min(1, snapshot.scrollRatioY)) : 0;
    return {
      left: !hasStoredWidth || hasSimilarWidth ? clampScrollX(snapshot.scrollX) : Math.round(maxScrollX * ratioX),
      top: !hasStoredHeight || hasSimilarHeight ? clampScrollY(snapshot.scrollY) : Math.round(maxScrollY * ratioY)
    };
  }
  async function waitForLayoutStability(shouldContinue) {
    const startedAt = performance.now();
    let stableFrames = 0;
    let previousWidth = getPageScrollWidth();
    let previousHeight = getPageScrollHeight();
    while (performance.now() - startedAt < LAYOUT_STABILITY_TIMEOUT_MS) {
      if (!shouldContinue()) return false;
      await new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
      if (!shouldContinue()) return false;
      const width = getPageScrollWidth();
      const height = getPageScrollHeight();
      if (Math.abs(width - previousWidth) <= LAYOUT_DIMENSION_TOLERANCE_PX && Math.abs(height - previousHeight) <= LAYOUT_DIMENSION_TOLERANCE_PX) {
        stableFrames += 1;
        if (stableFrames >= LAYOUT_STABILITY_REQUIRED_FRAMES) return true;
      } else {
        stableFrames = 0;
        previousWidth = width;
        previousHeight = height;
      }
    }
    return shouldContinue();
  }
  function suppressPageEvent(event) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
  }
  function isTabWheelPanelOpen() {
    return document.getElementById("ht-panel-host") !== null;
  }
  function isTopFrame() {
    try {
      return window.top === window;
    } catch (_) {
      return false;
    }
  }
  function initApp() {
    if (window.__tabWheelCleanup) {
      window.__tabWheelCleanup();
    }
    const isTopFrameContext = isTopFrame();
    let settings = { ...DEFAULT_TABWHEEL_SETTINGS };
    let statusTimer = 0;
    let scrollSaveTimer = 0;
    let lastScrollSaveX = Number.NaN;
    let lastScrollSaveY = Number.NaN;
    let suppressScrollSaveUntil = 0;
    let scrollRestoreToken = 0;
    let wheelAccumulator = 0;
    let lastWheelCycleAt = 0;
    let wheelBurstCount = 0;
    let areSettingsLoaded = false;
    let mouseGestureSession = null;
    let mouseGesturePolicies = MOUSE_GESTURE_POLICIES;
    const gestureFiredButtons = /* @__PURE__ */ new Set();
    void loadTabWheelSettings().then((loadedSettings) => {
      settings = loadedSettings;
      mouseGesturePolicies = buildMouseGesturePolicies(settings);
    }).finally(() => {
      areSettingsLoaded = true;
    });
    function showStatus(message) {
      let status = document.getElementById(STATUS_ID);
      if (!status) {
        status = document.createElement("div");
        status.id = STATUS_ID;
        status.setAttribute("role", "status");
        status.style.cssText = [
          "position:fixed",
          "left:50%",
          "top:50%",
          "transform:translate(-50%,-50%)",
          "z-index:2147483646",
          "width:min(360px,calc(100vw - 32px))",
          "min-height:42px",
          "display:flex",
          "align-items:center",
          "justify-content:center",
          "text-align:center",
          "padding:10px 14px",
          "border-radius:8px",
          "border:1px solid rgba(255,255,255,0.14)",
          "background:#1e1e1e",
          "color:#e0e0e0",
          "box-shadow:0 18px 54px rgba(0,0,0,0.44)",
          "font:12px/1.35 'SF Mono','JetBrains Mono','Fira Code','Consolas',monospace",
          "pointer-events:none"
        ].join(";");
        document.documentElement.appendChild(status);
      }
      status.textContent = message;
      if (statusTimer) window.clearTimeout(statusTimer);
      statusTimer = window.setTimeout(() => {
        status?.remove();
        statusTimer = 0;
      }, STATUS_TIMEOUT_MS);
    }
    function sendScrollSnapshot() {
      if (Date.now() < suppressScrollSaveUntil) return;
      const snapshot = getRootScrollSnapshot();
      if (snapshot.scrollX === lastScrollSaveX && snapshot.scrollY === lastScrollSaveY) return;
      lastScrollSaveX = snapshot.scrollX;
      lastScrollSaveY = snapshot.scrollY;
      void saveTabWheelScrollPosition(snapshot).catch(() => {
      });
    }
    function flushScrollSnapshot() {
      if (scrollSaveTimer) {
        window.clearTimeout(scrollSaveTimer);
        scrollSaveTimer = 0;
      }
      sendScrollSnapshot();
    }
    function scheduleScrollSnapshot() {
      if (Date.now() < suppressScrollSaveUntil) return;
      if (scrollSaveTimer) window.clearTimeout(scrollSaveTimer);
      scrollSaveTimer = window.setTimeout(() => {
        scrollSaveTimer = 0;
        sendScrollSnapshot();
      }, SCROLL_SAVE_DEBOUNCE_MS);
    }
    function cancelScrollRestore() {
      scrollRestoreToken += 1;
    }
    async function applyScrollRestoreAttempt(snapshot) {
      suppressScrollSaveUntil = Date.now() + SCROLL_RESTORE_SUPPRESS_SAVE_MS;
      if (scrollSaveTimer) {
        window.clearTimeout(scrollSaveTimer);
        scrollSaveTimer = 0;
      }
      const target = resolveRootScrollTarget(snapshot);
      window.scrollTo({
        left: target.left,
        top: target.top,
        behavior: "auto"
      });
      await new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
      return Math.abs(window.scrollX - target.left) <= 2 && Math.abs(window.scrollY - target.top) <= 2;
    }
    async function restoreWindowScroll(snapshot) {
      const token = ++scrollRestoreToken;
      const isCurrentRestore = () => token === scrollRestoreToken && document.visibilityState !== "hidden";
      if (!isCurrentRestore()) return;
      await applyScrollRestoreAttempt(snapshot);
      if (!isCurrentRestore()) return;
      if (!await waitForLayoutStability(isCurrentRestore)) return;
      for (const delay of SCROLL_RESTORE_DELAYS_MS) {
        if (!isCurrentRestore()) return;
        if (delay > 0) await sleep(delay);
        if (!isCurrentRestore()) return;
        if (await applyScrollRestoreAttempt(snapshot)) return;
      }
    }
    function isWheelGestureBlockedTarget(target) {
      return !settings.allowGesturesInEditableFields && isEditableTarget(target);
    }
    function isKeyboardWheelEvent(event) {
      return areSettingsLoaded && event.isTrusted && isTabWheelModifier(event, settings.gestureModifier, settings.gestureWithShift) && !isWheelGestureBlockedTarget(event.target);
    }
    function resolveMouseGesturePolicyForEvent(event) {
      if (!areSettingsLoaded) return null;
      if (isTabWheelPanelOpen()) return null;
      if (!event.isTrusted) return null;
      if (!isTabWheelModifier(event, settings.gestureModifier, settings.gestureWithShift)) return null;
      if (isWheelGestureBlockedTarget(event.target)) return null;
      return resolveMouseGesturePolicy(event.button, mouseGesturePolicies);
    }
    function resolvePanelSuppressedMouseGesturePolicy(event) {
      if (event.type === "contextmenu") {
        return mouseGesturePolicies.find((policy) => policy.runPhase === "contextmenu") || null;
      }
      return resolveMouseGesturePolicy(event.button, mouseGesturePolicies);
    }
    function shouldSuppressPanelMouseShortcut(event) {
      if (!areSettingsLoaded) return false;
      if (!isTabWheelPanelOpen()) return false;
      if (!event.isTrusted) return false;
      if (event.button === 0 && event.type !== "contextmenu") return false;
      if (!isTabWheelModifier(event, settings.gestureModifier, settings.gestureWithShift)) return false;
      return resolvePanelSuppressedMouseGesturePolicy(event) !== null;
    }
    function isMouseGestureSessionStartEvent(event) {
      return isMouseGestureSessionStartEventType(event.type);
    }
    function finishMouseGestureSession() {
      mouseGestureSession = null;
    }
    function resetWheelGestureState() {
      wheelAccumulator = 0;
      lastWheelCycleAt = 0;
      wheelBurstCount = 0;
    }
    function resetInputGestureState() {
      resetWheelGestureState();
      finishMouseGestureSession();
      gestureFiredButtons.clear();
    }
    function getActiveMouseGestureSession(event) {
      if (!mouseGestureSession) return null;
      if (isMouseGestureSessionExpired(mouseGestureSession, Date.now())) {
        finishMouseGestureSession();
        return null;
      }
      return isMouseGestureEventForSession(mouseGestureSession, event) ? mouseGestureSession : null;
    }
    function runMouseGestureSession(session) {
      if (session.hasRun) return;
      session.hasRun = true;
      gestureFiredButtons.add(session.policy.button);
      runMouseGestureAction(session.policy.action);
    }
    function runGestureActionWithStatus(task, failureStatus) {
      void task().then((result) => {
        if (!result.ok) showStatus(result.reason || failureStatus);
      }).catch(() => showStatus(failureStatus));
    }
    function runMouseGestureAction(action) {
      switch (action) {
        case "search":
          void openTabWheelSearchLauncher().catch(() => showStatus("Search unavailable"));
          return;
        case "recentTab":
          runGestureActionWithStatus(() => activateMostRecentTabWheelTab(), "Recent tab unavailable");
          return;
        case "nativeNewTab":
          runGestureActionWithStatus(() => openNativeNewTabWheelTab(), "New tab unavailable");
          return;
        case "duplicateTab":
          runGestureActionWithStatus(() => duplicateCurrentTabWheelTab(), "Duplicate unavailable");
          return;
        case "openSettings":
          runGestureActionWithStatus(() => openTabWheelOptions(), "Settings unavailable");
          return;
        case "closeToRecent":
          runGestureActionWithStatus(() => closeCurrentTabWheelTabAndActivateRecent(), "Close tab failed");
          return;
        default: {
          const unhandled = action;
        }
      }
    }
    function getTabCycleWheelDelta(event) {
      return normalizeWheelDelta(event, window.innerHeight, window.innerWidth, settings.horizontalWheel);
    }
    function computeNextBurstCount(now) {
      return now - lastWheelCycleAt <= WHEEL_ACCELERATION_WINDOW_MS ? Math.min(wheelBurstCount + 1, 6) : 0;
    }
    function getWheelTriggerDistance(now) {
      const baseDistance = resolveWheelTriggerDistance(WHEEL_TRIGGER_THRESHOLD_PX, settings.wheelSensitivity);
      return resolveAcceleratedWheelTriggerDistance(
        baseDistance,
        computeNextBurstCount(now),
        settings.wheelAcceleration
      );
    }
    function runWheelCycle(direction, now) {
      if (now - lastWheelCycleAt < settings.wheelCooldownMs) return false;
      wheelBurstCount = computeNextBurstCount(now);
      lastWheelCycleAt = now;
      if (isTabWheelPanelOpen()) dismissPanel();
      void cycleTabWheel(direction).catch(() => {
      });
      return true;
    }
    function handlePageScrollFilter(event) {
      if (!isTopFrameContext) return false;
      if (!areSettingsLoaded || !event.isTrusted || event.defaultPrevented) return false;
      if (hasAnyWheelModifier(event)) return false;
      if (isTabWheelPanelOpen()) return false;
      if (shouldUseNativePageScroll(settings.pageScrollSpeedMultiplier, settings.pageScrollViewportCapRatio)) return false;
      if (event.deltaY === 0) return false;
      if (isPageScrollFilterBlockedTarget(event.target)) return false;
      const scrollTarget = resolvePageScrollTarget(event, Math.sign(event.deltaY));
      if (!scrollTarget) return false;
      const viewportHeight = getPageScrollTargetViewportHeight(scrollTarget);
      const rawDeltaY = normalizeWheelDeltaY(event, viewportHeight);
      if (rawDeltaY === 0) return false;
      const scaledDeltaY = scalePageScrollDelta(
        rawDeltaY,
        settings.pageScrollSpeedMultiplier,
        viewportHeight,
        settings.pageScrollViewportCapRatio
      );
      if (scaledDeltaY === 0) return false;
      suppressPageEvent(event);
      scrollPageTarget(scrollTarget, scaledDeltaY);
      return true;
    }
    function wheelHandler(event) {
      if (!isKeyboardWheelEvent(event)) {
        handlePageScrollFilter(event);
        return;
      }
      const wheelDelta = getTabCycleWheelDelta(event);
      if (wheelDelta === 0) return;
      suppressPageEvent(event);
      const now = Date.now();
      wheelAccumulator += wheelDelta;
      const triggerDistance = getWheelTriggerDistance(now);
      if (Math.abs(wheelAccumulator) < triggerDistance) return;
      const direction = resolveWheelDirection(wheelAccumulator, settings.invertScroll);
      const cycleRan = runWheelCycle(direction, now);
      if (cycleRan || settings.overshootGuard) {
        wheelAccumulator = 0;
        return;
      }
      wheelAccumulator = Math.sign(wheelAccumulator) * Math.min(Math.abs(wheelAccumulator), triggerDistance);
    }
    function mouseGestureHandler(event) {
      if (shouldSuppressPanelMouseShortcut(event)) {
        suppressPageEvent(event);
        return;
      }
      const activeSession = getActiveMouseGestureSession(event);
      if (activeSession) {
        suppressPageEvent(event);
        if (shouldRunMouseGestureSession(activeSession, event.type)) runMouseGestureSession(activeSession);
        if (shouldFinishMouseGestureSession(activeSession, event.type)) finishMouseGestureSession();
        return;
      }
      const policy = resolveMouseGesturePolicyForEvent(event);
      if (!policy) return;
      suppressPageEvent(event);
      if (isMouseGestureSessionStartEvent(event)) {
        if (shouldSuppressRedundantGestureStart(event.type, event.button, gestureFiredButtons)) {
          return;
        }
        gestureFiredButtons.delete(event.button);
        mouseGestureSession = createMouseGestureSession(policy, Date.now());
        if (shouldRunMouseGestureSession(mouseGestureSession, event.type)) {
          runMouseGestureSession(mouseGestureSession);
        }
        if (shouldFinishMouseGestureSession(mouseGestureSession, event.type)) {
          finishMouseGestureSession();
        }
      }
    }
    function storageChangedHandler(changes, areaName) {
      if (areaName !== "local") return;
      const settingsChange = changes[TABWHEEL_STORAGE_KEYS.settings];
      if (settingsChange) {
        settings = normalizeTabWheelSettings(settingsChange.newValue);
        mouseGesturePolicies = buildMouseGesturePolicies(settings);
        resetInputGestureState();
      }
    }
    function messageHandler(message) {
      const receivedMessage = message;
      switch (receivedMessage.type) {
        case "TABWHEEL_PING":
          return Promise.resolve({ ok: true });
        case "GET_SCROLL":
          return Promise.resolve(getRootScrollSnapshot());
        case "SET_SCROLL":
          void restoreWindowScroll(receivedMessage);
          return Promise.resolve({ ok: true });
        case "TABWHEEL_STATUS":
          showStatus(receivedMessage.message);
          return Promise.resolve({ ok: true });
        case "TABWHEEL_DISMISS_PANEL":
          dismissPanel();
          return Promise.resolve({ ok: true });
      }
    }
    function visibilityHandler() {
      if (document.visibilityState !== "hidden") return;
      cancelScrollRestore();
      resetInputGestureState();
      if (!isTopFrameContext) return;
      flushScrollSnapshot();
      dismissPanel();
    }
    function pageHideHandler() {
      cancelScrollRestore();
      flushScrollSnapshot();
    }
    function beforeUnloadHandler() {
      cancelScrollRestore();
      flushScrollSnapshot();
    }
    window.addEventListener("pointerdown", mouseGestureHandler, true);
    window.addEventListener("mousedown", mouseGestureHandler, true);
    window.addEventListener("pointerup", mouseGestureHandler, true);
    window.addEventListener("mouseup", mouseGestureHandler, true);
    window.addEventListener("click", mouseGestureHandler, true);
    window.addEventListener("auxclick", mouseGestureHandler, true);
    window.addEventListener("contextmenu", mouseGestureHandler, true);
    window.addEventListener("wheel", wheelHandler, { passive: false, capture: true });
    document.addEventListener("visibilitychange", visibilityHandler);
    import_webextension_polyfill4.default.storage.onChanged.addListener(storageChangedHandler);
    if (isTopFrameContext) {
      window.addEventListener("scroll", scheduleScrollSnapshot, { passive: true, capture: true });
      window.addEventListener("pagehide", pageHideHandler);
      window.addEventListener("beforeunload", beforeUnloadHandler);
      import_webextension_polyfill4.default.runtime.onMessage.addListener(messageHandler);
    }
    window.__tabWheelCleanup = () => {
      window.removeEventListener("pointerdown", mouseGestureHandler, true);
      window.removeEventListener("mousedown", mouseGestureHandler, true);
      window.removeEventListener("pointerup", mouseGestureHandler, true);
      window.removeEventListener("mouseup", mouseGestureHandler, true);
      window.removeEventListener("click", mouseGestureHandler, true);
      window.removeEventListener("auxclick", mouseGestureHandler, true);
      window.removeEventListener("contextmenu", mouseGestureHandler, true);
      window.removeEventListener("wheel", wheelHandler, true);
      document.removeEventListener("visibilitychange", visibilityHandler);
      import_webextension_polyfill4.default.storage.onChanged.removeListener(storageChangedHandler);
      if (isTopFrameContext) {
        window.removeEventListener("scroll", scheduleScrollSnapshot, true);
        window.removeEventListener("pagehide", pageHideHandler);
        window.removeEventListener("beforeunload", beforeUnloadHandler);
        import_webextension_polyfill4.default.runtime.onMessage.removeListener(messageHandler);
      }
      cancelScrollRestore();
      if (scrollSaveTimer) window.clearTimeout(scrollSaveTimer);
      if (statusTimer) window.clearTimeout(statusTimer);
      document.getElementById(STATUS_ID)?.remove();
      dismissPanel();
    };
    if (isTopFrameContext) {
      void import_webextension_polyfill4.default.runtime.sendMessage({ type: "TABWHEEL_CONTENT_READY" }).catch(() => {
      });
    }
  }

  // src/entryPoints/contentScript/contentScript.ts
  initApp();
})();

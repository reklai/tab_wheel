"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/appInit/appInit.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabWheel.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var TABWHEEL_STORAGE_KEYS = {
    settings: "tabWheelSettings",
    scrollMemory: "tabWheelScrollMemory",
    mruState: "tabWheelMruState",
    onboarding: "tabWheelOnboarding"
  };
  var TABWHEEL_MODIFIER_KEYS = ["alt", "ctrl", "meta"];
  var TABWHEEL_CYCLE_SCOPES = ["general", "mru"];
  var TABWHEEL_PRESETS = ["precise", "balanced", "fast", "custom"];
  var TABWHEEL_MIDDLE_CLICK_ACTIONS = ["openSettings", "none"];
  var MIN_WHEEL_SENSITIVITY = 0.5;
  var MAX_WHEEL_SENSITIVITY = 2;
  var MIN_WHEEL_COOLDOWN_MS = 60;
  var MAX_WHEEL_COOLDOWN_MS = 400;
  var TABWHEEL_PRESET_VALUES = {
    precise: {
      wheelSensitivity: 0.8,
      wheelCooldownMs: 220,
      wheelAcceleration: false,
      overshootGuard: true
    },
    balanced: {
      wheelSensitivity: 1,
      wheelCooldownMs: 160,
      wheelAcceleration: false,
      overshootGuard: true
    },
    fast: {
      wheelSensitivity: 1.35,
      wheelCooldownMs: 90,
      wheelAcceleration: true,
      overshootGuard: true
    }
  };
  var DEFAULT_TABWHEEL_SETTINGS = {
    invertScroll: false,
    gestureModifier: "alt",
    gestureWithShift: false,
    allowGesturesInEditableFields: true,
    middleClickAction: "openSettings",
    cycleScope: "general",
    restorePagePosition: true,
    skipPinnedTabs: false,
    skipRestrictedPages: true,
    skipHiddenTabs: true,
    showRestrictedBadge: true,
    wrapAround: true,
    cycleWithinTabGroup: false,
    wheelPreset: "balanced",
    wheelSensitivity: 1,
    wheelCooldownMs: 160,
    wheelAcceleration: false,
    horizontalWheel: true,
    overshootGuard: true
  };
  function normalizeModifierKey(value) {
    return TABWHEEL_MODIFIER_KEYS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.gestureModifier;
  }
  function normalizeEnabledFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeNumberInRange(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }
  function normalizeTabWheelCycleScope(value) {
    return TABWHEEL_CYCLE_SCOPES.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.cycleScope;
  }
  function normalizeWheelPreset(value) {
    return TABWHEEL_PRESETS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.wheelPreset;
  }
  function normalizeMiddleClickAction(value) {
    return TABWHEEL_MIDDLE_CLICK_ACTIONS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.middleClickAction;
  }
  function detectTabWheelPreset(settings) {
    for (const preset of ["precise", "balanced", "fast"]) {
      const values = TABWHEEL_PRESET_VALUES[preset];
      if (settings.wheelSensitivity === values.wheelSensitivity && settings.wheelCooldownMs === values.wheelCooldownMs && settings.wheelAcceleration === values.wheelAcceleration && settings.overshootGuard === values.overshootGuard) {
        return preset;
      }
    }
    return "custom";
  }
  function normalizeTabWheelSettings(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
    const settings = value;
    const normalized = {
      invertScroll: settings.invertScroll === true,
      gestureModifier: normalizeModifierKey(settings.gestureModifier),
      gestureWithShift: settings.gestureWithShift === true,
      allowGesturesInEditableFields: true,
      middleClickAction: normalizeMiddleClickAction(settings.middleClickAction),
      cycleScope: normalizeTabWheelCycleScope(settings.cycleScope),
      restorePagePosition: true,
      skipPinnedTabs: normalizeEnabledFlag(settings.skipPinnedTabs, DEFAULT_TABWHEEL_SETTINGS.skipPinnedTabs),
      skipRestrictedPages: true,
      skipHiddenTabs: normalizeEnabledFlag(settings.skipHiddenTabs, DEFAULT_TABWHEEL_SETTINGS.skipHiddenTabs),
      showRestrictedBadge: true,
      wrapAround: normalizeEnabledFlag(settings.wrapAround, DEFAULT_TABWHEEL_SETTINGS.wrapAround),
      cycleWithinTabGroup: normalizeEnabledFlag(
        settings.cycleWithinTabGroup,
        DEFAULT_TABWHEEL_SETTINGS.cycleWithinTabGroup
      ),
      wheelPreset: normalizeWheelPreset(settings.wheelPreset),
      wheelSensitivity: normalizeNumberInRange(
        settings.wheelSensitivity,
        DEFAULT_TABWHEEL_SETTINGS.wheelSensitivity,
        MIN_WHEEL_SENSITIVITY,
        MAX_WHEEL_SENSITIVITY
      ),
      wheelCooldownMs: normalizeNumberInRange(
        settings.wheelCooldownMs,
        DEFAULT_TABWHEEL_SETTINGS.wheelCooldownMs,
        MIN_WHEEL_COOLDOWN_MS,
        MAX_WHEEL_COOLDOWN_MS
      ),
      wheelAcceleration: normalizeEnabledFlag(
        settings.wheelAcceleration,
        DEFAULT_TABWHEEL_SETTINGS.wheelAcceleration
      ),
      horizontalWheel: true,
      overshootGuard: true
    };
    normalized.wheelPreset = settings.wheelPreset == null ? detectTabWheelPreset(normalized) : normalized.wheelPreset;
    return normalized;
  }
  async function loadTabWheelSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.settings);
      return normalizeTabWheelSettings(data[TABWHEEL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
  }

  // src/lib/common/utils/asyncFlow.ts
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // src/lib/core/tabWheel/tabWheelCore.ts
  function isTabWheelModifier(event, modifier, withShift) {
    const expected = {
      altKey: modifier === "alt",
      ctrlKey: modifier === "ctrl",
      metaKey: modifier === "meta",
      shiftKey: withShift
    };
    return event.altKey === expected.altKey && event.ctrlKey === expected.ctrlKey && event.metaKey === expected.metaKey && event.shiftKey === expected.shiftKey;
  }
  function resolveWheelDirection(wheelDelta, invertScroll) {
    const normalDirection = wheelDelta > 0 ? "next" : "prev";
    if (!invertScroll) return normalDirection;
    return normalDirection === "next" ? "prev" : "next";
  }
  function normalizeWheelDelta(event, pageHeight, pageWidth, horizontalWheel) {
    const modeMultiplierY = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? pageHeight : 1;
    const normalizedY = event.deltaY * modeMultiplierY;
    if (!horizontalWheel) return normalizedY;
    const modeMultiplierX = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? pageWidth : 1;
    const normalizedX = event.deltaX * modeMultiplierX;
    return Math.abs(normalizedX) > Math.abs(normalizedY) ? normalizedX : normalizedY;
  }
  function resolveWheelTriggerDistance(baseThresholdPx, sensitivity) {
    const safeSensitivity = Number.isFinite(sensitivity) && sensitivity > 0 ? sensitivity : 1;
    return Math.max(1, baseThresholdPx / safeSensitivity);
  }
  var MAX_BURST_COUNT = 6;
  var BURST_REDUCTION_PX_PER_BURST = 6;
  var MIN_ACCELERATED_TRIGGER_DISTANCE_PX = 40;
  function resolveAcceleratedWheelTriggerDistance(triggerDistancePx, burstCount, isAccelerationEnabled) {
    if (!isAccelerationEnabled) return triggerDistancePx;
    const cappedBurstCount = Math.max(0, Math.min(MAX_BURST_COUNT, burstCount));
    return Math.max(
      MIN_ACCELERATED_TRIGGER_DISTANCE_PX,
      triggerDistancePx - cappedBurstCount * BURST_REDUCTION_PX_PER_BURST
    );
  }

  // src/lib/core/tabWheel/middleClickCore.ts
  var MIDDLE_CLICK_CLAIM_MS = 900;
  function isMiddleClickEvent(event) {
    return event.button === 1;
  }
  function isMiddleClickSessionStartEvent(event) {
    return isMiddleClickEvent(event) && (event.type === "pointerdown" || event.type === "mousedown" || event.type === "auxclick");
  }
  function createMiddleClickSession(startedAt) {
    return { startedAt, hasRun: false };
  }
  function isMiddleClickSessionExpired(session, now, claimMs = MIDDLE_CLICK_CLAIM_MS) {
    return now - session.startedAt > claimMs;
  }
  function shouldRunMiddleClickSession(session, event) {
    return !session.hasRun && isMiddleClickEvent(event) && event.type === "auxclick";
  }
  function shouldFinishMiddleClickSession(event) {
    return isMiddleClickEvent(event) && (event.type === "auxclick" || event.type === "click");
  }

  // src/lib/core/tabWheel/momentumGuardCore.ts
  var DEFAULT_MOMENTUM_GUARD_TUNING = {
    maxTailGapMs: 24,
    rampRatio: 1.3,
    steadyDecayFraction: 0.08,
    steadyEventCount: 4
  };
  function createMomentumGuardSession(committedAtMs, direction, seedMagnitudePx) {
    const seed = Number.isFinite(seedMagnitudePx) ? Math.abs(seedMagnitudePx) : 0;
    return {
      direction,
      // With no envelope carried from the committing gesture there is nothing to
      // measure a tail against, so the guard stays out of the way entirely.
      active: seed > 0,
      lastEventAtMs: committedAtMs,
      envelopeMagnitudePx: seed,
      recentMagnitudesPx: []
    };
  }
  function signOfDelta(deltaPx) {
    if (deltaPx > 0) return 1;
    if (deltaPx < 0) return -1;
    return 0;
  }
  function reArm(session) {
    session.active = false;
  }
  function shouldBlockWheelDelta(session, deltaPx, nowMs, tuning) {
    const gapMs = nowMs - session.lastEventAtMs;
    session.lastEventAtMs = nowMs;
    if (gapMs > tuning.maxTailGapMs) reArm(session);
    if (!session.active) return false;
    const deltaSign = signOfDelta(deltaPx);
    if (deltaSign !== 0 && deltaSign !== session.direction) {
      reArm(session);
      return false;
    }
    const magnitude = Math.abs(deltaPx);
    if (magnitude > session.envelopeMagnitudePx * tuning.rampRatio) {
      reArm(session);
      return false;
    }
    session.envelopeMagnitudePx = magnitude;
    const recent = session.recentMagnitudesPx;
    recent.push(magnitude);
    while (recent.length > tuning.steadyEventCount) recent.shift();
    if (recent.length < tuning.steadyEventCount) return true;
    const oldestMagnitude = recent[0];
    const netDecay = oldestMagnitude > 0 ? 1 - magnitude / oldestMagnitude : 0;
    if (netDecay < tuning.steadyDecayFraction) {
      reArm(session);
      return false;
    }
    return true;
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill2.default.runtime.sendMessage(message);
  }

  // src/lib/adapters/runtime/tabWheelApi.ts
  function notifyTabWheelContentReady() {
    return sendRuntimeMessage({ type: "TABWHEEL_CONTENT_READY" });
  }
  function cycleTabWheel(direction, source = "gesture") {
    return sendRuntimeMessage({
      type: "TABWHEEL_CYCLE",
      direction,
      source
    });
  }
  function saveTabWheelScrollPosition(scroll) {
    return sendRuntimeMessage({
      type: "TABWHEEL_SAVE_SCROLL_POSITION",
      ...scroll
    });
  }
  function openTabWheelOptions() {
    return sendRuntimeMessage({ type: "TABWHEEL_OPEN_OPTIONS" });
  }

  // src/lib/appInit/appInit.ts
  var SCROLL_SAVE_DEBOUNCE_MS = 700;
  var SCROLL_RESTORE_SUPPRESS_SAVE_MS = 450;
  var WHEEL_TRIGGER_THRESHOLD_PX = 80;
  var WHEEL_ARRIVAL_GUARD_WINDOW_MS = 32;
  var WORKER_PREWARM_INTERVAL_MS = 15e3;
  var WHEEL_ACCELERATION_WINDOW_MS = 700;
  var STATUS_TIMEOUT_MS = 1500;
  var STATUS_ID = "tw-status-indicator";
  var SCROLL_RESTORE_DELAYS_MS = [0, 80, 220, 500, 900, 1500, 2400, 3600];
  var LAYOUT_STABILITY_TIMEOUT_MS = 1600;
  var LAYOUT_STABILITY_REQUIRED_FRAMES = 3;
  var LAYOUT_DIMENSION_TOLERANCE_PX = 4;
  var LAYOUT_DIMENSION_MATCH_RATIO = 0.08;
  function isEditableTarget(target) {
    if (!(target instanceof Element)) return false;
    return target.closest(
      "input, textarea, select, [contenteditable=''], [contenteditable='true'], [role='textbox']"
    ) !== null;
  }
  function getPageScrollWidth() {
    const documentElement = document.documentElement;
    const body = document.body;
    return Math.max(
      documentElement?.scrollWidth || 0,
      body?.scrollWidth || 0,
      documentElement?.offsetWidth || 0,
      body?.offsetWidth || 0,
      documentElement?.clientWidth || 0,
      body?.clientWidth || 0
    );
  }
  function getPageScrollHeight() {
    const documentElement = document.documentElement;
    const body = document.body;
    return Math.max(
      documentElement?.scrollHeight || 0,
      body?.scrollHeight || 0,
      documentElement?.offsetHeight || 0,
      body?.offsetHeight || 0,
      documentElement?.clientHeight || 0,
      body?.clientHeight || 0
    );
  }
  function getMaxScrollX() {
    return Math.max(0, getPageScrollWidth() - window.innerWidth);
  }
  function getMaxScrollY() {
    return Math.max(0, getPageScrollHeight() - window.innerHeight);
  }
  function clampScrollX(scrollX) {
    return Math.max(0, Math.min(scrollX, getMaxScrollX()));
  }
  function clampScrollY(scrollY) {
    return Math.max(0, Math.min(scrollY, getMaxScrollY()));
  }
  function getRootScrollSnapshot() {
    const scrollX = Math.max(0, window.scrollX);
    const scrollY = Math.max(0, window.scrollY);
    const scrollWidth = getPageScrollWidth();
    const scrollHeight = getPageScrollHeight();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const maxScrollX = Math.max(0, scrollWidth - viewportWidth);
    const maxScrollY = Math.max(0, scrollHeight - viewportHeight);
    return {
      scrollX,
      scrollY,
      scrollRatioX: maxScrollX > 0 ? Math.max(0, Math.min(1, scrollX / maxScrollX)) : 0,
      scrollRatioY: maxScrollY > 0 ? Math.max(0, Math.min(1, scrollY / maxScrollY)) : 0,
      scrollWidth,
      scrollHeight,
      viewportWidth,
      viewportHeight
    };
  }
  function hasSimilarDimension(current, stored) {
    if (!Number.isFinite(stored) || stored <= 0) return false;
    return Math.abs(current - stored) <= Math.max(LAYOUT_DIMENSION_TOLERANCE_PX, stored * LAYOUT_DIMENSION_MATCH_RATIO);
  }
  function resolveRootScrollTarget(snapshot) {
    const current = getRootScrollSnapshot();
    const hasStoredWidth = snapshot.scrollWidth > 0 && snapshot.viewportWidth > 0;
    const hasStoredHeight = snapshot.scrollHeight > 0 && snapshot.viewportHeight > 0;
    const hasSimilarWidth = hasSimilarDimension(current.scrollWidth, snapshot.scrollWidth) && hasSimilarDimension(current.viewportWidth, snapshot.viewportWidth);
    const hasSimilarHeight = hasSimilarDimension(current.scrollHeight, snapshot.scrollHeight) && hasSimilarDimension(current.viewportHeight, snapshot.viewportHeight);
    const maxScrollX = Math.max(0, current.scrollWidth - current.viewportWidth);
    const maxScrollY = Math.max(0, current.scrollHeight - current.viewportHeight);
    const ratioX = Number.isFinite(snapshot.scrollRatioX) ? Math.max(0, Math.min(1, snapshot.scrollRatioX)) : 0;
    const ratioY = Number.isFinite(snapshot.scrollRatioY) ? Math.max(0, Math.min(1, snapshot.scrollRatioY)) : 0;
    return {
      left: !hasStoredWidth || hasSimilarWidth ? clampScrollX(snapshot.scrollX) : Math.round(maxScrollX * ratioX),
      top: !hasStoredHeight || hasSimilarHeight ? clampScrollY(snapshot.scrollY) : Math.round(maxScrollY * ratioY)
    };
  }
  async function waitForLayoutStability(shouldContinue) {
    const startedAt = performance.now();
    let stableFrames = 0;
    let previousWidth = getPageScrollWidth();
    let previousHeight = getPageScrollHeight();
    while (performance.now() - startedAt < LAYOUT_STABILITY_TIMEOUT_MS) {
      if (!shouldContinue()) return false;
      await new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
      if (!shouldContinue()) return false;
      const width = getPageScrollWidth();
      const height = getPageScrollHeight();
      if (Math.abs(width - previousWidth) <= LAYOUT_DIMENSION_TOLERANCE_PX && Math.abs(height - previousHeight) <= LAYOUT_DIMENSION_TOLERANCE_PX) {
        stableFrames += 1;
        if (stableFrames >= LAYOUT_STABILITY_REQUIRED_FRAMES) return true;
      } else {
        stableFrames = 0;
        previousWidth = width;
        previousHeight = height;
      }
    }
    return shouldContinue();
  }
  function suppressPageEvent(event) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
  }
  function isTopFrame() {
    try {
      return window.top === window;
    } catch (_) {
      return false;
    }
  }
  function initApp() {
    window.__tabWheelCleanup?.();
    const isTopFrameContext = isTopFrame();
    let settings = { ...DEFAULT_TABWHEEL_SETTINGS };
    let areSettingsLoaded = false;
    let statusTimer = 0;
    let scrollSaveTimer = 0;
    let lastScrollSaveX = Number.NaN;
    let lastScrollSaveY = Number.NaN;
    let suppressScrollSaveUntil = 0;
    let scrollRestoreToken = 0;
    let wheelAccumulator = 0;
    let lastGestureMagnitudePx = 0;
    let lastVisibleAtMs = 0;
    let lastWorkerPrewarmAt = 0;
    let lastWheelCycleAt = 0;
    let wheelBurstCount = 0;
    let middleClickSession = null;
    let momentumGuardSession = null;
    void loadTabWheelSettings().then((loadedSettings) => {
      settings = loadedSettings;
    }).finally(() => {
      areSettingsLoaded = true;
    });
    function showStatus(message) {
      let status = document.getElementById(STATUS_ID);
      if (!status) {
        status = document.createElement("div");
        status.id = STATUS_ID;
        status.setAttribute("role", "status");
        status.style.cssText = [
          "position:fixed",
          "left:50%",
          "top:50%",
          "transform:translate(-50%,-50%)",
          "z-index:2147483646",
          "width:min(360px,calc(100vw - 32px))",
          "min-height:42px",
          "display:flex",
          "align-items:center",
          "justify-content:center",
          "text-align:center",
          "padding:10px 14px",
          "border-radius:8px",
          "border:1px solid rgba(255,255,255,0.14)",
          "background:#1e1e1e",
          "color:#e0e0e0",
          "box-shadow:0 18px 54px rgba(0,0,0,0.44)",
          "font:12px/1.35 system-ui,sans-serif",
          "pointer-events:none"
        ].join(";");
        document.documentElement.appendChild(status);
      }
      status.textContent = message;
      if (statusTimer) window.clearTimeout(statusTimer);
      statusTimer = window.setTimeout(() => {
        status?.remove();
        statusTimer = 0;
      }, STATUS_TIMEOUT_MS);
    }
    function sendScrollSnapshot() {
      if (!settings.restorePagePosition || Date.now() < suppressScrollSaveUntil) return;
      const snapshot = getRootScrollSnapshot();
      if (snapshot.scrollX === lastScrollSaveX && snapshot.scrollY === lastScrollSaveY) return;
      lastScrollSaveX = snapshot.scrollX;
      lastScrollSaveY = snapshot.scrollY;
      void saveTabWheelScrollPosition(snapshot).catch(() => {
      });
    }
    function flushScrollSnapshot() {
      if (scrollSaveTimer) {
        window.clearTimeout(scrollSaveTimer);
        scrollSaveTimer = 0;
      }
      sendScrollSnapshot();
    }
    function scheduleScrollSnapshot() {
      if (!settings.restorePagePosition || Date.now() < suppressScrollSaveUntil) return;
      if (scrollSaveTimer) window.clearTimeout(scrollSaveTimer);
      scrollSaveTimer = window.setTimeout(() => {
        scrollSaveTimer = 0;
        sendScrollSnapshot();
      }, SCROLL_SAVE_DEBOUNCE_MS);
    }
    function cancelScrollRestore() {
      scrollRestoreToken += 1;
    }
    async function applyScrollRestoreAttempt(snapshot) {
      suppressScrollSaveUntil = Date.now() + SCROLL_RESTORE_SUPPRESS_SAVE_MS;
      if (scrollSaveTimer) {
        window.clearTimeout(scrollSaveTimer);
        scrollSaveTimer = 0;
      }
      const target = resolveRootScrollTarget(snapshot);
      window.scrollTo({ left: target.left, top: target.top, behavior: "auto" });
      await new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
      return Math.abs(window.scrollX - target.left) <= 2 && Math.abs(window.scrollY - target.top) <= 2;
    }
    async function restoreWindowScroll(snapshot) {
      if (!settings.restorePagePosition) return;
      const token = ++scrollRestoreToken;
      const isCurrentRestore = () => token === scrollRestoreToken && document.visibilityState !== "hidden" && settings.restorePagePosition;
      if (!isCurrentRestore()) return;
      await applyScrollRestoreAttempt(snapshot);
      if (!isCurrentRestore() || !await waitForLayoutStability(isCurrentRestore)) return;
      for (const delay of SCROLL_RESTORE_DELAYS_MS) {
        if (!isCurrentRestore()) return;
        if (delay > 0) await sleep(delay);
        if (!isCurrentRestore()) return;
        if (await applyScrollRestoreAttempt(snapshot)) return;
      }
    }
    function isKeyboardWheelEvent(event) {
      return areSettingsLoaded && event.isTrusted && isTabWheelModifier(event, settings.gestureModifier, settings.gestureWithShift) && (settings.allowGesturesInEditableFields || !isEditableTarget(event.target));
    }
    function isEnabledMiddleClickEvent(event) {
      return areSettingsLoaded && settings.middleClickAction === "openSettings" && event.isTrusted && isMiddleClickEvent(event) && isTabWheelModifier(event, settings.gestureModifier, settings.gestureWithShift) && (settings.allowGesturesInEditableFields || !isEditableTarget(event.target));
    }
    function resetMiddleClickSession() {
      middleClickSession = null;
    }
    function getActiveMiddleClickSession(event) {
      if (!middleClickSession) return null;
      if (isMiddleClickSessionExpired(middleClickSession, Date.now())) {
        resetMiddleClickSession();
        return null;
      }
      return isMiddleClickEvent(event) ? middleClickSession : null;
    }
    function openSettingsFromMiddleClick(session) {
      if (session.hasRun) return;
      session.hasRun = true;
      void openTabWheelOptions().then((result) => {
        if (!result.ok) showStatus(result.reason || "Settings unavailable");
      }).catch(() => showStatus("Settings unavailable"));
    }
    function middleClickHandler(event) {
      const activeSession = getActiveMiddleClickSession(event);
      if (activeSession) {
        suppressPageEvent(event);
        if (shouldRunMiddleClickSession(activeSession, event)) {
          openSettingsFromMiddleClick(activeSession);
        }
        if (shouldFinishMiddleClickSession(event)) resetMiddleClickSession();
        return;
      }
      if (!isMiddleClickSessionStartEvent(event) || !isEnabledMiddleClickEvent(event)) return;
      suppressPageEvent(event);
      middleClickSession = createMiddleClickSession(Date.now());
      if (shouldRunMiddleClickSession(middleClickSession, event)) {
        openSettingsFromMiddleClick(middleClickSession);
      }
      if (shouldFinishMiddleClickSession(event)) resetMiddleClickSession();
    }
    function computeNextBurstCount(now) {
      return now - lastWheelCycleAt <= WHEEL_ACCELERATION_WINDOW_MS ? Math.min(wheelBurstCount + 1, 6) : 0;
    }
    function runWheelCycle(direction, deltaDirection, now) {
      if (now - lastWheelCycleAt < settings.wheelCooldownMs) return false;
      wheelBurstCount = computeNextBurstCount(now);
      lastWheelCycleAt = now;
      momentumGuardSession = createMomentumGuardSession(now, deltaDirection, lastGestureMagnitudePx);
      void cycleTabWheel(direction, "gesture").catch(() => {
      });
      return true;
    }
    function wheelHandler(event) {
      if (!isKeyboardWheelEvent(event)) return;
      const wheelDelta = normalizeWheelDelta(
        event,
        window.innerHeight,
        window.innerWidth,
        settings.horizontalWheel
      );
      if (wheelDelta === 0) return;
      const now = Date.now();
      suppressPageEvent(event);
      if (isTopFrameContext && now - lastWorkerPrewarmAt >= WORKER_PREWARM_INTERVAL_MS) {
        lastWorkerPrewarmAt = now;
        void notifyTabWheelContentReady().catch(() => {
        });
      }
      if (!momentumGuardSession && event.deltaMode === 0 && now - lastVisibleAtMs <= WHEEL_ARRIVAL_GUARD_WINDOW_MS) {
        momentumGuardSession = createMomentumGuardSession(
          now,
          wheelDelta > 0 ? 1 : -1,
          Math.abs(wheelDelta)
        );
        return;
      }
      if (momentumGuardSession && shouldBlockWheelDelta(
        momentumGuardSession,
        wheelDelta,
        now,
        DEFAULT_MOMENTUM_GUARD_TUNING
      )) {
        return;
      }
      wheelAccumulator += wheelDelta;
      lastGestureMagnitudePx = Math.abs(wheelDelta);
      const baseDistance = resolveWheelTriggerDistance(
        WHEEL_TRIGGER_THRESHOLD_PX,
        settings.wheelSensitivity
      );
      const acceleratedDistance = resolveAcceleratedWheelTriggerDistance(
        baseDistance,
        computeNextBurstCount(now),
        settings.wheelAcceleration
      );
      if (Math.abs(wheelAccumulator) < acceleratedDistance) return;
      const direction = resolveWheelDirection(wheelAccumulator, settings.invertScroll);
      const cycleRan = runWheelCycle(
        direction,
        wheelAccumulator > 0 ? 1 : -1,
        now
      );
      if (cycleRan || settings.overshootGuard) {
        wheelAccumulator = 0;
        lastGestureMagnitudePx = 0;
        return;
      }
      wheelAccumulator = Math.sign(wheelAccumulator) * Math.min(
        Math.abs(wheelAccumulator),
        acceleratedDistance
      );
    }
    function resetWheelGestureState() {
      wheelAccumulator = 0;
      lastGestureMagnitudePx = 0;
      lastWheelCycleAt = 0;
      wheelBurstCount = 0;
      momentumGuardSession = null;
    }
    function storageChangedHandler(changes, areaName) {
      if (areaName !== "local") return;
      const settingsChange = changes[TABWHEEL_STORAGE_KEYS.settings];
      if (!settingsChange) return;
      settings = normalizeTabWheelSettings(settingsChange.newValue);
      if (!settings.restorePagePosition) {
        cancelScrollRestore();
        if (scrollSaveTimer) {
          window.clearTimeout(scrollSaveTimer);
          scrollSaveTimer = 0;
        }
      }
      resetWheelGestureState();
      resetMiddleClickSession();
    }
    function messageHandler(message) {
      const receivedMessage = message;
      switch (receivedMessage.type) {
        case "TABWHEEL_PING":
          return Promise.resolve({ ok: true });
        case "GET_SCROLL":
          return Promise.resolve(getRootScrollSnapshot());
        case "SET_SCROLL":
          void restoreWindowScroll(receivedMessage);
          return Promise.resolve({ ok: true });
        case "TABWHEEL_STATUS":
          showStatus(receivedMessage.message);
          return Promise.resolve({ ok: true });
      }
    }
    function visibilityHandler() {
      if (document.visibilityState !== "hidden") {
        lastVisibleAtMs = Date.now();
        return;
      }
      cancelScrollRestore();
      resetWheelGestureState();
      resetMiddleClickSession();
      if (isTopFrameContext) flushScrollSnapshot();
    }
    function pageHideHandler() {
      cancelScrollRestore();
      flushScrollSnapshot();
    }
    window.addEventListener("pointerdown", middleClickHandler, true);
    window.addEventListener("mousedown", middleClickHandler, true);
    window.addEventListener("pointerup", middleClickHandler, true);
    window.addEventListener("mouseup", middleClickHandler, true);
    window.addEventListener("auxclick", middleClickHandler, true);
    window.addEventListener("wheel", wheelHandler, { passive: false, capture: true });
    document.addEventListener("visibilitychange", visibilityHandler);
    import_webextension_polyfill3.default.storage.onChanged.addListener(storageChangedHandler);
    if (isTopFrameContext) {
      window.addEventListener("scroll", scheduleScrollSnapshot, { passive: true, capture: true });
      window.addEventListener("pagehide", pageHideHandler);
      window.addEventListener("beforeunload", pageHideHandler);
      import_webextension_polyfill3.default.runtime.onMessage.addListener(messageHandler);
    }
    window.__tabWheelCleanup = () => {
      window.removeEventListener("pointerdown", middleClickHandler, true);
      window.removeEventListener("mousedown", middleClickHandler, true);
      window.removeEventListener("pointerup", middleClickHandler, true);
      window.removeEventListener("mouseup", middleClickHandler, true);
      window.removeEventListener("auxclick", middleClickHandler, true);
      window.removeEventListener("wheel", wheelHandler, true);
      document.removeEventListener("visibilitychange", visibilityHandler);
      import_webextension_polyfill3.default.storage.onChanged.removeListener(storageChangedHandler);
      if (isTopFrameContext) {
        window.removeEventListener("scroll", scheduleScrollSnapshot, true);
        window.removeEventListener("pagehide", pageHideHandler);
        window.removeEventListener("beforeunload", pageHideHandler);
        import_webextension_polyfill3.default.runtime.onMessage.removeListener(messageHandler);
      }
      cancelScrollRestore();
      resetMiddleClickSession();
      if (scrollSaveTimer) window.clearTimeout(scrollSaveTimer);
      if (statusTimer) window.clearTimeout(statusTimer);
      document.getElementById(STATUS_ID)?.remove();
    };
    if (isTopFrameContext) {
      void notifyTabWheelContentReady().catch(() => {
      });
    }
  }

  // src/entryPoints/contentScript/contentScript.ts
  initApp();
})();

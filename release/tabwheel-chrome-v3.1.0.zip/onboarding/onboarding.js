"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/entryPoints/onboarding/onboarding.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabWheel.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var TABWHEEL_ONBOARDING_VERSION = 1;
  var TABWHEEL_STORAGE_KEYS = {
    settings: "tabWheelSettings",
    scrollMemory: "tabWheelScrollMemory",
    mruState: "tabWheelMruState",
    onboarding: "tabWheelOnboarding"
  };
  var TABWHEEL_MODIFIER_KEYS = ["alt", "ctrl", "meta"];
  var TABWHEEL_CYCLE_SCOPES = ["general", "mru"];
  var TABWHEEL_PRESETS = ["precise", "balanced", "fast", "custom"];
  var TABWHEEL_MIDDLE_CLICK_ACTIONS = ["openSettings", "none"];
  var MIN_WHEEL_SENSITIVITY = 0.5;
  var MAX_WHEEL_SENSITIVITY = 2;
  var MIN_WHEEL_COOLDOWN_MS = 60;
  var MAX_WHEEL_COOLDOWN_MS = 400;
  var TABWHEEL_PRESET_VALUES = {
    precise: {
      wheelSensitivity: 0.8,
      wheelCooldownMs: 220,
      wheelAcceleration: false,
      overshootGuard: true
    },
    balanced: {
      wheelSensitivity: 1,
      wheelCooldownMs: 160,
      wheelAcceleration: false,
      overshootGuard: true
    },
    fast: {
      wheelSensitivity: 1.35,
      wheelCooldownMs: 90,
      wheelAcceleration: true,
      overshootGuard: true
    }
  };
  var DEFAULT_TABWHEEL_SETTINGS = {
    invertScroll: false,
    gestureModifier: "alt",
    gestureWithShift: false,
    allowGesturesInEditableFields: true,
    middleClickAction: "openSettings",
    cycleScope: "general",
    restorePagePosition: true,
    skipPinnedTabs: false,
    skipRestrictedPages: true,
    skipHiddenTabs: true,
    showRestrictedBadge: true,
    wrapAround: true,
    cycleWithinTabGroup: false,
    wheelPreset: "balanced",
    wheelSensitivity: 1,
    wheelCooldownMs: 160,
    wheelAcceleration: false,
    horizontalWheel: true,
    overshootGuard: true
  };
  var DEFAULT_TABWHEEL_ONBOARDING_STATE = {
    version: TABWHEEL_ONBOARDING_VERSION,
    demoCompleted: false,
    firstGestureCycleCompleted: false,
    focusedReleaseSeen: false
  };
  function normalizeModifierKey(value) {
    return TABWHEEL_MODIFIER_KEYS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.gestureModifier;
  }
  function normalizeEnabledFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeNumberInRange(value, fallback, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
  }
  function normalizeTabWheelCycleScope(value) {
    return TABWHEEL_CYCLE_SCOPES.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.cycleScope;
  }
  function normalizeWheelPreset(value) {
    return TABWHEEL_PRESETS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.wheelPreset;
  }
  function normalizeMiddleClickAction(value) {
    return TABWHEEL_MIDDLE_CLICK_ACTIONS.includes(value) ? value : DEFAULT_TABWHEEL_SETTINGS.middleClickAction;
  }
  function detectTabWheelPreset(settings) {
    for (const preset of ["precise", "balanced", "fast"]) {
      const values = TABWHEEL_PRESET_VALUES[preset];
      if (settings.wheelSensitivity === values.wheelSensitivity && settings.wheelCooldownMs === values.wheelCooldownMs && settings.wheelAcceleration === values.wheelAcceleration && settings.overshootGuard === values.overshootGuard) {
        return preset;
      }
    }
    return "custom";
  }
  function normalizeTabWheelSettings(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
    const settings = value;
    const normalized = {
      invertScroll: settings.invertScroll === true,
      gestureModifier: normalizeModifierKey(settings.gestureModifier),
      gestureWithShift: settings.gestureWithShift === true,
      allowGesturesInEditableFields: true,
      middleClickAction: normalizeMiddleClickAction(settings.middleClickAction),
      cycleScope: normalizeTabWheelCycleScope(settings.cycleScope),
      restorePagePosition: true,
      skipPinnedTabs: normalizeEnabledFlag(settings.skipPinnedTabs, DEFAULT_TABWHEEL_SETTINGS.skipPinnedTabs),
      skipRestrictedPages: true,
      skipHiddenTabs: normalizeEnabledFlag(settings.skipHiddenTabs, DEFAULT_TABWHEEL_SETTINGS.skipHiddenTabs),
      showRestrictedBadge: true,
      wrapAround: normalizeEnabledFlag(settings.wrapAround, DEFAULT_TABWHEEL_SETTINGS.wrapAround),
      cycleWithinTabGroup: normalizeEnabledFlag(
        settings.cycleWithinTabGroup,
        DEFAULT_TABWHEEL_SETTINGS.cycleWithinTabGroup
      ),
      wheelPreset: normalizeWheelPreset(settings.wheelPreset),
      wheelSensitivity: normalizeNumberInRange(
        settings.wheelSensitivity,
        DEFAULT_TABWHEEL_SETTINGS.wheelSensitivity,
        MIN_WHEEL_SENSITIVITY,
        MAX_WHEEL_SENSITIVITY
      ),
      wheelCooldownMs: normalizeNumberInRange(
        settings.wheelCooldownMs,
        DEFAULT_TABWHEEL_SETTINGS.wheelCooldownMs,
        MIN_WHEEL_COOLDOWN_MS,
        MAX_WHEEL_COOLDOWN_MS
      ),
      wheelAcceleration: normalizeEnabledFlag(
        settings.wheelAcceleration,
        DEFAULT_TABWHEEL_SETTINGS.wheelAcceleration
      ),
      horizontalWheel: true,
      overshootGuard: true
    };
    normalized.wheelPreset = settings.wheelPreset == null ? detectTabWheelPreset(normalized) : normalized.wheelPreset;
    return normalized;
  }
  function normalizeTabWheelOnboardingState(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return { ...DEFAULT_TABWHEEL_ONBOARDING_STATE };
    }
    const state = value;
    return {
      version: Number(state.version) === TABWHEEL_ONBOARDING_VERSION ? TABWHEEL_ONBOARDING_VERSION : TABWHEEL_ONBOARDING_VERSION,
      demoCompleted: state.demoCompleted === true,
      firstGestureCycleCompleted: state.firstGestureCycleCompleted === true,
      focusedReleaseSeen: state.focusedReleaseSeen === true
    };
  }
  function formatTabWheelModifierKey(modifier) {
    if (modifier === "ctrl") return "Ctrl / Control";
    if (modifier === "meta") return "Meta / Command";
    return "Alt / Option";
  }
  function formatTabWheelModifierCombo(modifier, withShift) {
    const base = formatTabWheelModifierKey(modifier);
    return withShift ? `${base} + Shift` : base;
  }
  function formatTabWheelMiddleClickAction(action) {
    return action === "openSettings" ? "Open settings" : "Off";
  }
  async function loadTabWheelSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.settings);
      return normalizeTabWheelSettings(data[TABWHEEL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_SETTINGS };
    }
  }
  async function saveTabWheelSettings(settings) {
    await import_webextension_polyfill.default.storage.local.set({
      [TABWHEEL_STORAGE_KEYS.settings]: normalizeTabWheelSettings(settings)
    });
  }
  async function loadTabWheelOnboardingState() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABWHEEL_STORAGE_KEYS.onboarding);
      return normalizeTabWheelOnboardingState(data[TABWHEEL_STORAGE_KEYS.onboarding]);
    } catch (_) {
      return { ...DEFAULT_TABWHEEL_ONBOARDING_STATE };
    }
  }
  async function saveTabWheelOnboardingState(state) {
    await import_webextension_polyfill.default.storage.local.set({
      [TABWHEEL_STORAGE_KEYS.onboarding]: normalizeTabWheelOnboardingState(state)
    });
  }

  // src/lib/core/tabWheel/tabWheelCore.ts
  function isTabWheelModifier(event, modifier, withShift) {
    const expected = {
      altKey: modifier === "alt",
      ctrlKey: modifier === "ctrl",
      metaKey: modifier === "meta",
      shiftKey: withShift
    };
    return event.altKey === expected.altKey && event.ctrlKey === expected.ctrlKey && event.metaKey === expected.metaKey && event.shiftKey === expected.shiftKey;
  }
  function resolveWheelDirection(wheelDelta, invertScroll) {
    const normalDirection = wheelDelta > 0 ? "next" : "prev";
    if (!invertScroll) return normalDirection;
    return normalDirection === "next" ? "prev" : "next";
  }
  function normalizeWheelDelta(event, pageHeight, pageWidth, horizontalWheel) {
    const modeMultiplierY = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? pageHeight : 1;
    const normalizedY = event.deltaY * modeMultiplierY;
    if (!horizontalWheel) return normalizedY;
    const modeMultiplierX = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? pageWidth : 1;
    const normalizedX = event.deltaX * modeMultiplierX;
    return Math.abs(normalizedX) > Math.abs(normalizedY) ? normalizedX : normalizedY;
  }
  function resolveWheelTriggerDistance(baseThresholdPx, sensitivity) {
    const safeSensitivity = Number.isFinite(sensitivity) && sensitivity > 0 ? sensitivity : 1;
    return Math.max(1, baseThresholdPx / safeSensitivity);
  }

  // src/lib/ui/settings/settingsControls.ts
  function populateModifierSelect(select, selected) {
    setSelectOptions(
      select,
      TABWHEEL_MODIFIER_KEYS,
      selected,
      (value) => formatTabWheelModifierKey(value)
    );
  }
  function populateMiddleClickActionSelect(select, selected) {
    setSelectOptions(
      select,
      TABWHEEL_MIDDLE_CLICK_ACTIONS,
      selected,
      (value) => formatTabWheelMiddleClickAction(value)
    );
  }
  function setSelectOptions(select, values, selected, label) {
    select.replaceChildren();
    for (const value of values) {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = label(value);
      if (value === selected) option.selected = true;
      select.appendChild(option);
    }
  }

  // src/entryPoints/onboarding/onboarding.ts
  document.addEventListener("DOMContentLoaded", async () => {
    const byId = (id) => document.getElementById(id);
    const mode = new URLSearchParams(window.location.search).get("mode") === "update" ? "update" : "install";
    const installFlow = byId("installFlow");
    const updateFlow = byId("updateFlow");
    let settings = await loadTabWheelSettings();
    let onboarding = await loadTabWheelOnboardingState();
    async function closeCurrentTab() {
      const tab = await import_webextension_polyfill2.default.tabs.getCurrent().catch(() => null);
      if (tab?.id != null) await import_webextension_polyfill2.default.tabs.remove(tab.id).catch(() => {
      });
      else window.close();
    }
    const openSettings = () => void import_webextension_polyfill2.default.runtime.openOptionsPage();
    if (mode === "update") {
      installFlow.hidden = true;
      updateFlow.hidden = false;
      onboarding = { ...onboarding, focusedReleaseSeen: true };
      await saveTabWheelOnboardingState(onboarding);
      byId("updateSettingsBtn").addEventListener("click", openSettings);
      byId("dismissUpdateBtn").addEventListener("click", () => void closeCurrentTab());
      return;
    }
    const demo = byId("gestureDemo");
    const demoCombo = byId("demoCombo");
    const demoPrompt = byId("demoPrompt");
    const demoStatus = byId("demoStatus");
    const continueDemoBtn = byId("continueDemoBtn");
    const modifierSelect = byId("gestureModifier");
    const gestureWithShift = byId("gestureWithShift");
    const middleClickAction = byId("middleClickAction");
    const tabs = [...document.querySelectorAll(".demo-tab")];
    let demoAccumulator = 0;
    let activeDemoTab = 0;
    function renderCombo() {
      const combo = formatTabWheelModifierCombo(settings.gestureModifier, settings.gestureWithShift);
      demoCombo.textContent = combo;
      demoPrompt.textContent = `Hold ${combo} + scroll`;
      byId("readyCombo").textContent = `${combo} + wheel`;
    }
    function showStep(step) {
      for (const panel of document.querySelectorAll("[data-step]")) {
        panel.hidden = Number(panel.dataset.step) !== step;
      }
      for (const marker of document.querySelectorAll("[data-progress]")) {
        marker.classList.toggle("active", Number(marker.dataset.progress) <= step);
      }
    }
    async function markDemoComplete() {
      if (onboarding.demoCompleted) return;
      onboarding = { ...onboarding, demoCompleted: true };
      await saveTabWheelOnboardingState(onboarding);
    }
    populateModifierSelect(modifierSelect, settings.gestureModifier);
    populateMiddleClickActionSelect(middleClickAction, settings.middleClickAction);
    gestureWithShift.checked = settings.gestureWithShift;
    renderCombo();
    demo.addEventListener("wheel", (event) => {
      if (!isTabWheelModifier(event, settings.gestureModifier, settings.gestureWithShift)) {
        demoStatus.textContent = `Hold ${formatTabWheelModifierCombo(settings.gestureModifier, settings.gestureWithShift)} while scrolling.`;
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      demoAccumulator += normalizeWheelDelta(event, demo.clientHeight, demo.clientWidth, false);
      const triggerDistance = resolveWheelTriggerDistance(80, settings.wheelSensitivity);
      if (Math.abs(demoAccumulator) < triggerDistance) return;
      const movement = resolveWheelDirection(demoAccumulator, settings.invertScroll) === "next" ? 1 : -1;
      activeDemoTab = (activeDemoTab + movement + tabs.length) % tabs.length;
      tabs.forEach((tab, index) => tab.classList.toggle("active", index === activeDemoTab));
      demoAccumulator = 0;
      demo.classList.add("success");
      demoStatus.textContent = "Perfect \u2014 that is the whole gesture, and it works anywhere on a page.";
      continueDemoBtn.disabled = false;
      void markDemoComplete();
    }, { passive: false });
    demo.addEventListener("click", () => demo.focus());
    continueDemoBtn.addEventListener("click", () => showStep(2));
    byId("skipDemoBtn").addEventListener("click", () => showStep(2));
    byId("saveChoicesBtn").addEventListener("click", async () => {
      settings = {
        ...settings,
        gestureModifier: modifierSelect.value,
        gestureWithShift: gestureWithShift.checked,
        middleClickAction: middleClickAction.value
      };
      await saveTabWheelSettings(settings);
      renderCombo();
      showStep(3);
    });
    document.querySelector("[data-back='1']")?.addEventListener("click", () => showStep(1));
    byId("openSettingsBtn").addEventListener("click", openSettings);
    byId("finishBtn").addEventListener("click", async () => {
      onboarding = { ...onboarding, version: 1 };
      await saveTabWheelOnboardingState(onboarding);
      await closeCurrentTab();
    });
  });
})();
